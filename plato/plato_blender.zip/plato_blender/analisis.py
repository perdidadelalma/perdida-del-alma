"""Separa la luz que recibe la persona en fuentes con papel de plató.

Dos orígenes, en las mismas unidades (irradiancia de Blender, W/m², sobre una
superficie que mira a la fuente; calibrado en test_sonda):
- Luces de Blender, sumadas con fórmula: punto y foco P/(4πd²), área P/(πd²)·cos, sol su intensidad.
- La panorámica (con las luces invisibles a cámara): HDRI, cielo, objetos que
  emiten y rebotes. Las zonas brillantes se agrupan en fuentes; el resto es ambiente.
"""

import math

import bpy
import numpy as np
from mathutils import Vector

from . import sonda

# ---------------------------------------------------------------- color

_RGB2XYZ = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]])


def kelvin_de_rgb(rgb):
    """Temperatura de color (McCamy) y si es un color «de gel» lejos del blanco."""
    rgb = np.clip(np.asarray(rgb, dtype=float), 0, None)
    if rgb.max() <= 0:
        return None, False, ""
    X, Y, Z = _RGB2XYZ @ rgb
    s = X + Y + Z
    x, y = X / s, Y / s
    n = (x - 0.3320) / (0.1858 - y)
    cct = 449 * n ** 3 + 3525 * n ** 2 + 6823.3 * n + 5520.33
    sat = (rgb.max() - rgb.min()) / rgb.max()
    color = sat > 0.55 or not (1600 < cct < 20000)
    return float(np.clip(cct, 1000, 25000)), bool(color), _nombre_color(rgb) if color else ""


def _nombre_color(rgb):
    r, g, b = rgb / rgb.max()
    h = math.degrees(math.atan2(math.sqrt(3) * (g - b), 2 * r - g - b)) % 360
    for lim, nombre in ((15, "rojo"), (45, "naranja"), (70, "amarillo"), (160, "verde"), (200, "cian"),
                        (260, "azul"), (300, "violeta"), (340, "magenta"), (361, "rojo")):
        if h < lim:
            return nombre
    return "color"


def blackbody_rgb(k):
    """Aproximación (Tanner Helland) suficiente para el color de una luz por temperatura."""
    t = k / 100.0
    r = 255 if t <= 66 else 329.698727446 * ((t - 60) ** -0.1332047592)
    g = 99.4708025861 * math.log(t) - 161.1195681661 if t <= 66 else 288.1221695283 * ((t - 60) ** -0.0755148492)
    b = 255 if t >= 66 else (0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307)
    srgb = np.clip(np.array([r, g, b]) / 255.0, 0, 1)
    return np.where(srgb <= 0.04045, srgb / 12.92, ((srgb + 0.055) / 1.055) ** 2.4)


# ---------------------------------------------------------------- luces de Blender

def _deja_pasar_luz(obj):
    """Cristal, alfa o volumen: la luz atraviesa (ray_cast no lo sabe)."""
    for slot in getattr(obj, "material_slots", []):
        m = slot.material
        if m is None:
            continue
        if getattr(m, "blend_method", "OPAQUE") in {"BLEND", "HASHED"}:
            return True
        if m.use_nodes and m.node_tree:
            for n in m.node_tree.nodes:
                if n.type in {"BSDF_GLASS", "BSDF_TRANSPARENT", "BSDF_REFRACTION"}:
                    return True
                if n.type == "BSDF_PRINCIPLED":
                    t = n.inputs.get("Transmission Weight") or n.inputs.get("Transmission")
                    a = n.inputs.get("Alpha")
                    if (t and not t.is_linked and t.default_value > 0.5) or (a and not a.is_linked and a.default_value < 0.5):
                        return True
    return False


def _visible(scene, depsgraph, desde, hasta, ignorar):
    """¿Llega la luz de «hasta» a «desde»? Ignora la persona y lo que deja pasar la luz."""
    d = hasta - desde
    dist = d.length
    if dist < 1e-4:
        return True
    u = d.normalized()
    pos, resto = desde, dist
    for _ in range(64):
        hit, loc, _n, _i, obj, _m = scene.ray_cast(depsgraph, pos + u * 0.001, u, distance=resto - 0.002)
        if not hit:
            return True
        orig = getattr(obj, "original", obj)
        if orig.name not in ignorar and not _deja_pasar_luz(orig):
            return False
        pos = loc + u * 0.002
        resto = (hasta - pos).length
        if resto < 0.01:
            return True
    return True


def luces_blender(scene, punto, ignorar=()):
    depsgraph = bpy.context.evaluated_depsgraph_get()
    fuentes = []
    for o in scene.objects:
        if o.type != "LIGHT" or o.hide_render or not o.visible_get() or o.get("plato_foco"):
            continue
        l = o.data
        color = np.array(l.color[:])
        if getattr(l, "use_temperature", False):
            color = color * blackbody_rgb(l.temperature)
        m = o.matrix_world
        pos = m.translation
        eje = (m.to_3x3() @ Vector((0, 0, -1))).normalized()
        if l.type == "SUN":
            hacia = -eje
            E = l.energy
            tam = math.degrees(getattr(l, "angle", 0.0))
            dist = None
            lejos = punto + hacia * 1000
            tapada = not _visible(scene, depsgraph, punto, lejos, ignorar)
        else:
            v = pos - punto
            dist = v.length
            if dist < 1e-3:
                continue
            hacia = v.normalized()
            tapada = not _visible(scene, depsgraph, punto, pos, ignorar)
            if l.type in {"POINT", "SPOT"}:
                E = l.energy / (4 * math.pi * dist ** 2)
                radio = getattr(l, "shadow_soft_size", 0.0)
                tam = math.degrees(2 * math.atan2(radio, dist))
                if l.type == "SPOT":
                    ang = math.acos(max(-1, min(1, eje.dot(-hacia))))
                    medio = l.spot_size / 2
                    if ang > medio:
                        E = 0.0
                    else:
                        borde = medio * (1 - l.spot_blend)
                        if ang > borde and medio > borde:
                            t = (medio - ang) / (medio - borde)
                            E *= t * t * (3 - 2 * t)
            else:  # AREA
                c = max(0.0, eje.dot(-hacia))
                E = l.energy / (math.pi * dist ** 2) * c
                lado = max(l.size, getattr(l, "size_y", l.size) if l.shape in {"RECTANGLE", "ELLIPSE"} else l.size)
                tam = math.degrees(2 * math.atan2(lado / 2, dist))
        if E <= 0:
            continue
        rgb = color * E
        fuentes.append({"origen": "luz", "nombre": o.name, "tipo_blender": l.type, "dir": np.array(hacia[:]),
                        "E": float(E * (0.2126 * color[0] + 0.7152 * color[1] + 0.0722 * color[2])),
                        "rgb": color, "tam": tam, "dist": dist, "tapada": tapada,
                        "haz": math.degrees(l.spot_size) if l.type == "SPOT" else None})
    return fuentes


# ---------------------------------------------------------------- entorno (panorámica)

def _componentes(mask):
    """Regiones conectadas con la costura horizontal cerrada (sin scipy)."""
    alto, ancho = mask.shape
    etiqueta = np.zeros(mask.shape, dtype=np.int32)
    n = 0
    for i0, j0 in zip(*np.nonzero(mask)):
        if etiqueta[i0, j0]:
            continue
        n += 1
        pila = [(i0, j0)]
        etiqueta[i0, j0] = n
        while pila:
            i, j = pila.pop()
            for di, dj in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                a, b = i + di, (j + dj) % ancho
                if 0 <= a < alto and mask[a, b] and not etiqueta[a, b]:
                    etiqueta[a, b] = n
                    pila.append((a, b))
    return etiqueta, n


def fuentes_entorno(px, max_fuentes=5):
    d, dom = sonda.direcciones(*px.shape[:2])
    Y = px @ np.array([0.2126, 0.7152, 0.0722])
    w = Y * dom
    total = float(w.sum())
    if total <= 0:
        return [], {"E": 0.0}
    umbral = max(3.0 * float(np.median(Y)), 0.08 * float(Y.max()))
    etiqueta, n = _componentes(Y > umbral)
    fuentes = []
    for k in range(1, n + 1):
        m = etiqueta == k
        E = float(w[m].sum())
        if E < 0.03 * total:
            continue
        v = (d[m] * w[m][:, None]).sum(0)
        v /= np.linalg.norm(v)
        omega = float(dom[m].sum())
        tam = math.degrees(2 * math.acos(max(-1.0, 1 - omega / (2 * math.pi))))
        rgb = (px[m] * dom[m][:, None]).sum(0) / omega
        fuentes.append({"origen": "entorno", "nombre": "", "tipo_blender": None, "dir": v, "E": E,
                        "rgb": rgb / max(rgb.max(), 1e-9), "tam": tam, "dist": None, "tapada": False, "haz": None,
                        "mascara": m})
    fuentes.sort(key=lambda f: -f["E"])
    fuentes = fuentes[:max_fuentes]
    resto = np.ones(Y.shape, dtype=bool)
    for f in fuentes:
        resto &= ~f.pop("mascara")
    arriba = resto & (d[..., 2] > 0.25)
    abajo = resto & (d[..., 2] < -0.25)
    medio = resto & ~arriba & ~abajo
    amb = {}
    for nombre, m in (("cielo", arriba), ("horizonte", medio), ("suelo", abajo)):
        E = float(w[m].sum())
        rgb = (px[m] * dom[m][:, None]).sum(0) / max(float(dom[m].sum()), 1e-9)
        amb[nombre] = {"E": E, "rgb": rgb / max(rgb.max(), 1e-9)}
    amb["E"] = sum(a["E"] for a in amb.values() if isinstance(a, dict))
    return fuentes, amb


# ---------------------------------------------------------------- papeles

def _horizontal(v):
    v = Vector((v[0], v[1], 0))
    return v.normalized() if v.length > 1e-6 else Vector((0, -1, 0))


def clasificar(fuentes, hacia_camara):
    """Ángulos respecto al eje cámara-persona y papel de cada fuente."""
    c = _horizontal(hacia_camara)
    derecha = Vector((-c.y, c.x, 0))  # derecha de cuadro vista desde la cámara
    for f in fuentes:
        v = Vector(f["dir"])
        h = _horizontal(v)
        f["elev"] = math.degrees(math.asin(max(-1, min(1, v.z))))
        f["azim"] = math.degrees(math.atan2(h.dot(derecha), h.dot(c)))  # 0 = desde cámara, +90 = derecha de cuadro
        f["detras"] = abs(f["azim"]) > 100
    fuentes.sort(key=lambda f: -f["E"])
    hay_clave = False
    hay_relleno = False
    for f in fuentes:
        a = abs(f["azim"])
        if f["E"] <= 0:
            f["rol"] = "—"
        elif f["elev"] > 65:
            f["rol"] = "Cenital"
        elif f["elev"] < -20:
            f["rol"] = "Rebote de suelo"
        elif f["detras"]:
            f["rol"] = "Contra"
        elif not hay_clave:
            f["rol"] = "Clave"
            hay_clave = True
        elif not hay_relleno and a < 80:
            f["rol"] = "Relleno"
            hay_relleno = True
        else:
            f["rol"] = "Lateral" if a >= 80 else "Acento"
    if not hay_clave and fuentes:  # sin luz frontal: la más fuerte manda
        fuentes[0]["rol"] = "Clave · " + fuentes[0]["rol"]
    for f in fuentes:
        f["kelvin"], f["es_color"], f["color_nombre"] = kelvin_de_rgb(f["rgb"])
    return fuentes


def medir(scene, persona, muestras=48):
    """Todo el análisis para una persona: fuentes con papel y ambiente."""
    from . import maniqui
    punto = maniqui.punto_medida(persona)
    ocultar = [o for o in scene.objects if o.get("plato_persona") or o.get("plato_medida") or o.get("plato_foco")]
    luces = luces_blender(scene, punto, ignorar={o.name for o in ocultar})
    # Luces fuera de la panorámica (se suman con fórmula), pero su luz rebotada sí entra.
    saved = []
    for o in scene.objects:
        if o.type == "LIGHT" and hasattr(o, "visible_camera"):
            saved.append((o, o.visible_camera))
            o.visible_camera = False
    try:
        px = sonda.panoramica(scene, punto, ocultar=ocultar, muestras=muestras)
    finally:
        for o, v in saved:
            o.visible_camera = v
    entorno, ambiente = fuentes_entorno(px)
    cam = scene.camera
    hacia_cam = (cam.matrix_world.translation - punto) if cam else maniqui.frente(persona)
    fuentes = clasificar([f for f in luces if not f["tapada"]] + entorno, hacia_cam)
    tapadas = [f for f in luces if f["tapada"]]
    ambiente["kelvin"], _c, _n = kelvin_de_rgb(ambiente.get("cielo", {}).get("rgb", np.ones(3)))
    return {"punto": tuple(punto), "fuentes": fuentes, "ambiente": ambiente, "tapadas": tapadas,
            "panoramica": px}
