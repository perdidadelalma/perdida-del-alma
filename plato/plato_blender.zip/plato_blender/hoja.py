"""Hoja de plató: una página HTML que vale para imprimir y para la tablet.

Lleva la planta vista desde arriba (persona, cámara y focos numerados), una
ficha por foco con todo lo que hay que montar, la panorámica de lo que ve la
cara y una casilla «montado» por foco que se recuerda en la tablet.
Todo va dentro del archivo (fuentes e imágenes), así que se puede mandar tal cual.
"""

import base64
import datetime
import html
import math
import os
import socket
import tempfile
import threading
import webbrowser
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

import bpy
import numpy as np

from . import analisis, catalogo, traduccion as tr

AQUI = os.path.dirname(__file__)


def _b64(ruta):
    with open(ruta, "rb") as f:
        return base64.b64encode(f.read()).decode()


def _hex(rgb):
    rgb = np.clip(np.asarray(rgb, dtype=float), 0, None)
    rgb = rgb / max(rgb.max(), 1e-9)
    srgb = np.where(rgb <= 0.0031308, rgb * 12.92, 1.055 * rgb ** (1 / 2.4) - 0.055)
    return "#%02x%02x%02x" % tuple(int(round(c * 255)) for c in np.clip(srgb, 0, 1))


def color_foco(fo):
    if fo.get("es_color"):
        return _hex(fo["rgb"])
    return _hex(analisis.blackbody_rgb(fo.get("kelvin") or 5600))


def panoramica_png(px, giro=0.0):
    """La panorámica en PNG para la hoja, con la cámara en el centro.

    «giro»: ángulo (rad) en el mundo de la dirección cara → cámara.
    """
    if px is None:
        return ""
    alto, ancho = px.shape[:2]
    # La columna j mira a lon = (0,5 − j/ancho)·2π; se rueda para que la cámara quede en el centro.
    px = np.roll(px, int(round(giro / (2 * math.pi) * ancho)), axis=1)
    lum = px @ np.array([0.2126, 0.7152, 0.0722])
    px = px * (0.25 / max(float(np.mean(lum)), 1e-6))
    v = px / (px + 1.0)  # Reinhard: se ven a la vez el cielo y las sombras
    v = np.where(v <= 0.0031308, v * 12.92, 1.055 * np.power(np.clip(v, 0, 1), 1 / 2.4) - 0.055)
    rgba = np.concatenate([v[::-1], np.ones((alto, ancho, 1), np.float32)], axis=2).astype(np.float32)
    img = bpy.data.images.new("PLATÓ · panorámica", ancho, alto, alpha=True, float_buffer=False)
    ruta = os.path.join(tempfile.gettempdir(), f"plato_pano_{os.getpid()}.png")
    try:
        img.pixels.foreach_set(rgba.ravel())
        img.filepath_raw = ruta
        img.file_format = "PNG"
        img.save()
        return _b64(ruta)
    finally:
        bpy.data.images.remove(img)
        try:
            os.remove(ruta)
        except OSError:
            pass


# ---------------------------------------------------------------- planta

def planta_svg(focos):
    """Vista desde arriba: persona en el centro, cámara abajo, focos numerados.

    Escala de raíz cuadrada: lo cercano se separa y lo lejano cabe. Los anillos marcan metros reales.
    """
    alcance = max([2.0] + [math.hypot(f["x"], f["y"]) for f in focos]) * 1.08
    S = 560
    k = (S / 2 - 34) / math.sqrt(alcance)

    def p(x, y):  # x derecha de cuadro, y hacia cámara (abajo en el dibujo)
        r = math.hypot(x, y)
        if r < 1e-6:
            return S / 2, S / 2
        e = k * math.sqrt(r) / r
        return S / 2 + x * e, S / 2 + y * e

    e = [f'<svg viewBox="0 0 {S} {S}" class="planta" role="img" aria-label="Planta del plató">']
    for r in [0.5] + list(range(1, int(alcance) + 1)):
        rr = k * math.sqrt(r)
        e.append(f'<circle cx="{S/2}" cy="{S/2}" r="{rr:.1f}" class="anillo"/>'
                 f'<text x="{S/2 + 3}" y="{S/2 - rr - 3:.1f}" class="metro">{_f(r, 1 if r < 1 else 0)} m</text>')
    cx, cy = S / 2, S - 26
    e.append(f'<line x1="{S/2}" y1="{S/2}" x2="{cx:.1f}" y2="{cy:.1f}" class="eje"/>')
    e.append(f'<g transform="translate({cx:.1f},{cy - 6:.1f})"><rect x="-17" y="-11" width="34" height="22" rx="3" class="camara"/>'
             f'<polygon points="-9,-11 9,-11 15,-22 -15,-22" class="camara"/><text x="26" y="5" class="rotulo" style="text-anchor:start">CÁMARA</text></g>')
    e.append(f'<circle cx="{S/2}" cy="{S/2}" r="11" class="persona"/><circle cx="{S/2}" cy="{S/2 + 13}" r="3.5" class="persona"/>')
    for f in sorted(focos, key=lambda f: -math.hypot(f["x"], f["y"])):
        x, y = p(f["x"], f["y"])
        col = color_foco(f)
        ang = math.degrees(math.atan2(S / 2 - y, S / 2 - x))
        e.append(f'<line x1="{x:.1f}" y1="{y:.1f}" x2="{S/2}" y2="{S/2}" stroke="{col}" class="rayo"/>')
        e.append(f'<g transform="translate({x:.1f},{y:.1f})"><rect x="-13" y="-11" width="26" height="22" rx="2" '
                 f'transform="rotate({ang:.0f})" fill="{col}" class="foco"/>'
                 f'<text y="5" class="num">{f["n"]}</text></g>')
    e.append("</svg>")
    return "".join(e)


# ---------------------------------------------------------------- página

CSS = """
@font-face { font-family: Senal; src: url(data:font/ttf;base64,%(senal)s); }
@font-face { font-family: Bloque; src: url(data:font/ttf;base64,%(bloque)s); }
:root { --h: #0a1112; --h2: #111b1d; --h3: #1a272a; --n: #a4b4ba; --no: #607076; --c: #4fe3f0; }
* { box-sizing: border-box; }
body { margin: 0; background: var(--h); color: var(--n); font: 16px/1.5 system-ui, "Segoe UI", sans-serif; }
main { max-width: 1100px; margin: 0 auto; padding: 18px 16px 60px; }
.osd { font: 13px Consolas, monospace; letter-spacing: .08em; text-transform: uppercase; color: var(--no); }
h1 { font-family: Bloque, Impact, sans-serif; font-size: clamp(34px, 6vw, 58px); margin: 6px 0 0; color: #dfe9eb; letter-spacing: .02em; }
h1 span { color: var(--c); }
h2 { font-family: Senal, Impact, sans-serif; font-weight: normal; font-size: 28px; color: #dfe9eb; margin: 34px 0 10px; }
.datos { display: flex; flex-wrap: wrap; gap: 8px; margin: 14px 0; }
.datos b { display: inline-block; background: var(--h2); border-left: 3px solid var(--c); padding: 6px 12px; font-weight: normal; }
.datos b i { font-style: normal; color: var(--c); }
.arriba { display: grid; grid-template-columns: minmax(0, 1.1fr) minmax(0, 1fr); gap: 22px; align-items: start; }
.planta { width: 100%%; background: var(--h2); border: 1px solid var(--h3); }
.anillo { fill: none; stroke: var(--h3); stroke-width: 1; }
.metro { fill: var(--no); font: 11px Consolas, monospace; }
.eje { stroke: var(--no); stroke-dasharray: 4 6; }
.camara { fill: var(--h3); stroke: var(--n); stroke-width: 1.5; }
.persona { fill: var(--n); }
.rayo { stroke-width: 2; opacity: .55; }
.foco { stroke: #000; stroke-width: 1; }
.num { fill: #000; font: bold 13px Consolas, monospace; text-anchor: middle; }
.rotulo { fill: var(--n); font: 10px Consolas, monospace; text-anchor: middle; letter-spacing: .06em; }
.pano img { width: 100%%; display: block; border: 1px solid var(--h3); image-rendering: auto; }
.pano .osd { margin-top: 6px; }
.pano .marco { position: relative; }
.pano span { position: absolute; transform: translate(-50%%, -50%%); min-width: 20px; height: 20px; padding: 0 4px;
  color: #000; font: bold 12px/20px Consolas, monospace; text-align: center; border: 1px solid #000; border-radius: 10px; }
.fichas { display: grid; grid-template-columns: repeat(auto-fill, minmax(320px, 1fr)); gap: 14px; }
.ficha { background: var(--h2); border-top: 4px solid var(--col); padding: 14px 16px 12px; position: relative; }
.ficha .n { font-family: Senal, Impact, sans-serif; font-size: 44px; line-height: 1; color: var(--col); float: right; }
.ficha h3 { margin: 0; font: 12px Consolas, monospace; letter-spacing: .1em; text-transform: uppercase; color: var(--c); }
.ficha .modelo { font-size: 20px; color: #dfe9eb; margin: 2px 0 8px; }
.ficha dl { display: grid; grid-template-columns: auto 1fr; gap: 3px 12px; margin: 0; }
.ficha dt { color: var(--no); font-size: 13px; }
.ficha dd { margin: 0; }
.ficha .pct { font-family: Bloque, Impact, sans-serif; font-size: 28px; color: var(--c); }
.ficha .pct small { font: 18px system-ui, sans-serif; margin-left: 3px; }
.ficha .aviso { margin-top: 8px; color: #f0b14f; font-size: 14px; }
.ficha label { display: flex; gap: 8px; align-items: center; margin-top: 10px; font: 13px Consolas, monospace; text-transform: uppercase; cursor: pointer; }
.ficha input { width: 22px; height: 22px; accent-color: var(--c); }
.ficha.hecho { opacity: .45; }
.falta { padding-left: 20px; } .falta li { margin: 6px 0; } .falta b { color: #dfe9eb; }
.nota { background: var(--h2); border-left: 3px solid var(--c); padding: 12px 16px; margin: 26px 0 0; font-size: 14px; }
footer { margin-top: 30px; }
footer a { color: var(--c); }
@media (max-width: 760px) { .arriba, .fichas { grid-template-columns: minmax(0, 1fr); } .planta, .pano { max-width: 100%%; } .ficha dd, .osd { overflow-wrap: anywhere; } .ficha { padding: 12px; } }
@media print {
  body { background: #fff; color: #111; font-size: 12px; }
  h1, h2, .ficha .modelo { color: #000; }
  .datos b, .ficha, .planta, .nota { background: #fff; border-color: #999; }
  .planta .anillo { stroke: #ccc; } .planta .rotulo, .planta .metro { fill: #333; } .persona { fill: #333; }
  .camara { fill: #eee; stroke: #333; } .ficha label { display: none; } .ficha.hecho { opacity: 1; }
  .fichas { grid-template-columns: 1fr 1fr; } .ficha { break-inside: avoid; border: 1px solid #999; border-top: 4px solid var(--col); }
  .pano { break-inside: avoid; }
}
"""

JS = """
const clave = 'plato:' + document.body.dataset.id;
let hechos = {};
try { hechos = JSON.parse(localStorage.getItem(clave) || '{}'); } catch (e) {}
document.querySelectorAll('.ficha input').forEach(c => {
  const f = c.closest('.ficha'), n = f.dataset.n;
  c.checked = !!hechos[n]; f.classList.toggle('hecho', c.checked);
  c.addEventListener('change', () => {
    hechos[n] = c.checked; f.classList.toggle('hecho', c.checked);
    try { localStorage.setItem(clave, JSON.stringify(hechos)); } catch (e) {}
  });
});
"""


def _f(v, d=1):
    return f"{v:.{d}f}".replace(".", ",")


def ficha(fo, L_clave):
    f = catalogo.foco(fo["foco_id"]) or {"marca": "Pasivo", "modelo": "— sin foco: falta equipo —", "tipo": "", "accesorio": ""}
    m = catalogo.modificador(fo["mod"])
    paso = tr.pasos(fo["lux"], L_clave)
    ratio = "la clave" if fo["rol"].startswith("Clave") else (f"{_f(paso)} pasos respecto a la clave")
    pasivo = f.get("tipo") == "Pasivo"
    par = fo.get("parecido")
    filas = [
        ("Dónde", f"{tr.lado_texto(fo['azim'])}, {tr.hora_texto(fo['hora'])} (cámara a las 6)"),
        ("Distancia", f"{_f(fo['en_suelo'], 2)} m por el suelo hasta la persona"),
        ("Altura", f"{_f(fo['altura'], 2)} m, apuntando a la cara ({_f(fo['elev'], 0)}°)"),
        ("Modificador", "—" if pasivo else m["nombre"]),
        ("Color", fo["gel"] or "—"),
        ("En la cara", f"{_f(fo['lux'], 0)} lux · {ratio}"),
        ("Sale de", f"{fo['fuente']} ({fo['origen']})"),
    ]
    if par is not None:
        filas.append(("Parecido", f"{_f(par * 100, 0)} % con la luz de Blender"))
    dl = "".join(f"<dt>{html.escape(a)}</dt><dd>{html.escape(b)}</dd>" for a, b in filas)
    pct = "" if pasivo else f'<div class="pct">{_f(min(fo["pct"], 999), 0)}<small>%</small></div>'
    aviso = f'<div class="aviso">⚠ {html.escape(fo["aviso"])}</div>' if fo.get("aviso") else ""
    return (f'<article class="ficha" data-n="{fo["n"]}" style="--col:{color_foco(fo)}">'
            f'<div class="n">{fo["n"]}</div><h3>{html.escape(fo["rol"])}</h3>'
            f'<div class="modelo">{html.escape(catalogo.nombre(f))}</div>{pct}<dl>{dl}</dl>{aviso}'
            f'<label><input type="checkbox"> montado</label></article>')


def generar(ruta, focos, datos, px=None):
    """Escribe la hoja. «datos»: escena, persona, t_stop, iso, fps, obturador, lux_clave."""
    L = datos["lux_clave"]
    pano = panoramica_png(px, datos.get("giro", 0.0))
    # Cada foco sobre la panorámica: la derecha de cuadro queda a la izquierda (se mira desde la cara a cámara).
    marcas = "".join(f'<span style="left:{50 - fo["azim"] / 3.6:.1f}%;top:{50 - fo["elev"] / 1.8:.1f}%;'
                     f'background:{color_foco(fo)}">{fo["n"]}</span>' for fo in focos)
    pano_html = (f'<div class="pano"><div class="marco"><img alt="Panorámica de 360° desde la cara de la persona" '
                 f'src="data:image/png;base64,{pano}">{marcas}</div><div class="osd">Lo que ve la cara en 360° · en el centro, la cámara · a los lados, lo que tiene detrás · los números son los focos</div></div>'
                 if pano else "")
    fichas = "".join(ficha(fo, L) for fo in focos)
    total = datos.get("parecido")
    parecido_html = f"<b>Parecido con Blender <i>{_f(total * 100, 0)} %</i></b>" if total is not None else ""
    falta = datos.get("falta") or []
    falta_html = ""
    if falta:
        filas = "".join(f"<li><b>{html.escape(n)}</b> · sube el parecido {_f(g, 0)} puntos · para {html.escape(', '.join(dict.fromkeys(r)))}</li>"
                        for n, g, r in falta)
        falta_html = f'<h2>Qué me falta</h2><ul class="falta">{filas}</ul>'
    hoy = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
    css = CSS % {"senal": _b64(os.path.join(AQUI, "docs", "PerdidaSenal.ttf")),
                 "bloque": _b64(os.path.join(AQUI, "docs", "PerdidaBloque.ttf"))}
    ident = f"{datos['escena']}·{datos['persona']}"
    pagina = f"""<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Hoja de plató · {html.escape(datos['escena'])}</title><style>{css}</style></head>
<body data-id="{html.escape(ident)}"><main>
<div class="osd">PLATÓ · N.º 02 · {hoy}</div>
<h1>HOJA DE <span>PLATÓ</span></h1>
<div class="datos">
<b>Escena <i>{html.escape(datos['escena'])}</i></b><b>Persona <i>{html.escape(datos['persona'])}</i></b>
<b>Cámara <i>T{_f(datos['t_stop'])} · ISO {datos['iso']} · {_f(datos['fps'], 0)} fps · {datos['obturador']:.0f}°</i></b>
<b>Clave <i>{_f(L, 0)} lux</i></b><b>Focos <i>{len(focos)}</i></b>{parecido_html}</div>
<div class="arriba"><div>{planta_svg(focos)}</div><div>{pano_html}
<div class="nota">Mide con el fotómetro en la cara, apuntando a cada foco con los demás apagados, y ajusta la potencia
hasta que dé los lux de su ficha. Los porcentajes salen de datos aproximados de fabricante: son el punto de partida.</div></div></div>
<h2>Focos</h2><div class="fichas">{fichas}</div>{falta_html}
<footer class="osd">PLATÓ · Iluminación real · por Toniño · Pérdida del Alma ·
<a href="https://www.instagram.com/perdidadelalma/">@perdidadelalma</a></footer>
</main><script>{JS}</script></body></html>"""
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(pagina)
    return ruta


def carpeta_salida():
    if bpy.data.filepath:
        return os.path.join(os.path.dirname(bpy.data.filepath), "plato")
    return os.path.join(os.path.expanduser("~"), "PLATO", "hojas")


def abrir(ruta):
    webbrowser.open("file:///" + ruta.replace("\\", "/"))


# ---------------------------------------------------------------- servir a la tablet

_servidor = {"srv": None, "dir": None, "puerto": 8791}


def ip_local():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def servir(carpeta):
    """Sirve la carpeta de hojas en la red local para abrirla desde la tablet o el móvil."""
    if _servidor["srv"] and _servidor["dir"] == carpeta:
        return _servidor["puerto"]
    parar()
    for puerto in range(8791, 8800):
        try:
            srv = ThreadingHTTPServer(("0.0.0.0", puerto), partial(SimpleHTTPRequestHandler, directory=carpeta))
            break
        except OSError:
            continue
    else:
        raise OSError("no hay ningún puerto libre entre 8791 y 8799")
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _servidor.update(srv=srv, dir=carpeta, puerto=puerto)
    return puerto


def parar():
    if _servidor["srv"]:
        _servidor["srv"].shutdown()
        _servidor["srv"].server_close()
        _servidor.update(srv=None, dir=None)
