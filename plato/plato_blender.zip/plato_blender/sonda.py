"""Panorámica de luz: lo que «ve» la cara de la persona en todas direcciones.

Se renderiza con Cycles una imagen equirrectangular pequeña desde el punto de
medida, con la persona oculta. Así entra todo lo que ilumina de verdad: focos,
HDRI, cielo, objetos que emiten y rebotes. Se devuelve como matriz numpy
lineal (alto × ancho × 3) en las unidades de la escena.
"""

import os
import tempfile

import bpy
import numpy as np
from mathutils import Euler

ANCHO, ALTO = 256, 128


def _set(obj, attr, value, saved):
    if hasattr(obj, attr):
        saved.append((obj, attr, getattr(obj, attr)))
        setattr(obj, attr, value)


def panoramica(scene, punto, ocultar=(), muestras=48, ancho=ANCHO, alto=ALTO):
    cam_data = bpy.data.cameras.new("PLATÓ · sonda")
    cam_data.type = "PANO"
    if hasattr(cam_data, "panorama_type"):
        cam_data.panorama_type = "EQUIRECTANGULAR"
    else:  # Blender < 4.0
        cam_data.cycles.panorama_type = "EQUIRECTANGULAR"
    cam = bpy.data.objects.new("PLATÓ · sonda", cam_data)
    scene.collection.objects.link(cam)
    cam.location = punto
    # Cámara mirando a +X del mundo con +Z arriba: el centro de la imagen es +X.
    cam.rotation_euler = Euler((1.5707963, 0, -1.5707963), "XYZ")

    saved = []
    r = scene.render
    _set(scene, "camera", cam, saved)
    _set(r, "engine", "CYCLES", saved)
    _set(r, "resolution_x", ancho, saved)
    _set(r, "resolution_y", alto, saved)
    _set(r, "resolution_percentage", 100, saved)
    _set(r, "use_compositing", False, saved)
    _set(r, "use_sequencer", False, saved)
    _set(r, "film_transparent", False, saved)
    _set(r, "use_border", False, saved)
    _set(scene.cycles, "samples", muestras, saved)
    _set(scene.cycles, "use_denoising", True, saved)
    _set(scene.cycles, "use_adaptive_sampling", True, saved)
    _set(r.image_settings, "file_format", "OPEN_EXR", saved)
    _set(r.image_settings, "color_depth", "32", saved)
    _set(r.image_settings, "color_mode", "RGB", saved)
    for o in ocultar:
        _set(o, "hide_render", True, saved)
    ruta = os.path.join(tempfile.gettempdir(), f"plato_sonda_{os.getpid()}.exr")
    _set(r, "filepath", ruta, saved)
    try:
        bpy.ops.render.render(write_still=True, scene=scene.name)
        img = bpy.data.images.load(ruta, check_existing=False)
        try:
            px = np.empty(len(img.pixels), dtype=np.float32)
            img.pixels.foreach_get(px)
        finally:
            bpy.data.images.remove(img)
        px = px.reshape(alto, ancho, 4)[::-1, :, :3]  # fila 0 = arriba
        return np.nan_to_num(px, nan=0.0, posinf=0.0)
    finally:
        for obj, attr, val in reversed(saved):
            try:
                setattr(obj, attr, val)
            except Exception:
                pass
        bpy.data.objects.remove(cam)
        bpy.data.cameras.remove(cam_data)
        try:
            os.remove(ruta)
        except OSError:
            pass


def direcciones(alto=ALTO, ancho=ANCHO):
    """Dirección en el mundo de cada píxel y su ángulo sólido.

    Con la cámara de arriba: columna central = +X, la imagen crece hacia la
    izquierda en +Y (se comprueba en test_sonda), fila 0 = cénit.
    """
    j = (np.arange(ancho) + 0.5) / ancho
    i = (np.arange(alto) + 0.5) / alto
    lon = (0.5 - j) * 2 * np.pi          # +X en el centro
    lat = (0.5 - i) * np.pi              # +90° arriba
    lon, lat = np.meshgrid(lon, lat)
    d = np.stack([np.cos(lat) * np.cos(lon), np.cos(lat) * np.sin(lon), np.sin(lat)], axis=-1)
    domega = (2 * np.pi / ancho) * (np.pi / alto) * np.cos(lat)
    return d, domega
