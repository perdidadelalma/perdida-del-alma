"""Maniquí de persona para colocar en la escena y medir la luz donde estará el actor.

Una figura hecha de cápsulas (cabeza, tronco, brazos, piernas) con unas poses
básicas. Mira hacia −Y local, que en las escenas del TFG es hacia la cámara.
El punto de medida es un vacío hijo a la altura de la cara.
"""

import math

import bmesh
import bpy
from mathutils import Matrix, Vector

ALTURA_BASE = 1.75

# Articulaciones de una persona de 1,75 m, en metros: x derecha, y fondo, z arriba.
# La cara mira hacia −y.
POSES = {
    "DE_PIE": {
        "cabeza": (0, 0, 1.62), "cuello": (0, 0, 1.50), "pecho": (0, 0, 1.33), "pelvis": (0, 0, 0.97),
        "hombro_i": (-0.19, 0, 1.44), "codo_i": (-0.24, 0.01, 1.17), "mano_i": (-0.26, -0.01, 0.92),
        "hombro_d": (0.19, 0, 1.44), "codo_d": (0.24, 0.01, 1.17), "mano_d": (0.26, -0.01, 0.92),
        "cadera_i": (-0.10, 0, 0.93), "rodilla_i": (-0.11, -0.01, 0.50), "tobillo_i": (-0.11, 0.01, 0.08),
        "punta_i": (-0.11, -0.13, 0.03),
        "cadera_d": (0.10, 0, 0.93), "rodilla_d": (0.11, -0.01, 0.50), "tobillo_d": (0.11, 0.01, 0.08),
        "punta_d": (0.11, -0.13, 0.03),
    },
    "SENTADO": {
        "cabeza": (0, 0.09, 1.19), "cuello": (0, 0.09, 1.07), "pecho": (0, 0.08, 0.92), "pelvis": (0, 0.06, 0.56),
        "hombro_i": (-0.19, 0.08, 1.01), "codo_i": (-0.23, 0.03, 0.78), "mano_i": (-0.20, -0.22, 0.62),
        "hombro_d": (0.19, 0.08, 1.01), "codo_d": (0.23, 0.03, 0.78), "mano_d": (0.20, -0.22, 0.62),
        "cadera_i": (-0.10, 0.05, 0.52), "rodilla_i": (-0.12, -0.38, 0.52), "tobillo_i": (-0.12, -0.44, 0.08),
        "punta_i": (-0.12, -0.56, 0.03),
        "cadera_d": (0.10, 0.05, 0.52), "rodilla_d": (0.12, -0.38, 0.52), "tobillo_d": (0.12, -0.44, 0.08),
        "punta_d": (0.12, -0.56, 0.03),
    },
    "TUMBADO": {  # boca arriba, cabeza hacia +y
        "cabeza": (0, 0.70, 0.12), "cuello": (0, 0.58, 0.11), "pecho": (0, 0.41, 0.13), "pelvis": (0, 0.03, 0.12),
        "hombro_i": (-0.19, 0.50, 0.11), "codo_i": (-0.29, 0.25, 0.07), "mano_i": (-0.31, 0.01, 0.06),
        "hombro_d": (0.19, 0.50, 0.11), "codo_d": (0.29, 0.25, 0.07), "mano_d": (0.31, 0.01, 0.06),
        "cadera_i": (-0.10, -0.01, 0.10), "rodilla_i": (-0.11, -0.44, 0.10), "tobillo_i": (-0.11, -0.86, 0.08),
        "punta_i": (-0.11, -0.91, 0.19),
        "cadera_d": (0.10, -0.01, 0.10), "rodilla_d": (0.11, -0.44, 0.10), "tobillo_d": (0.11, -0.86, 0.08),
        "punta_d": (0.11, -0.91, 0.19),
    },
}

# Más poses, a partir de las de arriba (misma persona de 1,75 m).
def _variante(base, **cambios):
    d = dict(POSES[base])
    d.update(cambios)
    return d


POSES["BRAZOS_ABIERTOS"] = _variante(
    "DE_PIE", codo_i=(-0.46, 0, 1.44), mano_i=(-0.72, 0, 1.45), codo_d=(0.46, 0, 1.44), mano_d=(0.72, 0, 1.45))
POSES["BRAZOS_ARRIBA"] = _variante(
    "DE_PIE", codo_i=(-0.25, 0, 1.71), mano_i=(-0.31, -0.02, 1.97), codo_d=(0.25, 0, 1.71), mano_d=(0.31, -0.02, 1.97))
POSES["ANDAR"] = _variante(
    "DE_PIE", cabeza=(0, -0.02, 1.61), cuello=(0, -0.01, 1.49), pelvis=(0, 0, 0.95),
    codo_i=(-0.23, 0.10, 1.18), mano_i=(-0.25, 0.20, 0.97), codo_d=(0.23, -0.10, 1.18), mano_d=(0.25, -0.20, 0.96),
    cadera_i=(-0.10, 0, 0.92), rodilla_i=(-0.11, -0.20, 0.52), tobillo_i=(-0.11, -0.26, 0.08), punta_i=(-0.11, -0.39, 0.04),
    cadera_d=(0.10, 0, 0.92), rodilla_d=(0.11, 0.08, 0.50), tobillo_d=(0.11, 0.28, 0.12), punta_d=(0.11, 0.20, 0.03))
POSES["CORRER"] = _variante(
    "DE_PIE", cabeza=(0, -0.19, 1.53), cuello=(0, -0.14, 1.42), pecho=(0, -0.08, 1.27), pelvis=(0, 0, 0.92),
    hombro_i=(-0.19, -0.11, 1.37), codo_i=(-0.23, 0.14, 1.20), mano_i=(-0.21, 0.08, 0.99),
    hombro_d=(0.19, -0.11, 1.37), codo_d=(0.23, -0.24, 1.19), mano_d=(0.20, -0.33, 1.40),
    cadera_i=(-0.10, -0.01, 0.89), rodilla_i=(-0.11, -0.38, 0.70), tobillo_i=(-0.11, -0.31, 0.30), punta_i=(-0.11, -0.43, 0.27),
    cadera_d=(0.10, 0.01, 0.89), rodilla_d=(0.11, 0.16, 0.52), tobillo_d=(0.11, 0.49, 0.42), punta_d=(0.11, 0.56, 0.31))
POSES["SUELO"] = {
    "cabeza": (0, 0.05, 0.80), "cuello": (0, 0.06, 0.68), "pecho": (0, 0.07, 0.52), "pelvis": (0, 0.06, 0.16),
    "hombro_i": (-0.19, 0.07, 0.62), "codo_i": (-0.23, 0.02, 0.38), "mano_i": (-0.21, -0.14, 0.24),
    "hombro_d": (0.19, 0.07, 0.62), "codo_d": (0.23, 0.02, 0.38), "mano_d": (0.21, -0.14, 0.24),
    "cadera_i": (-0.10, 0.05, 0.12), "rodilla_i": (-0.32, -0.24, 0.17), "tobillo_i": (0.08, -0.34, 0.07),
    "punta_i": (0.19, -0.37, 0.05),
    "cadera_d": (0.10, 0.05, 0.12), "rodilla_d": (0.32, -0.24, 0.17), "tobillo_d": (-0.08, -0.40, 0.08),
    "punta_d": (-0.19, -0.43, 0.06),
}
POSES["RODILLAS"] = {
    "cabeza": (0, 0, 1.34), "cuello": (0, 0, 1.22), "pecho": (0, 0, 1.05), "pelvis": (0, 0.02, 0.70),
    "hombro_i": (-0.19, 0, 1.16), "codo_i": (-0.24, 0.01, 0.90), "mano_i": (-0.25, -0.02, 0.66),
    "hombro_d": (0.19, 0, 1.16), "codo_d": (0.24, 0.01, 0.90), "mano_d": (0.25, -0.02, 0.66),
    "cadera_i": (-0.10, 0.02, 0.66), "rodilla_i": (-0.11, 0.0, 0.07), "tobillo_i": (-0.11, 0.45, 0.07),
    "punta_i": (-0.11, 0.55, 0.04),
    "cadera_d": (0.10, 0.02, 0.66), "rodilla_d": (0.11, 0.0, 0.07), "tobillo_d": (0.11, 0.45, 0.07),
    "punta_d": (0.11, 0.55, 0.04),
}
POSES["CUCLILLAS"] = {
    "cabeza": (0, -0.08, 0.98), "cuello": (0, -0.05, 0.87), "pecho": (0, 0.0, 0.73), "pelvis": (0, 0.12, 0.42),
    "hombro_i": (-0.19, -0.01, 0.82), "codo_i": (-0.25, -0.20, 0.60), "mano_i": (-0.20, -0.32, 0.45),
    "hombro_d": (0.19, -0.01, 0.82), "codo_d": (0.25, -0.20, 0.60), "mano_d": (0.20, -0.32, 0.45),
    "cadera_i": (-0.11, 0.10, 0.38), "rodilla_i": (-0.17, -0.30, 0.50), "tobillo_i": (-0.13, -0.05, 0.08),
    "punta_i": (-0.13, -0.18, 0.03),
    "cadera_d": (0.11, 0.10, 0.38), "rodilla_d": (0.17, -0.30, 0.50), "tobillo_d": (0.13, -0.05, 0.08),
    "punta_d": (0.13, -0.18, 0.03),
}

NOMBRES_POSE = {"DE_PIE": "De pie", "BRAZOS_ABIERTOS": "Brazos abiertos", "BRAZOS_ARRIBA": "Brazos arriba",
                "ANDAR": "Andando", "CORRER": "Corriendo", "SENTADO": "Sentada", "SUELO": "Sentada en el suelo",
                "RODILLAS": "De rodillas", "CUCLILLAS": "En cuclillas", "TUMBADO": "Tumbada"}
POSE_ITEMS = [(k, v, "") for k, v in NOMBRES_POSE.items()]

# (desde, hasta, radio inicial, radio final)
SEGMENTOS = [
    ("cuello", "cabeza", 0.050, 0.050),
    ("pecho", "cuello", 0.150, 0.060),
    ("pelvis", "pecho", 0.140, 0.155),
    ("hombro_i", "codo_i", 0.048, 0.040), ("codo_i", "mano_i", 0.040, 0.032),
    ("hombro_d", "codo_d", 0.048, 0.040), ("codo_d", "mano_d", 0.040, 0.032),
    ("hombro_i", "hombro_d", 0.055, 0.055),
    ("cadera_i", "rodilla_i", 0.075, 0.055), ("rodilla_i", "tobillo_i", 0.055, 0.040),
    ("cadera_d", "rodilla_d", 0.075, 0.055), ("rodilla_d", "tobillo_d", 0.055, 0.040),
    ("tobillo_i", "punta_i", 0.040, 0.035), ("tobillo_d", "punta_d", 0.040, 0.035),
    ("cadera_i", "cadera_d", 0.080, 0.080),
]
ESFERAS = [("cabeza", 0.110), ("mano_i", 0.045), ("mano_d", 0.045), ("rodilla_i", 0.058),
           ("rodilla_d", 0.058), ("codo_i", 0.042), ("codo_d", 0.042), ("hombro_i", 0.055), ("hombro_d", 0.055)]


def _segmento(bm, a, b, r1, r2):
    a, b = Vector(a), Vector(b)
    eje = b - a
    largo = eje.length
    if largo < 1e-4:
        return
    rot = eje.normalized().to_track_quat("Z", "Y").to_matrix().to_4x4()
    m = Matrix.Translation((a + b) / 2) @ rot
    bmesh.ops.create_cone(bm, cap_ends=True, segments=14, radius1=r1, radius2=r2, depth=largo, matrix=m)
    for p, r in ((a, r1), (b, r2)):
        bmesh.ops.create_uvsphere(bm, u_segments=14, v_segments=8, radius=r, matrix=Matrix.Translation(p))


def malla_persona(pose="DE_PIE", altura=ALTURA_BASE, nombre="Persona"):
    j = {k: Vector(v) * (altura / ALTURA_BASE) for k, v in POSES[pose].items()}
    bm = bmesh.new()
    for a, b, r1, r2 in SEGMENTOS:
        _segmento(bm, j[a], j[b], r1, r2)
    for k, r in ESFERAS:
        bmesh.ops.create_uvsphere(bm, u_segments=16, v_segments=10, radius=r * (1.0 if k != "cabeza" else 1.0),
                                  matrix=Matrix.Translation(j[k]))
    # Nariz: marca hacia dónde mira.
    nariz = j["cabeza"] + Vector((0, -0.105, -0.01)) if pose != "TUMBADO" else j["cabeza"] + Vector((0, 0, 0.105))
    bmesh.ops.create_uvsphere(bm, u_segments=8, v_segments=6, radius=0.025, matrix=Matrix.Translation(nariz))
    me = bpy.data.meshes.new(nombre)
    bm.to_mesh(me)
    bm.free()
    for p in me.polygons:
        p.use_smooth = True
    return me, j


def _material():
    mat = bpy.data.materials.get("PLATÓ · maniquí")
    if mat is None:
        mat = bpy.data.materials.new("PLATÓ · maniquí")
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get("Principled BSDF")
        bsdf.inputs["Base Color"].default_value = (0.55, 0.55, 0.55, 1)
        bsdf.inputs["Roughness"].default_value = 0.7
        mat.diffuse_color = (0.55, 0.55, 0.55, 1)
    return mat


def crear_persona(context, pose="DE_PIE", altura=ALTURA_BASE, ubicacion=(0, 0, 0), giro_z=0.0):
    me, j = malla_persona(pose, altura)
    me.materials.append(_material())
    obj = bpy.data.objects.new(f"Persona · {NOMBRES_POSE[pose]}", me)
    obj["plato_persona"] = True
    obj["plato_pose"] = pose
    obj["plato_altura"] = altura
    context.scene.collection.objects.link(obj)
    obj.location = ubicacion
    obj.rotation_euler = (0, 0, giro_z)
    # Punto de medida: a la altura de la cara, un poco por delante.
    cara = j["cabeza"] + (Vector((0, -0.06, 0)) if pose != "TUMBADO" else Vector((0, 0, 0.06)))
    vacio = bpy.data.objects.new(f"{obj.name} · medida", None)
    vacio.empty_display_type = "SPHERE"
    vacio.empty_display_size = 0.05
    vacio["plato_medida"] = True
    context.scene.collection.objects.link(vacio)
    vacio.parent = obj
    vacio.location = cara
    return obj


def cambiar_pose(obj, pose):
    altura = obj.get("plato_altura", ALTURA_BASE)
    viejo = obj.data
    me, j = malla_persona(pose, altura, viejo.name)
    me.materials.append(_material())
    obj.data = me
    bpy.data.meshes.remove(viejo)
    obj["plato_pose"] = pose
    obj.name = f"Persona · {NOMBRES_POSE[pose]}"
    for hijo in obj.children:
        if hijo.get("plato_medida"):
            hijo.location = j["cabeza"] + (Vector((0, -0.06, 0)) if pose != "TUMBADO" else Vector((0, 0, 0.06)))


ASIENTO = 0.45  # altura del asiento bajo la pose «Sentada» de una persona de 1,75 m
RODILLA = 0.33  # del origen a donde va el filo del asiento (un poco por detrás del centro de la rodilla)


def _abajo(scene, depsgraph, desde, distancia, ignorar):
    """ray_cast hacia abajo que atraviesa a la propia persona."""
    abajo = Vector((0, 0, -1))
    for _ in range(8):
        hit, loc, n, i, o, m = scene.ray_cast(depsgraph, desde, abajo, distance=distancia)
        if not hit or getattr(o, "original", o) is not ignorar:
            return hit, loc
        distancia -= (desde - loc).length + 0.001
        desde = loc + abajo * 0.001
        if distancia <= 0:
            break
    return False, None


def apoyar(obj, punto, scene, depsgraph):
    """Pone a la persona en «punto» (lo que hay bajo el ratón).

    Si está «Sentada» y el punto es un asiento de la escena (una silla, un sofá, un trono: debajo hay
    suelo a más de 25 cm), se baja la persona para que la cadera quede apoyada en él.
    """
    punto = Vector(punto)
    if obj.get("plato_pose") == "SENTADO":
        # Bajar atravesando el grosor del propio asiento (puede tener varias capas) hasta el suelo de debajo.
        desde, suelo = punto, None
        for _ in range(16):
            hit, loc = _abajo(scene, depsgraph, desde + Vector((0, 0, -0.01)), 3.0, obj)
            if not hit:
                break
            if punto.z - loc.z >= 0.25:
                suelo = loc
                break
            desde = loc
        if suelo is not None:
            esc = obj.get("plato_altura", ALTURA_BASE) / ALTURA_BASE
            asiento_z = punto.z
            punto.z -= ASIENTO * esc
            # Como en una silla de verdad: hacia delante hasta que las rodillas queden en el borde
            # del asiento y las piernas cuelguen por fuera (si no, se meterían dentro del asiento).
            delante = frente(obj)
            delante.z = 0
            if delante.length > 1e-6:
                delante.normalize()
                borde = None
                for k in range(1, 61):
                    q = Vector((punto.x, punto.y, asiento_z + 0.3)) + delante * (k * 0.04)
                    hit, loc = _abajo(scene, depsgraph, q, 0.6, obj)
                    if not hit or asiento_z - loc.z > 0.12:
                        borde = (k - 1) * 0.04
                        break
                if borde is not None:
                    punto += delante * (borde - RODILLA * esc)
    obj.location = punto


def punto_medida(obj):
    for hijo in obj.children:
        if hijo.get("plato_medida"):
            return hijo.matrix_world.translation.copy()
    return obj.matrix_world.translation + Vector((0, 0, 1.6))


def frente(obj):
    """Hacia dónde mira la persona (horizontal, en el mundo)."""
    if obj.get("plato_pose") == "TUMBADO":
        v = obj.matrix_world.to_3x3() @ Vector((0, 0, 1))
    else:
        v = obj.matrix_world.to_3x3() @ Vector((0, -1, 0))
    return v.normalized()


def personas(scene):
    return [o for o in scene.objects if o.get("plato_persona")]


def mirar_a_camara(obj, scene):
    cam = scene.camera
    if cam is None:
        return
    d = cam.matrix_world.translation - obj.matrix_world.translation
    d.z = 0
    if d.length < 1e-4:
        return
    # −Y local girado θ queda en (sen θ, −cos θ): tiene que apuntar a la cámara.
    obj.rotation_euler.z = math.atan2(d.x, -d.y)
