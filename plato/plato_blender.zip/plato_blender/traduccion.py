"""De las fuentes medidas en Blender a focos del plató, y de vuelta.

Ida: cada fuente (luz de Blender, zona brillante del HDRI o del decorado,
ambiente) se convierte en un foco real con modificador, distancia, altura,
posición en la planta, potencia en % y temperatura de color o gel.
- La exposición de la cámara fija los lux de la clave: E = 250·N²/(t·ISO).
- El resto de fuentes guardan su proporción con la clave (igual que en Blender).
- El tamaño aparente de la fuente decide el modificador y la distancia:
  misma suavidad = mismo ángulo visto desde la cara.

Vuelta: con la lista de focos (medida o hecha a mano) se crean luces de área
o de foco en Blender que dan esos lux en la cara de la persona.
"""

import math

import bpy
import numpy as np
from mathutils import Vector

from . import analisis, catalogo, maniqui

DIST_MIN = 0.6

# Geles de corrección: (nombre, desplazamiento en mired, luz que dejan pasar)
GELES_CTO = [("1/8 CTO", 20, 0.9), ("1/4 CTO", 42, 0.8), ("1/2 CTO", 81, 0.7), ("3/4 CTO", 112, 0.62),
             ("CTO completo", 159, 0.55)]
GELES_CTB = [("1/8 CTB", -12, 0.83), ("1/4 CTB", -30, 0.7), ("1/2 CTB", -68, 0.55), ("CTB completo", -131, 0.36)]
GELES_COLOR = {"rojo": "Lee 106", "naranja": "Lee 105", "amarillo": "Lee 101", "verde": "Lee 139",
               "cian": "Lee 116", "azul": "Lee 119", "violeta": "Lee 126", "magenta": "Lee 128"}


def lux_clave(t_stop, iso, fps, obturador=180.0):
    """Luz incidente que deja la clave en exposición correcta (fotómetro, C = 250)."""
    t = (obturador / 360.0) / fps
    return 250.0 * t_stop ** 2 / (t * iso)


def pasos(a, b):
    """Diferencia en pasos (stops) de a respecto a b."""
    if a <= 0 or b <= 0:
        return 0.0
    return math.log2(a / b)


# ---------------------------------------------------------------- color

def gel_para(f, kelvin, es_color, color_nombre):
    """Qué hacer con el color: nada, modo RGB, gel de corrección o gel de color.

    Devuelve (texto, luz que deja pasar, cuánto se parece el color de 0 a 1).
    """
    if es_color:
        if f["rgb"]:
            return f"modo RGB/HSI: {color_nombre}", 1.0, 1.0
        return f"gel {color_nombre} ({GELES_COLOR.get(color_nombre, 'de color')})", 0.3, 0.75
    if not kelvin:
        return "", 1.0, 1.0
    k0, k1 = f["k"]
    if k0 <= kelvin <= k1 or f["rgb"] and 1700 <= kelvin <= 20000:
        return f"{round(kelvin / 100) * 100:.0f} K", 1.0, 1.0
    borde = k0 if kelvin < k0 else k1
    mired = 1e6 / kelvin - 1e6 / borde
    if abs(mired) < 15:
        return f"{borde} K (casi igual)", 1.0, 1.0 - abs(mired) / 100
    geles = GELES_CTO if mired > 0 else GELES_CTB
    g = min(geles, key=lambda g: abs(g[1] - mired))
    return f"{borde} K + {g[0]}", g[2], max(0.0, 0.97 - abs(mired - g[1]) / 100)


# ---------------------------------------------------------------- elegir foco

TAM_SUAVE = 0.25  # una fuente de este tamaño o más ya da luz suave (paneles, tubos, mantas)


def es_dura(f, m):
    """Luz dura: sin difusión y con una superficie pequeña (un COB o un fresnel tal cual)."""
    tam = f["tam_m"] if m["id"] in ("NADA", "SPOT") else m["tam_m"]
    return bool(m.get("duro")) and tam < TAM_SUAVE


def opciones(f):
    """Modificadores que admite un foco, con el tamaño de la fuente resultante."""
    for m in catalogo.modificadores():
        if f["tipo"] not in m["para"]:
            continue
        tam = f["tam_m"] if m["id"] in ("NADA", "SPOT") else m["tam_m"]
        yield m, tam


def calcular(fo, dist_max=6.0):
    """Rellena potencia, gel y avisos de un foco ya elegido (también tras editarlo a mano)."""
    f = catalogo.foco(fo["foco_id"])
    if f is None:
        fo.update(pct=0.0, gel="", aviso="no queda equipo para esta luz" if not fo["foco_id"] else "foco desconocido")
        fo["parecido"], fo["partes"] = parecido(fo, dist_max)
        return fo
    if f["tipo"] == "Pasivo":
        fo.update(mod="NADA", pct=0.0, gel="", aviso="")
        fo["aviso"] = f"acércalo o aléjalo hasta que el fotómetro marque {fo['lux']:.0f} lux en la cara"
        fo["parecido"], fo["partes"] = parecido(fo, dist_max)
        return fo
    m = catalogo.modificador(fo["mod"])
    if f["tipo"] not in m["para"]:
        m = catalogo.modificador("NADA")
        fo["mod"] = "NADA"
    gel, paso_gel, _c = gel_para(f, fo.get("kelvin"), fo.get("es_color", False), fo.get("color_nombre", ""))
    sale = f["lux_1m"] * m["factor"] * paso_gel
    fo["gel"] = gel
    fo["pct"] = 100.0 * fo["lux"] * fo["dist"] ** 2 / max(sale, 1e-6)
    avisos = []
    if fo["pct"] > 100:
        falta = pasos(fo["pct"], 100)
        avisos.append(f"no llega: le falta {falta:.1f} pasos; acércalo, quita difusión o abre diafragma")
    elif fo["pct"] < 3 and f["tipo"] not in ("Práctico", "Mini"):
        avisos.append("sobra mucho: aléjalo o usa uno más pequeño")
    if fo["dist"] > dist_max + 0.01:
        avisos.append(f"más lejos de {dist_max:.1f} m: no cabe en el plató")
    alt = fo.get("altura")
    if alt is not None and alt > 3.6:
        avisos.append("más alto que un pie normal: jirafa, parrilla o escalera")
    fo["aviso"] = "; ".join(avisos)
    fo["parecido"], fo["partes"] = parecido(fo, dist_max)
    return fo


# ---------------------------------------------------------------- parecido con Blender

def tam_real(fo):
    """Tamaño aparente (grados) del foco elegido visto desde la cara."""
    f = catalogo.foco(fo["foco_id"])
    m = catalogo.modificador(fo["mod"])
    lado = f["tam_m"] if m["id"] in ("NADA", "SPOT") else m["tam_m"]
    return math.degrees(2 * math.atan2(lado / 2, max(fo["dist"], 0.05)))


def parecido(fo, dist_max=6.0):
    """Cuánto se parece (0 a 1) lo que da este foco a la luz que había en Blender, y por qué.

    Intensidad (si llega a los lux), suavidad (mismo tamaño aparente), color (temperatura o gel) y sitio.
    Un foco puesto a mano no tiene con qué compararse: None.
    """
    if fo.get("origen") == "manual":
        return None, {}
    f = catalogo.foco(fo["foco_id"])
    if f is None:
        return 0.0, {"intensidad": 0.0, "suavidad": 0.0, "color": 0.0, "sitio": 0.0}
    if f["tipo"] == "Pasivo":
        partes = {"intensidad": 0.8, "suavidad": 1.0, "color": 1.0, "sitio": 1.0}
    else:
        pct = fo.get("pct", 0.0)
        inten = 1.0 if pct <= 100 else max(0.0, 1.0 - pasos(pct, 100) / 2)
        objetivo = fo.get("tam") or 0.0
        m = catalogo.modificador(fo["mod"])
        if objetivo < 4.0:
            suav = 1.0 if es_dura(f, m) else 0.55
        else:
            real = tam_real(fo)
            suav = (min(real, objetivo) / max(real, objetivo, 1.0)) ** 0.5
        _g, _p, color = gel_para(f, fo.get("kelvin"), fo.get("es_color", False), fo.get("color_nombre", ""))
        sitio = 1.0
        if fo["dist"] > dist_max + 0.01:
            sitio -= 0.15
        if (fo.get("altura") or 0) > 3.6:
            sitio -= 0.1
        partes = {"intensidad": inten, "suavidad": suav, "color": color, "sitio": sitio}
    total = 0.4 * partes["intensidad"] + 0.25 * partes["suavidad"] + 0.25 * partes["color"] + 0.1 * partes["sitio"]
    return total, partes


def parecido_total(focos):
    """Media del parecido pesada por los lux de cada luz (las que más se ven, mandan). None si no hay medida.

    Una luz desmarcada cuenta como 0: es luz de Blender que no se va a montar.
    """
    medidos = [fo for fo in focos if fo.get("parecido") is not None]
    peso = sum(fo["lux"] for fo in medidos)
    if not medidos or peso <= 0:
        return None
    return sum(fo["parecido"] * fo["lux"] * (1 if fo.get("activo", True) else 0) for fo in medidos) / peso


def _como_fuente(fo):
    fu = {"tam": fo.get("tam"), "elev": fo["elev"], "kelvin": fo.get("kelvin"), "es_color": fo.get("es_color"),
          "color_nombre": fo.get("color_nombre", ""), "haz": None}
    if fo.get("origen") == "ambiente":
        fu.update(mods=["REBOTE", "MARCO6", "TECHO"], d_fijo=2.5)
    return fu


def que_me_falta(focos, dist_max=6.0, alt_cara=1.6, cuantos=3):
    """Qué foco del catálogo, si lo tuviéramos, subiría más el parecido total.

    Devuelve [(foco_id, puntos que sube el % total, [papeles que mejora])], de más a menos útil.
    """
    medidos = [fo for fo in focos if fo.get("parecido") is not None and fo.get("activo", True)]
    peso = sum(fo["lux"] for fo in medidos)
    if peso <= 0:
        return []
    mejoras = {}
    for fo in medidos:
        f = catalogo.foco(fo["foco_id"])
        if fo["parecido"] >= 0.9 or (f and f["tipo"] == "Pasivo"):
            continue
        e = elegir(_como_fuente(fo), fo["lux"], fo.get("dist_blender"), dist_max, None, alt_cara)
        if e is None:
            continue
        nuevo = calcular(dict(fo, **e), dist_max)
        ganancia = (nuevo["parecido"] - fo["parecido"]) * fo["lux"] / peso * 100
        if ganancia < 0.5:
            continue
        g, roles = mejoras.get(e["foco_id"], (0.0, []))
        mejoras[e["foco_id"]] = (g + ganancia, roles + [fo["rol"]])
    orden = sorted(mejoras.items(), key=lambda kv: -kv[1][0])[:cuantos]
    return [(fid, g, roles) for fid, (g, roles) in orden]


def elegir(fuente, lux, dist_blender, dist_max=6.0, inventario=None, alt_cara=1.6):
    """El mejor foco y modificador para dar «lux» con la suavidad de la fuente.

    «inventario»: ids de los focos que se pueden usar (None = todo el catálogo).
    """
    if fuente.get("pasivo"):
        return {"foco_id": "reflector_pasivo", "mod": "NADA", "dist": round(min(1.0, dist_max), 2)}
    tam = fuente.get("tam") or 0.0
    if fuente["elev"] < -3:  # viene de abajo: el foco no puede quedar bajo el suelo
        dist_max = min(dist_max, max(DIST_MIN, (alt_cara - 0.1) / math.sin(math.radians(-fuente["elev"]))))
    mods_validos = fuente.get("mods")
    duro = tam < 4.0
    mejor = None
    lista = [f for f in catalogo.focos() if inventario is None or f["id"] in inventario]
    for f in lista:
        gel, paso_gel, _c = gel_para(f, fuente.get("kelvin"), fuente.get("es_color", False), fuente.get("color_nombre", ""))
        for m, tam_m in opciones(f):
            if duro != es_dura(f, m) or (mods_validos and m["id"] not in mods_validos) or f["tipo"] == "Pasivo":
                continue
            if fuente.get("d_fijo"):
                d = d_ideal = fuente["d_fijo"]
            elif duro:
                d = dist_blender if dist_blender else 3.0
                d_ideal = d
            else:
                d_ideal = tam_m / (2 * math.tan(math.radians(min(tam, 170)) / 2))
                d = d_ideal
            d = min(max(d, DIST_MIN), dist_max)
            sale = f["lux_1m"] * m["factor"] * paso_gel
            pct = 100.0 * lux * d * d / max(sale, 1e-6)
            coste = 3.0 * abs(math.log(d / max(d_ideal, 1e-3)))  # suavidad distinta a la de Blender
            coste += 10.0 + pasos(pct, 100) if pct > 100 else 0.0
            coste += 1.0 if pct < 8 else 0.0
            coste += max(0.0, pct - 85) / 30 if pct <= 100 else 0.0  # sin margen para subir en el plató
            coste += f["w"] / 1500.0  # a igualdad, el más pequeño
            if fuente.get("es_color") and not f["rgb"]:
                coste += 0.6
            if m["id"] == "SPOT" and (fuente.get("haz") or 90) > 30:
                coste += 0.5
            if f["tipo"] == "Práctico":
                coste += 2.0  # solo si no hay otra cosa (o si está en el inventario)
            if mejor is None or coste < mejor[0]:
                mejor = (coste, f, m, d)
    if mejor is None:
        return None
    _c, f, m, d = mejor
    return {"foco_id": f["id"], "mod": m["id"], "dist": round(d, 2)}


# ---------------------------------------------------------------- ida: medida → plató

def _ambiente_como_fuentes(ambiente, E_ref):
    sale = []
    for clave, rol, az, el in (("horizonte", "Relleno de ambiente", 0.0, 8.0), ("cielo", "Ambiente cenital", 0.0, 70.0),
                              ("suelo", "Rebote de suelo", 0.0, -35.0)):
        a = ambiente.get(clave)
        if not a or a["E"] < 0.08 * E_ref:
            continue
        k, color, nombre = analisis.kelvin_de_rgb(a["rgb"])
        sale.append({"origen": "ambiente", "nombre": clave, "rol": rol, "E": a["E"], "azim": az, "elev": el,
                     "tam": 100.0, "dist": None, "kelvin": k, "es_color": color, "color_nombre": nombre,
                     "rgb": a["rgb"], "haz": None, "mods": ["REBOTE", "MARCO6", "TECHO"], "d_fijo": 2.5,
                     "pasivo": clave == "suelo"})
    return sale


def traducir(medida, t_stop=2.8, iso=800, fps=25, obturador=180, dist_max=6.0, inventario=None, alt_cara=1.6):
    """Lista de focos del plató a partir de analisis.medir().

    «inventario»: {id: cuántos tenemos} para usar solo nuestro equipo (None = todo el catálogo).
    Se reparte de la luz más fuerte a la más floja; si se acaba el equipo, la luz queda sin foco.
    """
    quedan = dict(inventario) if inventario is not None else None
    fuentes = [f for f in medida["fuentes"] if f["E"] > 0]
    if not fuentes and medida["ambiente"]["E"] <= 0:
        return [], 0.0, 0.0
    clave = next((f for f in fuentes if f["rol"].startswith("Clave")), fuentes[0] if fuentes else None)
    E_clave = clave["E"] if clave else medida["ambiente"]["E"]
    L_clave = lux_clave(t_stop, iso, fps, obturador)
    todas = fuentes + _ambiente_como_fuentes(medida["ambiente"], E_clave)
    todas.sort(key=lambda f: -f["E"])
    focos = []
    for fu in todas:
        lux = L_clave * fu["E"] / E_clave
        if lux < 0.03 * L_clave:
            continue  # menos de 1/32 de la clave: no se nota
        if fu["origen"] == "entorno" and fu["rol"] == "Rebote de suelo":
            fu["pasivo"] = True
        disponibles = None if quedan is None else {k for k, v in quedan.items() if v > 0}
        eleccion = elegir(fu, lux, fu.get("dist"), dist_max, disponibles, alt_cara)
        if eleccion is None:
            eleccion = {"foco_id": "", "mod": "NADA", "dist": 2.5}
        elif quedan is not None and eleccion["foco_id"] in quedan:
            quedan[eleccion["foco_id"]] -= 1
        rgb = np.asarray(fu.get("rgb", (1, 1, 1)), dtype=float)
        fo = {"rol": fu["rol"], "fuente": fu.get("nombre") or ("entorno" if fu["origen"] == "entorno" else fu["origen"]),
              "origen": fu["origen"], "azim": round(float(fu["azim"]), 1), "elev": round(float(fu["elev"]), 1),
              "lux": round(lux, 1), "tam": round(float(fu.get("tam") or 0), 1), "kelvin": fu.get("kelvin"),
              "es_color": bool(fu.get("es_color")), "color_nombre": fu.get("color_nombre", ""),
              "rgb": tuple(float(c) for c in rgb / max(rgb.max(), 1e-9)), "dist_blender": fu.get("dist"), **eleccion}
        focos.append(fo)
    focos.sort(key=lambda f: -f["lux"])
    for n, fo in enumerate(focos, 1):
        fo["n"] = n
    ref = E_clave / L_clave  # W/m² de Blender por lux real
    return focos, L_clave, ref


# ---------------------------------------------------------------- geometría

def ejes(scene, persona):
    """Cara de la persona, dirección a cámara (horizontal) y derecha de cuadro."""
    F = maniqui.punto_medida(persona)
    cam = scene.camera
    c = (cam.matrix_world.translation - F) if cam else maniqui.frente(persona)
    c = Vector((c.x, c.y, 0))
    c = c.normalized() if c.length > 1e-6 else Vector((0, -1, 0))
    derecha = Vector((-c.y, c.x, 0))
    return F, c, derecha


def direccion(fo, c, derecha):
    az, el = math.radians(fo["azim"]), math.radians(fo["elev"])
    return (c * math.cos(az) + derecha * math.sin(az)) * math.cos(el) + Vector((0, 0, math.sin(el)))


def colocar(fo, F, c, derecha, suelo):
    """Posición en la planta (x a la derecha de cuadro, y hacia cámara), altura y hora del reloj."""
    d = fo["dist"]
    az, el = math.radians(fo["azim"]), math.radians(fo["elev"])
    en_suelo = d * math.cos(el)
    fo["x"] = round(en_suelo * math.sin(az), 2)
    fo["y"] = round(en_suelo * math.cos(az), 2)
    fo["en_suelo"] = round(en_suelo, 2)
    fo["altura"] = round(F.z - suelo + d * math.sin(el), 2)
    hora = (6 - fo["azim"] / 30.0) % 12
    hora = round(hora * 2) / 2 or 12
    fo["hora"] = hora
    return F + direccion(fo, c, derecha) * d


def hora_texto(h):
    if h is None:
        return ""
    entera = int(h) or 12
    return f"a las {entera} y media" if h % 1 else f"a las {entera}"


def lado_texto(az):
    a = abs(az)
    if a < 15:
        lado = "desde cámara"
    elif a > 165:
        lado = "justo detrás"
    else:
        lado = ("derecha" if az > 0 else "izquierda") + " de cuadro"
        if a > 100:
            lado += ", por detrás"
    return lado


# ---------------------------------------------------------------- vuelta: plató → Blender

COLECCION = "PLATÓ · focos"


def _coleccion(scene):
    col = bpy.data.collections.get(COLECCION)
    if col is None:
        col = bpy.data.collections.new(COLECCION)
    if col.name not in scene.collection.children:
        scene.collection.children.link(col)
    return col


def _lum(rgb):
    return 0.2126 * rgb[0] + 0.7152 * rgb[1] + 0.0722 * rgb[2]


def crear_en_blender(scene, persona, focos, ref):
    """Borra los focos de PLATÓ anteriores y crea uno por cada foco de la lista."""
    col = _coleccion(scene)
    for o in list(col.objects):
        datos = o.data
        bpy.data.objects.remove(o)
        if datos is not None and datos.users == 0:
            bpy.data.lights.remove(datos)
    F, c, derecha = ejes(scene, persona)
    suelo = persona.matrix_world.translation.z
    hechos = []
    for fo in focos:
        if not fo.get("activo", True):
            continue
        f = catalogo.foco(fo["foco_id"])
        m = catalogo.modificador(fo["mod"])
        if f is None:
            continue
        pos = colocar(fo, F, c, derecha, suelo)
        d = fo["dist"]
        if fo.get("es_color"):
            rgb = np.asarray(fo["rgb"], dtype=float)
        else:
            rgb = analisis.blackbody_rgb(fo.get("kelvin") or 5600)
        rgb = rgb / max(rgb.max(), 1e-9)
        E = fo["lux"] * ref / max(_lum(rgb), 1e-3)
        nombre = f"PLATÓ {fo['n']} · {fo['rol']}"
        if m.get("duro") and f["tipo"] not in ("Panel", "Tubo"):
            luz = bpy.data.lights.new(nombre, "SPOT")
            haz = f["haz"] / (3.0 if m["id"] == "SPOT" else 1.0)
            luz.spot_size = math.radians(min(max(haz, 5), 170))
            luz.spot_blend = 0.3
            luz.shadow_soft_size = f["tam_m"] / 2
            luz.energy = E * 4 * math.pi * d * d
        else:
            luz = bpy.data.lights.new(nombre, "AREA")
            tam = f["tam_m"] if m["id"] in ("NADA", "SPOT") else m["tam_m"]
            if f["tipo"] == "Tubo" and m["id"] == "NADA":
                luz.shape, luz.size, luz.size_y = "RECTANGLE", 0.04, tam
            elif m["id"] in ("OCTA90", "LINTERNA"):
                luz.shape, luz.size = "DISK", tam
            else:
                luz.shape, luz.size = "SQUARE", tam
            luz.energy = E * math.pi * d * d
        luz.color = tuple(rgb)
        obj = bpy.data.objects.new(nombre, luz)
        obj["plato_foco"] = True
        obj["plato_n"] = fo["n"]
        col.objects.link(obj)
        obj.location = pos
        obj.rotation_euler = (F - pos).to_track_quat("-Z", "Y").to_euler()
        hechos.append(obj)
    return hechos


def nuevo_foco_manual(foco_id, n, lux_clave_, kelvin=None):
    """Un foco puesto a mano desde el buscador: de partida, clave a 45° y 30° de alto."""
    f = catalogo.foco(foco_id)
    k = kelvin or (f["k"][0] if f["k"][0] == f["k"][1] else 5600)
    return {"n": n, "rol": "Clave" if n == 1 else "Foco", "fuente": "a mano", "origen": "manual",
            "azim": 45.0 if n % 2 else -45.0, "elev": 30.0, "lux": round(lux_clave_ if n == 1 else lux_clave_ / 2, 1),
            "tam": 0.0, "kelvin": k, "es_color": False, "color_nombre": "", "rgb": (1.0, 1.0, 1.0),
            "foco_id": foco_id, "mod": "NADA", "dist": 2.5}
