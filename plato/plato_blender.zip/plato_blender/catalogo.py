"""Catálogo de focos reales y modificadores, con buscador.

El catálogo general va en catalogo.json. Los focos que tenga el plató de verdad
(o medidas propias con fotómetro) van en ~/PLATO/catalogo_propio.json con la
misma forma; si un id se repite, manda el propio.
"""

import json
import os
import unicodedata

AQUI = os.path.dirname(__file__)
PROPIO = os.path.join(os.path.expanduser("~"), "PLATO", "catalogo_propio.json")

_cache = {"mtime": None, "focos": [], "mods": [], "nota": ""}


def _leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


def cargar(forzar=False):
    rutas = [os.path.join(AQUI, "catalogo.json")] + ([PROPIO] if os.path.exists(PROPIO) else [])
    mtime = tuple(os.path.getmtime(r) for r in rutas)
    if not forzar and _cache["mtime"] == mtime:
        return _cache
    base = _leer(rutas[0])
    focos = {f["id"]: dict(f, propio=False) for f in base["focos"]}
    mods = {m["id"]: m for m in base["modificadores"]}
    if len(rutas) > 1:
        try:
            propio = _leer(rutas[1])
            for f in propio.get("focos", []):
                focos[f["id"]] = dict(f, propio=True)
            for m in propio.get("modificadores", []):
                mods[m["id"]] = m
        except (OSError, ValueError) as e:
            print("PLATÓ: no se pudo leer", PROPIO, e)
    _cache.update(mtime=mtime, focos=list(focos.values()), mods=list(mods.values()), nota=base.get("nota", ""))
    return _cache


def focos():
    return cargar()["focos"]


def modificadores():
    return cargar()["mods"]


def foco(fid):
    return next((f for f in focos() if f["id"] == fid), None)


def modificador(mid):
    return next((m for m in modificadores() if m["id"] == mid), modificadores()[0])


def nombre(f):
    return f"{f['marca']} {f['modelo']}" if f["marca"] not in ("Genérico", "Práctico", "Pasivo") else f["modelo"]


def _plano(t):
    t = unicodedata.normalize("NFD", t.lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def etiquetas(f):
    if f["tipo"] == "Pasivo":
        return ["Pasivo", "sin corriente"]
    e = [f["tipo"], f"{f['w']} W"]
    k0, k1 = f["k"]
    e.append("RGB" if f["rgb"] else (f"{k0} K" if k0 == k1 else f"bicolor {k0}–{k1} K"))
    if f.get("bateria"):
        e.append("batería")
    if f.get("bowens"):
        e.append("Bowens")
    if f.get("propio"):
        e.append("propio")
    return e


def buscar(texto="", tipos=None, solo_rgb=False):
    """Busca por palabras en marca, modelo, tipo y etiquetas (sin tildes ni mayúsculas)."""
    palabras = _plano(texto).split()
    res = []
    for f in focos():
        if tipos and f["tipo"] not in tipos:
            continue
        if solo_rgb and not f["rgb"]:
            continue
        hay = _plano(" ".join([f["marca"], f["modelo"], f["accesorio"]] + etiquetas(f)))
        if all(p in hay for p in palabras):
            res.append(f)
    return sorted(res, key=lambda f: (f["tipo"], f["w"]))


def items_enum(_self=None, _context=None):
    """Para el desplegable con buscador de Blender (invoke_search_popup)."""
    global _items
    _items = [(f["id"], f"{nombre(f)}  ·  {' · '.join(etiquetas(f))}", f["accesorio"]) for f in buscar()]
    return _items


_items = []


def items_mods(_self=None, _context=None):
    global _items_m
    _items_m = [(m["id"], m["nombre"], "") for m in modificadores()]
    return _items_m


_items_m = []


# ---------------------------------------------------------------- mi equipo

def _leer_propio():
    if os.path.exists(PROPIO):
        try:
            return _leer(PROPIO)
        except (OSError, ValueError):
            pass
    return {}


def _guardar_propio(datos):
    os.makedirs(os.path.dirname(PROPIO), exist_ok=True)
    tmp = PROPIO + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    os.replace(tmp, PROPIO)
    cargar(forzar=True)


def equipo():
    """Lo que tenemos: [{"id", "cantidad"}] (solo los que existen en el catálogo)."""
    ids = {f["id"] for f in focos()}
    return [e for e in _leer_propio().get("equipo", []) if e.get("id") in ids]


def equipo_dict():
    return {e["id"]: int(e.get("cantidad", 1)) for e in equipo()}


def poner_en_equipo(fid, cantidad=None, sumar=0):
    datos = _leer_propio()
    lista = datos.setdefault("equipo", [])
    e = next((x for x in lista if x["id"] == fid), None)
    if e is None:
        e = {"id": fid, "cantidad": 0}
        lista.append(e)
    e["cantidad"] = max(0, int(cantidad if cantidad is not None else e["cantidad"] + sumar))
    if e["cantidad"] == 0:
        lista.remove(e)
    _guardar_propio(datos)


def nuevo_foco_propio(f, cantidad=1):
    """Un foco que no está en el catálogo: se guarda con sus datos y entra en el equipo."""
    datos = _leer_propio()
    base = "".join(c if c.isalnum() else "_" for c in _plano(f"{f['marca']} {f['modelo']}")).strip("_") or "foco"
    ids = {x["id"] for x in focos()}
    fid, k = base, 2
    while fid in ids:
        fid, k = f"{base}_{k}", k + 1
    f = dict(f, id=fid)
    datos.setdefault("focos", []).append(f)
    datos.setdefault("equipo", []).append({"id": fid, "cantidad": int(cantidad)})
    _guardar_propio(datos)
    return fid
