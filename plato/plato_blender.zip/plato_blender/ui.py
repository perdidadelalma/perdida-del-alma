"""Panel «Plató» de la vista 3D, sus propiedades y operadores.

Flujo: colocar la persona con un clic → medir la luz → lista de focos del plató
(se puede editar: cambiar de foco con el buscador, modificador, distancia…)
→ hoja de plató (imprimir / tablet) o crear esos focos en Blender.
También al revés: añadir focos a mano desde el catálogo y crearlos en Blender.
"""

import math
import os
import webbrowser

import bpy
import bpy.utils.previews
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty,
                       IntProperty, PointerProperty, StringProperty)
from bpy_extras import view3d_utils
from mathutils import Vector

from . import analisis, catalogo, hoja, maniqui, traduccion as tr

VERSION = "0.2.0"
CREDIT = "por Toniño · Pérdida del Alma"
INSTAGRAM = "https://www.instagram.com/perdidadelalma/"
WEB = "https://perdidadelalma.github.io/perdida-del-alma/"
DOCS = os.path.join(os.path.dirname(__file__), "docs", "instrucciones.html")

_previews = None
_ultima = {}  # última medida por escena (panorámica para la hoja)


def icon(name):
    if _previews is None:
        return 0
    for key in (name, f"i_{name}"):
        if key in _previews:
            return _previews[key].icon_id
    return 0


def load_icons():
    global _previews
    _previews = bpy.utils.previews.new()
    carpeta = os.path.join(os.path.dirname(__file__), "icons")
    if os.path.isdir(carpeta):
        for f in os.listdir(carpeta):
            if f.endswith(".png"):
                _previews.load(os.path.splitext(f)[0], os.path.join(carpeta, f), "IMAGE")


def free_icons():
    global _previews
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None


def osd(layout, text, icon_name=None, alert=False):
    row = layout.row()
    row.alert = alert
    if icon_name and icon(icon_name):
        row.label(text=text.upper(), icon_value=icon(icon_name))
    else:
        row.label(text=text.upper())


# ---------------------------------------------------------------- propiedades

def _recalcular(self, context):
    s = context.scene.plato
    if s.bloqueo:
        return
    fo = foco_a_dict(self)
    tr.calcular(fo, s.dist_max)
    s.bloqueo = True
    try:
        self.pct, self.gel, self.aviso = fo["pct"], fo["gel"], fo["aviso"]
        self.mod = fo["mod"]
        self.parecido = -1.0 if fo.get("parecido") is None else fo["parecido"]
        self.partes = _partes_texto(fo.get("partes"))
    finally:
        s.bloqueo = False


class PLATO_Foco(bpy.types.PropertyGroup):
    n: IntProperty()
    rol: StringProperty(name="Papel")
    fuente: StringProperty()
    origen: StringProperty()
    foco_id: StringProperty(update=_recalcular)
    mod: EnumProperty(name="Modificador", items=catalogo.items_mods, update=_recalcular)
    dist: FloatProperty(name="Distancia", unit="LENGTH", min=0.3, max=30, update=_recalcular)
    azim: FloatProperty(name="Ángulo desde cámara", description="0 = desde cámara, +90 = derecha de cuadro, 180 = detrás",
                        min=-180, max=180)
    elev: FloatProperty(name="Altura (grados)", min=-80, max=90)
    lux: FloatProperty(name="Lux en la cara", min=0, update=_recalcular)
    tam: FloatProperty()
    kelvin: FloatProperty(name="Kelvin", min=1000, max=25000, update=_recalcular)
    es_color: BoolProperty(name="De color", update=_recalcular)
    color_nombre: StringProperty()
    rgb: FloatVectorProperty(subtype="COLOR", min=0, max=1, size=3, default=(1, 1, 1))
    pct: FloatProperty()
    gel: StringProperty()
    aviso: StringProperty()
    activo: BoolProperty(name="Usar", default=True, update=_recalcular)
    parecido: FloatProperty(default=-1.0, description="Cuánto se parece a la luz de Blender (0–1; −1 si no hay medida)")
    partes: StringProperty()
    dist_blender: FloatProperty(default=0.0)


def _partes_texto(partes):
    if not partes:
        return ""
    return " · ".join(f"{k} {v * 100:.0f}" for k, v in partes.items())


def foco_a_dict(p):
    return {"n": p.n, "rol": p.rol, "fuente": p.fuente, "origen": p.origen, "foco_id": p.foco_id, "mod": p.mod,
            "dist": p.dist, "azim": p.azim, "elev": p.elev, "lux": p.lux, "tam": p.tam,
            "kelvin": p.kelvin or None, "es_color": p.es_color, "color_nombre": p.color_nombre,
            "rgb": tuple(p.rgb), "pct": p.pct, "gel": p.gel, "aviso": p.aviso, "activo": p.activo,
            "parecido": None if p.parecido < 0 else p.parecido, "dist_blender": p.dist_blender or None}


def dict_a_foco(d, p, s):
    s.bloqueo = True
    try:
        for k in ("n", "rol", "fuente", "origen", "foco_id", "mod", "dist", "azim", "elev", "lux", "tam",
                  "es_color", "color_nombre", "pct", "gel", "aviso"):
            if k in d and d[k] is not None:
                setattr(p, k, d[k])
        p.kelvin = d.get("kelvin") or 5600
        p.parecido = -1.0 if d.get("parecido") is None else d["parecido"]
        p.partes = _partes_texto(d.get("partes"))
        p.dist_blender = d.get("dist_blender") or 0.0
        p.rgb = d.get("rgb", (1, 1, 1))
        p.activo = d.get("activo", True)
    finally:
        s.bloqueo = False


def _items_personas(self, context):
    return [(o.name, o.name, "") for o in maniqui.personas(context.scene)] or [("", "(sin persona)", "")]


class PLATO_Ajustes(bpy.types.PropertyGroup):
    pose: EnumProperty(name="Pose", items=maniqui.POSE_ITEMS, default="DE_PIE")
    altura: FloatProperty(name="Estatura", default=1.75, min=0.5, max=2.3, unit="LENGTH")
    t_stop: FloatProperty(name="T", default=2.8, min=0.7, max=32, step=10, precision=1,
                          description="Diafragma (T-stop) al que vais a rodar")
    iso: IntProperty(name="ISO", default=800, min=50, max=25600)
    fps: FloatProperty(name="fps", default=25, min=1, max=240)
    obturador: FloatProperty(name="Obturador", default=180, min=1, max=360, description="Ángulo de obturación en grados")
    dist_max: FloatProperty(name="Distancia máxima", default=6.0, min=1, max=30, unit="LENGTH",
                            description="Lo más lejos que cabe un foco de la persona en vuestro plató")
    solo_inventario: BoolProperty(name="Solo mi equipo",
                                  description="Elegir solo entre los focos de «Mi equipo», respetando cuántos hay de cada uno")
    muestras: IntProperty(name="Muestras de la sonda", default=48, min=8, max=512)
    focos: CollectionProperty(type=PLATO_Foco)
    activo: IntProperty()
    lux_clave: FloatProperty()
    ref: FloatProperty(default=0.0, description="W/m² de Blender por lux real")
    medida_de: StringProperty()
    bloqueo: BoolProperty()
    url_tablet: StringProperty()


def ajustes(context):
    return context.scene.plato


def persona_activa(context):
    o = context.active_object
    if o is not None:
        if o.get("plato_persona"):
            return o
        if o.parent is not None and o.parent.get("plato_persona"):
            return o.parent
    s = ajustes(context)
    pers = maniqui.personas(context.scene)
    return next((p for p in pers if p.name == s.medida_de), pers[0] if pers else None)


# ---------------------------------------------------------------- operadores: persona

class PLATO_OT_colocar(bpy.types.Operator):
    """Pon a la persona en la escena con un clic. Rueda: girar · Clic izquierdo: dejar · Esc: cancelar"""
    bl_idname = "plato.colocar"
    bl_label = "Colocar persona"
    bl_options = {"REGISTER", "UNDO"}

    pose: EnumProperty(name="Pose", items=maniqui.POSE_ITEMS)

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == "VIEW_3D"

    def _mover(self, context, event):
        region, rv3d = context.region, context.region_data
        coord = (event.mouse_region_x, event.mouse_region_y)
        origen = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
        rayo = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
        dg = context.evaluated_depsgraph_get()
        hit, loc, normal, _i, obj, _m = context.scene.ray_cast(dg, origen, rayo)
        if not hit or normal.z < 0.5:  # paredes y techos no: al suelo (z = 0)
            if abs(rayo.z) > 1e-6:
                t = -origen.z / rayo.z
                loc = origen + rayo * t if t > 0 else None
            else:
                loc = None
        if loc is not None:
            maniqui.apoyar(self.obj, loc, context.scene, dg)

    def invoke(self, context, event):
        s = ajustes(context)
        self.obj = maniqui.crear_persona(context, self.pose, s.altura)
        for o in context.selected_objects:
            o.select_set(False)
        self.obj.select_set(True)
        context.view_layer.objects.active = self.obj
        self.obj.hide_select = True  # que el rayo no choque con ella misma
        self.obj.display_type = "WIRE"
        maniqui.mirar_a_camara(self.obj, context.scene)
        self.giro_extra = 0.0
        self._mover(context, event)
        context.window_manager.modal_handler_add(self)
        context.area.header_text_set("PLATÓ · Clic: dejar aquí · Rueda: girar · C: mirar a cámara · Esc: cancelar")
        return {"RUNNING_MODAL"}

    def _fin(self, context):
        context.area.header_text_set(None)
        self.obj.hide_select = False
        self.obj.display_type = "TEXTURED"

    def modal(self, context, event):
        if event.type == "MOUSEMOVE":
            self._mover(context, event)
        elif event.type in {"WHEELUPMOUSE", "WHEELDOWNMOUSE"}:
            self.obj.rotation_euler.z += math.radians(15 if event.type == "WHEELUPMOUSE" else -15)
        elif event.type == "C" and event.value == "PRESS":
            maniqui.mirar_a_camara(self.obj, context.scene)
        elif event.type == "LEFTMOUSE" and event.value == "PRESS":
            self._fin(context)
            ajustes(context).medida_de = self.obj.name
            return {"FINISHED"}
        elif event.type in {"RIGHTMOUSE", "ESC"} and event.value == "PRESS":
            self._fin(context)
            for h in list(self.obj.children):
                bpy.data.objects.remove(h)
            me = self.obj.data
            bpy.data.objects.remove(self.obj)
            bpy.data.meshes.remove(me)
            return {"CANCELLED"}
        else:
            return {"PASS_THROUGH"} if event.type in {"MIDDLEMOUSE", "TRACKPADPAN", "TRACKPADZOOM"} else {"RUNNING_MODAL"}
        return {"RUNNING_MODAL"}


class PLATO_OT_pose(bpy.types.Operator):
    """Cambia la pose de la persona seleccionada"""
    bl_idname = "plato.pose"
    bl_label = "Cambiar pose"
    bl_options = {"REGISTER", "UNDO"}
    pose: EnumProperty(name="Pose", items=maniqui.POSE_ITEMS)

    def execute(self, context):
        p = persona_activa(context)
        if p is None:
            self.report({"WARNING"}, "Primero coloca una persona")
            return {"CANCELLED"}
        maniqui.cambiar_pose(p, self.pose)
        return {"FINISHED"}


class PLATO_OT_mirar(bpy.types.Operator):
    """Gira a la persona para que mire a la cámara activa"""
    bl_idname = "plato.mirar"
    bl_label = "Mirar a cámara"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        p = persona_activa(context)
        if p is None or context.scene.camera is None:
            self.report({"WARNING"}, "Hace falta una persona y una cámara activa")
            return {"CANCELLED"}
        maniqui.mirar_a_camara(p, context.scene)
        return {"FINISHED"}


# ---------------------------------------------------------------- operadores: luz

def _rellenar(context, focos, persona):
    s = ajustes(context)
    F, c, derecha = tr.ejes(context.scene, persona)
    suelo = persona.matrix_world.translation.z
    s.focos.clear()
    for fo in focos:
        tr.colocar(fo, F, c, derecha, suelo)
        tr.calcular(fo, s.dist_max)
        dict_a_foco(fo, s.focos.add(), s)
    s.activo = 0


def lista_focos(context):
    """Los focos de la lista como diccionarios, con posición y potencia al día."""
    s = ajustes(context)
    persona = persona_activa(context)
    focos = [foco_a_dict(p) for p in s.focos]
    if persona is not None:
        F, c, derecha = tr.ejes(context.scene, persona)
        suelo = persona.matrix_world.translation.z
        for fo in focos:
            tr.colocar(fo, F, c, derecha, suelo)
            tr.calcular(fo, s.dist_max)
    return focos


class PLATO_OT_medir(bpy.types.Operator):
    """Mide la luz que llega a la cara de la persona (luces, HDRI, cielo, objetos que emiten y rebotes)
y la convierte en focos del plató"""
    bl_idname = "plato.medir"
    bl_label = "Medir la luz"

    def execute(self, context):
        s = ajustes(context)
        persona = persona_activa(context)
        if persona is None:
            self.report({"WARNING"}, "Primero coloca una persona")
            return {"CANCELLED"}
        context.window.cursor_set("WAIT")
        try:
            medida = analisis.medir(context.scene, persona, muestras=s.muestras)
        finally:
            context.window.cursor_set("DEFAULT")
        inventario = None
        if s.solo_inventario:
            inventario = catalogo.equipo_dict()
            if not inventario:
                self.report({"WARNING"}, "«Mi equipo» está vacío: uso todo el catálogo")
                inventario = None
        F = maniqui.punto_medida(persona)
        focos, L, ref = tr.traducir(medida, s.t_stop, s.iso, s.fps, s.obturador, s.dist_max, inventario,
                                    alt_cara=F.z - persona.matrix_world.translation.z)
        if not focos:
            self.report({"WARNING"}, "No llega luz a la cara")
            return {"CANCELLED"}
        s.lux_clave, s.ref, s.medida_de = L, ref, persona.name
        _ultima[context.scene.name] = medida["panoramica"]
        _rellenar(context, focos, persona)
        tapadas = ", ".join(f["nombre"] for f in medida["tapadas"])
        total = tr.parecido_total(lista_focos(context))
        self.report({"INFO"}, f"{len(focos)} focos · clave {L:.0f} lux"
                    + (f" · parecido {total * 100:.0f} %" if total is not None else "")
                    + (f" · tapadas: {tapadas}" if tapadas else ""))
        return {"FINISHED"}


class PLATO_OT_elegir_foco(bpy.types.Operator):
    """Busca un foco en el catálogo (escribe marca, modelo, tipo, «rgb», «batería»…)"""
    bl_idname = "plato.elegir_foco"
    bl_label = "Buscar foco"
    bl_property = "foco"
    bl_options = {"REGISTER", "UNDO"}

    foco: EnumProperty(items=catalogo.items_enum)
    nuevo: BoolProperty(default=False, options={"SKIP_SAVE"})
    al_equipo: BoolProperty(default=False, options={"SKIP_SAVE"})

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        s = ajustes(context)
        if self.al_equipo:
            catalogo.poner_en_equipo(self.foco, sumar=1)
            return {"FINISHED"}
        if self.nuevo or not s.focos:
            if not s.lux_clave:
                s.lux_clave = tr.lux_clave(s.t_stop, s.iso, s.fps, s.obturador)
            fo = tr.nuevo_foco_manual(self.foco, len(s.focos) + 1, s.lux_clave)
            tr.calcular(fo, s.dist_max)
            dict_a_foco(fo, s.focos.add(), s)
            s.activo = len(s.focos) - 1
        else:
            s.focos[s.activo].foco_id = self.foco
        return {"FINISHED"}


class PLATO_OT_equipo(bpy.types.Operator):
    """Cambia cuántos tenemos de este foco (a 0 sale de «Mi equipo»)"""
    bl_idname = "plato.equipo"
    bl_label = "Cantidad"
    foco: StringProperty()
    sumar: IntProperty(default=1)

    def execute(self, context):
        catalogo.poner_en_equipo(self.foco, sumar=self.sumar)
        for a in context.screen.areas:
            a.tag_redraw()
        return {"FINISHED"}


TIPOS = [(t, t, "") for t in ("COB", "Panel", "Tubo", "Fresnel", "Mini", "Práctico")]


class PLATO_OT_foco_nuevo(bpy.types.Operator):
    """Añade a «Mi equipo» un foco que no está en el catálogo, con sus datos"""
    bl_idname = "plato.foco_nuevo"
    bl_label = "Foco nuevo"
    bl_options = {"REGISTER"}

    marca: StringProperty(name="Marca", default="")
    modelo: StringProperty(name="Modelo", default="")
    tipo: EnumProperty(name="Tipo", items=TIPOS, description="Decide qué modificadores admite")
    w: IntProperty(name="Vatios", default=100, min=1, max=20000)
    lux_1m: IntProperty(name="Lux a 1 m", default=20000, min=1, max=2000000,
                        description="Al 100 % y con su accesorio de serie: de la ficha del fabricante o medido con fotómetro")
    haz: IntProperty(name="Haz (grados)", default=55, min=1, max=360)
    tam_m: FloatProperty(name="Tamaño de lo que emite", default=0.2, min=0.01, max=5, unit="LENGTH")
    k_min: IntProperty(name="Kelvin mín.", default=5600, min=1000, max=20000)
    k_max: IntProperty(name="Kelvin máx.", default=5600, min=1000, max=20000)
    rgb: BoolProperty(name="RGB")
    bowens: BoolProperty(name="Montura Bowens")
    bateria: BoolProperty(name="Batería")
    cantidad: IntProperty(name="Cuántos tenemos", default=1, min=1, max=99)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        lay = self.layout
        col = lay.column()
        col.prop(self, "marca")
        col.prop(self, "modelo")
        col.prop(self, "tipo")
        col.prop(self, "cantidad")
        col.separator()
        col.prop(self, "w")
        col.prop(self, "lux_1m")
        col.label(text="Lux a 1 m: ficha del fabricante o mídelo con fotómetro", icon="INFO")
        col.prop(self, "haz")
        col.prop(self, "tam_m")
        row = col.row(align=True)
        row.prop(self, "k_min")
        row.prop(self, "k_max")
        row = col.row(align=True)
        row.prop(self, "rgb", toggle=True)
        row.prop(self, "bowens", toggle=True)
        row.prop(self, "bateria", toggle=True)

    def execute(self, context):
        if not self.modelo.strip():
            self.report({"WARNING"}, "Ponle al menos el modelo")
            return {"CANCELLED"}
        k0, k1 = sorted((self.k_min, self.k_max))
        f = {"marca": self.marca.strip() or "Plató", "modelo": self.modelo.strip(), "tipo": self.tipo, "w": self.w,
             "lux_1m": self.lux_1m, "haz": self.haz, "accesorio": "datos propios", "tam_m": round(self.tam_m, 3),
             "k": [k0, k1], "rgb": self.rgb, "bowens": self.bowens, "bateria": self.bateria}
        fid = catalogo.nuevo_foco_propio(f, self.cantidad)
        self.report({"INFO"}, f"«{f['modelo']}» añadido a Mi equipo ({fid})")
        return {"FINISHED"}


class PLATO_OT_quitar(bpy.types.Operator):
    """Quita el foco seleccionado de la lista"""
    bl_idname = "plato.quitar"
    bl_label = "Quitar foco"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = ajustes(context)
        if s.focos:
            s.focos.remove(s.activo)
            for i, p in enumerate(s.focos, 1):
                p.n = i
            s.activo = max(0, min(s.activo, len(s.focos) - 1))
        return {"FINISHED"}


class PLATO_OT_crear(bpy.types.Operator):
    """Crea en Blender los focos de la lista, en su sitio y con su potencia (al revés: del plató a Blender)"""
    bl_idname = "plato.crear"
    bl_label = "Crear focos en Blender"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        s = ajustes(context)
        persona = persona_activa(context)
        if persona is None or not s.focos:
            self.report({"WARNING"}, "Hace falta una persona y algún foco en la lista")
            return {"CANCELLED"}
        if not s.lux_clave:
            s.lux_clave = tr.lux_clave(s.t_stop, s.iso, s.fps, s.obturador)
        ref = s.ref or 3.0 / s.lux_clave  # sin medida: la clave queda como un sol de fuerza 3
        hechos = tr.crear_en_blender(context.scene, persona, lista_focos(context), ref)
        self.report({"INFO"}, f"{len(hechos)} focos en la colección «{tr.COLECCION}»")
        return {"FINISHED"}


class PLATO_OT_ver(bpy.types.Operator):
    """Enciende las luces de la escena original o solo los focos del plató, para comparar"""
    bl_idname = "plato.ver"
    bl_label = "Comparar"
    bl_options = {"REGISTER", "UNDO"}
    modo: EnumProperty(items=[("ESCENA", "Escena", ""), ("PLATO", "Plató", "")])

    def execute(self, context):
        plato = self.modo == "PLATO"
        for o in context.scene.objects:
            if o.type != "LIGHT":
                continue
            es_plato = bool(o.get("plato_foco"))
            o.hide_render = o.hide_viewport = (es_plato != plato)
        return {"FINISHED"}


def _datos_hoja(context, persona):
    s = ajustes(context)
    giro = 0.0
    if persona is not None:
        _F, c, _d = tr.ejes(context.scene, persona)
        giro = math.atan2(c.y, c.x)
    focos = lista_focos(context)
    total = tr.parecido_total(focos)
    falta = [(catalogo.nombre(catalogo.foco(fid)), g, roles) for fid, g, roles in tr.que_me_falta(focos, s.dist_max)]
    return {"parecido": total, "falta": falta, "giro": giro, "escena": context.scene.name, "persona": persona.name if persona else "—", "t_stop": s.t_stop,
            "iso": s.iso, "fps": s.fps, "obturador": s.obturador,
            "lux_clave": s.lux_clave or tr.lux_clave(s.t_stop, s.iso, s.fps, s.obturador)}


def _ruta_hoja(context):
    nombre = bpy.path.clean_name(context.scene.name)
    return os.path.join(hoja.carpeta_salida(), f"hoja_plato_{nombre}.html")


class PLATO_OT_hoja(bpy.types.Operator):
    """Hace la hoja de plató (planta, fichas de cada foco y panorámica) y la abre en el navegador para imprimirla"""
    bl_idname = "plato.hoja"
    bl_label = "Hoja de plató"

    tablet: BoolProperty(default=False, options={"SKIP_SAVE"})

    def execute(self, context):
        s = ajustes(context)
        if not s.focos:
            self.report({"WARNING"}, "La lista de focos está vacía: mide la luz o añade focos")
            return {"CANCELLED"}
        persona = persona_activa(context)
        ruta = hoja.generar(_ruta_hoja(context), lista_focos(context), _datos_hoja(context, persona),
                            _ultima.get(context.scene.name))
        if self.tablet:
            try:
                puerto = hoja.servir(os.path.dirname(ruta))
            except OSError as e:
                self.report({"ERROR"}, str(e))
                return {"CANCELLED"}
            s.url_tablet = f"http://{hoja.ip_local()}:{puerto}/{os.path.basename(ruta)}"
            context.window_manager.clipboard = s.url_tablet
            self.report({"INFO"}, f"En la tablet (misma wifi): {s.url_tablet} · copiada al portapapeles")
        else:
            hoja.abrir(ruta)
            self.report({"INFO"}, ruta)
        return {"FINISHED"}


class PLATO_OT_parar_tablet(bpy.types.Operator):
    """Deja de servir la hoja en la red"""
    bl_idname = "plato.parar_tablet"
    bl_label = "Dejar de compartir"

    def execute(self, context):
        hoja.parar()
        ajustes(context).url_tablet = ""
        return {"FINISHED"}


class PLATO_OT_catalogo_propio(bpy.types.Operator):
    """Abre (o crea) catalogo_propio.json para añadir los focos que tenéis y vuestras medidas"""
    bl_idname = "plato.catalogo_propio"
    bl_label = "Mis focos"

    def execute(self, context):
        ruta = catalogo.PROPIO
        if not os.path.exists(ruta):
            os.makedirs(os.path.dirname(ruta), exist_ok=True)
            with open(ruta, "w", encoding="utf-8") as f:
                f.write('{\n  "focos": [\n    {"id": "mi_foco_1", "marca": "Plató", "modelo": "Foco de ejemplo (cambia los datos)",'
                        ' "tipo": "COB", "w": 100, "lux_1m": 30000, "haz": 55, "accesorio": "reflector de serie",'
                        ' "tam_m": 0.2, "k": [5600, 5600], "rgb": false, "bowens": true, "bateria": false}\n  ]\n}\n')
        os.startfile(ruta) if hasattr(os, "startfile") else webbrowser.open(ruta)
        catalogo.cargar(forzar=True)
        return {"FINISHED"}


class PLATO_OT_link(bpy.types.Operator):
    bl_idname = "plato.link"
    bl_label = "Abrir"
    url: StringProperty()

    def execute(self, context):
        if self.url == "docs":
            webbrowser.open("file:///" + DOCS.replace("\\", "/"))
        else:
            webbrowser.open(self.url)
        return {"FINISHED"}


# ---------------------------------------------------------------- paneles

class PLATO_UL_focos(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon_, active_data, active_propname, index=0):
        f = catalogo.foco(item.foco_id)
        row = layout.row(align=True)
        row.prop(item, "activo", text="")
        row.label(text=f"{item.n} · {item.rol}")
        sub = row.row()
        sub.alert = item.pct > 100 or bool(item.aviso and "no llega" in item.aviso)
        nombre = f["modelo"] if f else "— sin foco —"
        sub.label(text=nombre if not f or f["tipo"] == "Pasivo" else f"{nombre} · {item.pct:.0f}%")
        if item.parecido >= 0:
            r = row.row()
            r.alert = item.parecido < 0.6
            r.label(text=f"≈{item.parecido * 100:.0f}")


class _Base:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Plató"


class PLATO_PT_main(_Base, bpy.types.Panel):
    bl_label = "PLATÓ"
    bl_idname = "PLATO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("logo"))

    def draw(self, context):
        lay = self.layout
        unidad = 20 * context.preferences.system.ui_scale
        ancho = (context.region.width / unidad) if context.region else 14
        row = lay.row(align=True)
        row.alignment = "CENTER"
        for i in range(3):
            row.template_icon(icon_value=icon(f"banner_{i}"), scale=max(2.0, (ancho - 1.4) / 3))
        osd(lay, "Iluminación real · N.º 02")


class PLATO_PT_persona(_Base, bpy.types.Panel):
    bl_label = "Persona"
    bl_parent_id = "PLATO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("persona"))

    def draw(self, context):
        s = ajustes(context)
        lay = self.layout
        lay.prop(s, "altura")
        grid = lay.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
        for pose, txt in maniqui.NOMBRES_POSE.items():
            grid.prop_enum(s, "pose", pose, text=txt)
        col = lay.column(align=True)
        col.scale_y = 1.3
        col.operator("plato.colocar", text=f"Colocar · {maniqui.NOMBRES_POSE[s.pose]}", icon="ADD").pose = s.pose
        p = persona_activa(context)
        if p is None:
            lay.label(text="Elige la pose, pulsa Colocar y haz clic donde va el actor", icon="INFO")
            return
        box = lay.box()
        box.label(text=p.name, icon="OUTLINER_OB_ARMATURE")
        box.operator_menu_enum("plato.pose", "pose", text=f"Cambiar pose · {maniqui.NOMBRES_POSE.get(p.get('plato_pose'), '')}")
        box.operator("plato.mirar", icon="CAMERA_DATA")


class PLATO_PT_camara(_Base, bpy.types.Panel):
    bl_label = "Cámara del rodaje"
    bl_parent_id = "PLATO_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("camara"))

    def draw(self, context):
        s = ajustes(context)
        lay = self.layout
        col = lay.column(align=True)
        row = col.row(align=True)
        row.prop(s, "t_stop")
        row.prop(s, "iso")
        row = col.row(align=True)
        row.prop(s, "fps")
        row.prop(s, "obturador")
        osd(lay, f"Clave: {tr.lux_clave(s.t_stop, s.iso, s.fps, s.obturador):.0f} lux en la cara")
        lay.prop(s, "dist_max")
        lay.prop(s, "muestras")


class PLATO_PT_focos(_Base, bpy.types.Panel):
    bl_label = "Focos del plató"
    bl_parent_id = "PLATO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("foco"))

    def draw(self, context):
        s = ajustes(context)
        lay = self.layout
        col = lay.column(align=True)
        col.scale_y = 1.5
        col.operator("plato.medir", text="MEDIR LA LUZ", icon_value=icon("sonda"))
        row = lay.row(align=True)
        row.prop(s, "solo_inventario", toggle=True, icon="CHECKMARK")
        row.operator("plato.catalogo_propio", text="", icon="FILE_TEXT")
        if s.focos:
            osd(lay, f"Clave {s.lux_clave:.0f} lux · {s.medida_de}")
        row = lay.row()
        row.template_list("PLATO_UL_focos", "", s, "focos", s, "activo", rows=4)
        col = row.column(align=True)
        op = col.operator("plato.elegir_foco", text="", icon="ADD")
        op.nuevo = True
        col.operator("plato.quitar", text="", icon="REMOVE")
        if not s.focos or s.activo >= len(s.focos):
            lay.label(text="Mide la luz o añade focos con +", icon="INFO")
            return
        total = tr.parecido_total([foco_a_dict(p) for p in s.focos])
        if total is not None:
            box = lay.box()
            row = box.row()
            row.alert = total < 0.6
            row.scale_y = 1.4
            row.label(text=f"PARECIDO CON BLENDER: {total * 100:.0f} %", icon_value=icon("sonda"))
            box.label(text="Intensidad, suavidad, color y sitio de cada luz, pesados por lo que se ve")
        it = s.focos[s.activo]
        f = catalogo.foco(it.foco_id)
        box = lay.box()
        box.label(text=f"{it.n} · {it.rol}  ({it.fuente})")
        box.operator("plato.elegir_foco", text=catalogo.nombre(f) if f else "Elegir foco", icon="VIEWZOOM")
        if f:
            box.label(text=" · ".join(catalogo.etiquetas(f)))
        if not f or f["tipo"] != "Pasivo":
            box.prop(it, "mod", text="")
        col = box.column(align=True)
        col.prop(it, "lux")
        col.prop(it, "dist")
        col.prop(it, "azim")
        col.prop(it, "elev")
        row = box.row(align=True)
        row.prop(it, "kelvin")
        row.prop(it, "es_color", toggle=True, text="", icon="COLOR")
        if it.es_color:
            box.prop(it, "rgb", text="")
        if f and f["tipo"] != "Pasivo":
            r = box.row()
            r.alert = it.pct > 100
            r.label(text=f"Potencia: {it.pct:.0f} %", icon="LIGHT")
        if it.gel:
            box.label(text=f"Color: {it.gel}", icon="COLORSET_04_VEC")
        if it.parecido >= 0:
            r = box.row()
            r.alert = it.parecido < 0.6
            r.label(text=f"Parecido: {it.parecido * 100:.0f} %", icon="CHECKMARK" if it.parecido >= 0.8 else "DOT")
            box.label(text=it.partes)
        if it.aviso:
            for trozo in it.aviso.split("; "):
                r = box.row()
                r.alert = "no llega" in trozo
                r.label(text=trozo, icon="ERROR")


class PLATO_PT_equipo(_Base, bpy.types.Panel):
    bl_label = "Mi equipo"
    bl_parent_id = "PLATO_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("foco"))

    def draw(self, context):
        lay = self.layout
        eq = catalogo.equipo()
        if not eq:
            lay.label(text="Apunta los focos que tenéis o que vais a tener", icon="INFO")
        col = lay.column(align=True)
        for e in eq:
            f = catalogo.foco(e["id"])
            row = col.row(align=True)
            row.label(text=catalogo.nombre(f), icon="LIGHT" if not f.get("propio") else "LIGHT_AREA")
            op = row.operator("plato.equipo", text="", icon="REMOVE")
            op.foco, op.sumar = e["id"], -1
            row.label(text=f"×{e['cantidad']}")
            op = row.operator("plato.equipo", text="", icon="ADD")
            op.foco, op.sumar = e["id"], 1
        row = lay.row(align=True)
        row.operator("plato.elegir_foco", text="Del catálogo", icon="VIEWZOOM").al_equipo = True
        row.operator("plato.foco_nuevo", text="Foco nuevo", icon="ADD")
        lay.prop(ajustes(context), "solo_inventario", toggle=True, icon="CHECKMARK")


_falta_cache = {"clave": None, "res": []}


def que_me_falta(context):
    s = ajustes(context)
    focos = lista_focos(context)
    clave = tuple((f["foco_id"], f["mod"], round(f["dist"], 2), round(f["lux"], 1), f["activo"]) for f in focos)
    clave += (round(s.dist_max, 2), tuple(sorted(catalogo.equipo_dict().items())))
    if _falta_cache["clave"] != clave:
        _falta_cache.update(clave=clave, res=tr.que_me_falta(focos, s.dist_max))
    return _falta_cache["res"]


class PLATO_PT_falta(_Base, bpy.types.Panel):
    bl_label = "Qué me falta"
    bl_parent_id = "PLATO_PT_main"

    @classmethod
    def poll(cls, context):
        return any(p.parecido >= 0 for p in ajustes(context).focos)

    def draw_header(self, context):
        self.layout.label(text="", icon="SORT_DESC")

    def draw(self, context):
        lay = self.layout
        res = que_me_falta(context)
        if not res:
            lay.label(text="Con este equipo no se gana más cambiando de foco", icon="CHECKMARK")
            return
        lay.label(text="Lo que más acercaría el plató a Blender:")
        tengo = catalogo.equipo_dict()
        for fid, gana, roles in res:
            f = catalogo.foco(fid)
            box = lay.box()
            row = box.row()
            row.label(text=catalogo.nombre(f), icon="LIGHT")
            row.label(text=f"+{gana:.0f} %")
            box.label(text="Para: " + ", ".join(dict.fromkeys(roles)))
            if fid in tengo:
                box.label(text=f"Tenéis {tengo[fid]}: haría falta uno más", icon="INFO")
            op = box.operator("plato.equipo", text="Lo tengo: añadir a Mi equipo", icon="ADD")
            op.foco, op.sumar = fid, 1


class PLATO_PT_salida(_Base, bpy.types.Panel):
    bl_label = "Al plató"
    bl_parent_id = "PLATO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("hoja"))

    def draw(self, context):
        s = ajustes(context)
        lay = self.layout
        col = lay.column(align=True)
        col.scale_y = 1.3
        col.operator("plato.hoja", text="Hoja de plató (imprimir)", icon_value=icon("hoja"))
        col.operator("plato.hoja", text="Abrir en la tablet o el móvil", icon="DESKTOP").tablet = True
        if s.url_tablet:
            box = lay.box()
            box.label(text=s.url_tablet, icon="URL")
            box.label(text="Misma wifi · copiada al portapapeles")
            box.operator("plato.parar_tablet", icon="CANCEL")
        lay.separator()
        col = lay.column(align=True)
        col.scale_y = 1.3
        col.operator("plato.crear", text="Crear focos en Blender", icon_value=icon("crear"))
        row = lay.row(align=True)
        row.label(text="Ver:")
        row.operator("plato.ver", text="Escena").modo = "ESCENA"
        row.operator("plato.ver", text="Plató").modo = "PLATO"


class PLATO_PT_senal(_Base, bpy.types.Panel):
    bl_label = "Señal"
    bl_parent_id = "PLATO_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("senal"))

    def draw(self, context):
        lay = self.layout
        lay.template_icon(icon_value=icon("foto"), scale=8)
        osd(lay, f"PLATÓ {VERSION} · {CREDIT}")
        col = lay.column(align=True)
        col.operator("plato.link", text="Instrucciones", icon_value=icon("libro")).url = "docs"
        col.operator("plato.link", text="@perdidadelalma", icon_value=icon("ig")).url = INSTAGRAM
        col.operator("plato.link", text="Pérdida del Alma · web", icon="URL").url = WEB


classes = (PLATO_Foco, PLATO_Ajustes, PLATO_OT_colocar, PLATO_OT_pose, PLATO_OT_mirar, PLATO_OT_medir,
           PLATO_OT_elegir_foco, PLATO_OT_equipo, PLATO_OT_foco_nuevo, PLATO_OT_quitar, PLATO_OT_crear, PLATO_OT_ver, PLATO_OT_hoja, PLATO_OT_parar_tablet,
           PLATO_OT_catalogo_propio, PLATO_OT_link, PLATO_UL_focos, PLATO_PT_main, PLATO_PT_persona, PLATO_PT_camara,
           PLATO_PT_focos, PLATO_PT_falta, PLATO_PT_equipo, PLATO_PT_salida, PLATO_PT_senal)


def register():
    load_icons()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.plato = PointerProperty(type=PLATO_Ajustes)


def unregister():
    hoja.parar()
    del bpy.types.Scene.plato
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    free_icons()
