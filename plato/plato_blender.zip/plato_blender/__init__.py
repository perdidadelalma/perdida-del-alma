"""PLATÓ · de la luz de Blender al plató real, y al revés."""

bl_info = {
    "name": "PLATÓ · Iluminación real",
    "author": "Toniño",
    "version": (0, 2, 0),
    "blender": (4, 2, 0),
    "location": "Vista 3D > Barra lateral (N) > Plató",
    "description": "Traduce la iluminación de cada escena a focos reales de plató, y al revés",
    "doc_url": "https://perdidadelalma.github.io/perdida-del-alma/plato/",
    "category": "Lighting",
}

if "ui" in locals():
    import importlib
    from . import analisis, catalogo, hoja, maniqui, sonda, traduccion
    for m in (sonda, maniqui, analisis, catalogo, traduccion, hoja, ui):
        importlib.reload(m)
else:
    from . import ui


def register():
    ui.register()


def unregister():
    ui.unregister()
