"""Rutas del entorno de CorridorKey y pasos para instalarlo.

CorridorKey necesita PyTorch con CUDA, que no se puede meter en el Python de
Blender. Por eso vive en su propia carpeta con su propio venv, y el addon lo
llama como proceso externo.
"""

import os
import shutil
import sys

from . import jobs

REPO_URL = "https://github.com/nikopueringer/CorridorKey2.0"
FFMPEG_URL = ("https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/"
              "ffmpeg-master-latest-win64-gpl.zip")
TORCH_PACKAGES = ["torch==2.9.1", "torchvision==0.24.1"]


def addon_prefs(context=None):
    import bpy
    context = context or bpy.context
    return context.preferences.addons[__package__].preferences


def default_root():
    # Fuera de AppData: Windows virtualiza AppData para las apps empaquetadas
    # (Blender de la Store, por ejemplo) y no verían la instalación.
    return os.path.join(os.path.expanduser("~"), "CorridorKey2")


def root(prefs):
    return os.path.normpath(bpy_abspath(prefs.ck_root) or default_root())


def bpy_abspath(p):
    import bpy
    return bpy.path.abspath(p) if p else p


def venv_python(prefs):
    r = root(prefs)
    if os.name == "nt":
        return os.path.join(r, "venv", "Scripts", "python.exe")
    return os.path.join(r, "venv", "bin", "python")


def ffmpeg_exe(prefs):
    if prefs.ffmpeg_path:
        p = bpy_abspath(prefs.ffmpeg_path)
        if os.path.isfile(p):
            return p
    local = os.path.join(root(prefs), "ffmpeg", "bin",
                         "ffmpeg.exe" if os.name == "nt" else "ffmpeg")
    if os.path.isfile(local):
        return local
    return shutil.which("ffmpeg")


def base_python(prefs):
    """Python con el que se crea el venv (no el de Blender si se puede evitar)."""
    if prefs.base_python and os.path.isfile(bpy_abspath(prefs.base_python)):
        return bpy_abspath(prefs.base_python)
    for name in ("python3.12", "python3.11", "python3", "python"):
        p = shutil.which(name)
        # El alias de la Microsoft Store abre la tienda en vez de ejecutar Python.
        if p and "WindowsApps" not in p:
            return p
    if os.name == "nt":
        py = shutil.which("py")
        if py:
            return py
    return sys.executable


def status(prefs):
    r = root(prefs)
    return {
        "repo": os.path.isfile(os.path.join(r, "infer.py")),
        "venv": os.path.isfile(venv_python(prefs)),
        "weights": os.path.isfile(os.path.join(r, "weights", "corridorkey_v2.safetensors")),
        "vfms": os.path.isdir(os.path.join(r, "vfms", "cradio", "C-RADIOv4-SO400M")),
        "ffmpeg": bool(ffmpeg_exe(prefs)),
        "git": bool(shutil.which("git")),
    }


def is_ready(prefs):
    s = status(prefs)
    return s["repo"] and s["venv"] and s["weights"] and s["vfms"] and s["ffmpeg"]


_FFMPEG_SCRIPT = r"""
import io, os, shutil, sys, urllib.request, zipfile
url, dest = sys.argv[1], sys.argv[2]
print("Descargando ffmpeg...", flush=True)
data = urllib.request.urlopen(url).read()
print(f"  {len(data) // 1_000_000} MB, descomprimiendo", flush=True)
tmp = dest + "_tmp"
shutil.rmtree(tmp, ignore_errors=True)
zipfile.ZipFile(io.BytesIO(data)).extractall(tmp)
inner = next(os.path.join(tmp, d) for d in os.listdir(tmp))
shutil.rmtree(dest, ignore_errors=True)
shutil.move(inner, dest)
shutil.rmtree(tmp, ignore_errors=True)
print("ffmpeg listo en", dest, flush=True)
"""

_GIT_ZIP_SCRIPT = r"""
import io, os, shutil, sys, urllib.request, zipfile
url, dest = sys.argv[1], sys.argv[2]
print("Descargando CorridorKey (zip)...", flush=True)
data = urllib.request.urlopen(url + "/archive/refs/heads/main.zip").read()
tmp = dest + "_tmp"
shutil.rmtree(tmp, ignore_errors=True)
zipfile.ZipFile(io.BytesIO(data)).extractall(tmp)
inner = next(os.path.join(tmp, d) for d in os.listdir(tmp))
os.makedirs(dest, exist_ok=True)
for name in os.listdir(inner):
    target = os.path.join(dest, name)
    if not os.path.exists(target):
        shutil.move(os.path.join(inner, name), target)
shutil.rmtree(tmp, ignore_errors=True)
print("Código en", dest, flush=True)
"""


def install_steps(prefs):
    """Pasos que faltan para dejar CorridorKey listo. Saltan lo ya hecho."""
    r = root(prefs)
    s = status(prefs)
    steps = []
    py = venv_python(prefs)
    bpy_ = base_python(prefs)
    if not s["repo"]:
        if s["git"] and not os.path.exists(r):
            steps.append(jobs.Step("Clonar CorridorKey",
                                   ["git", "clone", "--depth", "1", REPO_URL, r]))
        else:
            steps.append(jobs.Step("Descargar CorridorKey",
                                   [bpy_, "-c", _GIT_ZIP_SCRIPT, REPO_URL, r]))
    if not s["venv"]:
        steps.append(jobs.Step("Crear entorno Python",
                               [bpy_, "-m", "venv", os.path.join(r, "venv")]))
        steps.append(jobs.Step("Actualizar pip", [py, "-m", "pip", "install", "--upgrade", "pip"]))
    if not s["venv"] or not s["weights"]:
        steps.append(jobs.Step(
            "Instalar PyTorch (CUDA, ~3 GB)",
            [py, "-m", "pip", "install", *TORCH_PACKAGES,
             "--index-url", prefs.torch_index_url], weight=6))
        steps.append(jobs.Step(
            "Instalar dependencias",
            [py, "-m", "pip", "install", "-r", os.path.join(r, "requirements.txt")],
            cwd=r, weight=2))
    if not s["weights"] or not s["vfms"]:
        steps.append(jobs.Step(
            "Descargar pesos del modelo (~5 GB)",
            [py, os.path.join(r, "scripts", "download_weights.py")], cwd=r, weight=6))
    if not s["ffmpeg"]:
        steps.append(jobs.Step(
            "Descargar ffmpeg",
            [bpy_, "-c", _FFMPEG_SCRIPT, FFMPEG_URL, os.path.join(r, "ffmpeg")], weight=1))
    return steps
