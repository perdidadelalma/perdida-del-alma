"""CorridorKey para Blender.

Recorta pantalla verde (o cualquier sujeto) con el modelo CorridorKey 2.0 de
Corridor Digital, desde el editor de secuencias y el editor de clips.
CorridorKey corre en su propio entorno Python con CUDA; el addon lo instala,
lo lanza en segundo plano y trae el resultado a Blender.

CorridorKey 2.0: https://github.com/nikopueringer/CorridorKey2.0
(licencia propia de Corridor Digital, uso libre no comercial y comercial con
condiciones; ver su LICENSE).
"""

bl_info = {
    "name": "CorridorKey para Blender",
    "author": "Toniño",
    "version": (0, 3, 0),
    "blender": (4, 2, 0),
    "location": "VSE / Editor de clips / Vista 3D > Barra lateral (N) > CorridorKey",
    "description": "Recorta croma con CorridorKey 2.0",
    "category": "Sequencer",
}

import os

import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)

from . import jobs, keying, setup, ui


# ---------------------------------------------------------------- preferencias

class CK_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    ck_root: StringProperty(
        name="Carpeta de CorridorKey", subtype="DIR_PATH",
        default=setup.default_root(),
        description="Dónde vive CorridorKey con su venv, pesos y ffmpeg")
    base_python: StringProperty(
        name="Python para el venv", subtype="FILE_PATH",
        description="Python 3.10–3.13 con el que crear el entorno. Vacío = el del sistema")
    ffmpeg_path: StringProperty(
        name="ffmpeg", subtype="FILE_PATH",
        description="Vacío = el que se descarga en la carpeta de CorridorKey o el del PATH")
    torch_index_url: StringProperty(
        name="Índice de PyTorch", default="https://download.pytorch.org/whl/cu128",
        description="cu128 sirve para RTX 30, 40 y 50")

    def draw(self, context):
        layout = self.layout
        ui.draw_banner(layout, context)
        layout.prop(self, "ck_root")
        layout.prop(self, "base_python")
        layout.prop(self, "ffmpeg_path")
        layout.prop(self, "torch_index_url")

        ui.draw_install_box(layout, self)
        layout.label(text=ui.CREDIT, icon_value=ui.icon("logo"))


# ---------------------------------------------------------------- ajustes por escena

class CK_Settings(bpy.types.PropertyGroup):
    source_mode: EnumProperty(
        name="Origen",
        items=[("AUTO", "Automático", "Tira activa del VSE o clip del editor de clips"),
               ("STRIP", "Tira del VSE", "La tira activa del editor de secuencias"),
               ("CLIP", "Clip", "El clip abierto en el editor de clips"),
               ("OBJECT", "Planos seleccionados",
                "Image as Plane o planos de COLMAP: el recorte se cambia en su propio material"),
               ("CAMERA", "Fondo de la cámara",
                "La imagen de fondo de la cámara activa (cámara animada de COLMAP)"),
               ("FILE", "Archivo", "Un vídeo o carpeta de fotogramas del disco")],
        default="AUTO")
    source_file: StringProperty(name="Archivo", subtype="FILE_PATH")
    frames_color: EnumProperty(
        name="Fotogramas",
        items=[("AUTO", "Automático", "EXR lineal, PNG/JPG sRGB"),
               ("SRGB", "sRGB", "Fotogramas con gamma de pantalla"),
               ("LINEAR", "Lineal", "Fotogramas en lineal de escena")],
        default="AUTO")

    hint_mode: EnumProperty(
        name="Pista",
        items=[("NONE", "Sin pista", "El modelo decide quién es el sujeto"),
               ("MASK_FIRST", "Máscara, primer fotograma",
                "Una máscara de Blender en el primer fotograma del clip"),
               ("MASK_ALL", "Máscara, todo el clip",
                "La máscara animada en cada fotograma (roto o máscara basura)"),
               ("IMAGE", "Imagen", "Mate del primer fotograma desde un archivo"),
               ("VIDEO", "Vídeo", "Vídeo o carpeta de mates para cada fotograma")],
        default="NONE")
    hint_mask: PointerProperty(name="Máscara", type=bpy.types.Mask)
    hint_file: StringProperty(name="Archivo de pista", subtype="FILE_PATH")
    hint_quality: FloatProperty(
        name="Confianza en la pista", min=0.0, max=1.0, default=0.95,
        description="0.95 mate buena, 0.75 automática aproximada, 0.5 o menos borrón")
    carry_hint: BoolProperty(
        name="Arrastrar pista", default=True,
        description="Usa la predicción anterior como pista en las ventanas solapadas")

    out_cutout: BoolProperty(name="Recorte", default=True,
                             description="Color sin premultiplicar + alfa, sin derrame")
    out_alpha: BoolProperty(name="Alfa", default=True, description="Solo el mate")
    out_fg: BoolProperty(name="Frente", default=False, description="Color del sujeto sin despill")
    out_checker: BoolProperty(name="Damero", default=False, description="Vista previa sobre damero")
    output_format: EnumProperty(
        name="Formato",
        items=[("EXR", "EXR (HDR)", "Secuencias OpenEXR lineales, lo mejor para componer"),
               ("VIDEO", "Vídeo", "MP4 y ProRes 4444 con alfa, más ligero")],
        default="EXR")
    exr_dtype: EnumProperty(name="Precisión",
                            items=[("HALF", "Half", ""), ("FLOAT", "Float", "")], default="HALF")
    cutout_linear: BoolProperty(name="Recorte en lineal", default=False)
    despill: FloatProperty(name="Quitar derrame", min=0.0, max=1.0, default=0.5)

    vram_mode: EnumProperty(
        name="Memoria",
        items=[("AUTO", "Automática", "Elige ventana según la VRAM libre"),
               ("LOW", "Poca VRAM", "Inferencia por etapas, más lenta y usa disco"),
               ("MANUAL", "Manual", "Fija el tamaño de ventana")],
        default="AUTO")
    hann_chunk: IntProperty(name="Ventana", min=1, max=96, default=8)
    hann_stride: IntProperty(name="Paso", min=1, max=96, default=4)
    manual_low_vram: BoolProperty(name="Poca VRAM", default=False)
    test_frames: IntProperty(
        name="Solo los primeros", min=0, default=0,
        description="Procesa solo N fotogramas para probar. 0 = todo el clip")

    output_dir: StringProperty(name="Carpeta de salida", subtype="DIR_PATH",
                               default="//corridorkey/")
    add_to_vse: BoolProperty(name="Añadir al VSE", default=True,
                             description="Pone el recorte en un canal encima del original")
    add_plane: BoolProperty(name="Plano en 3D", default=False,
                            description="Crea un plano con el recorte animado como material")
    add_compositor: BoolProperty(name="Nodos en el compositor", default=False,
                                 description="Pone el recorte encima de lo que ya sale por el compositor")
    camera_plane: BoolProperty(name="Plano pegado a la cámara", default=True,
                               description="Con fondo de cámara: plano hijo de la cámara que llena el "
                                           "encuadre y sale en el render, para componer el actor con lo 3D")
    camera_plane_distance: FloatProperty(name="Distancia", default=10.0, min=0.01, unit="LENGTH",
                                         description="A cuántos metros de la cámara va el plano")


# ---------------------------------------------------------------- operadores

class CK_OT_install(bpy.types.Operator):
    bl_idname = "corridorkey.install"
    bl_label = "Instalar CorridorKey"
    bl_description = "Descarga CorridorKey, PyTorch con CUDA, los pesos (~5 GB) y ffmpeg"

    def execute(self, context):
        prefs = setup.addon_prefs(context)
        if any(j.active and j.data.get("install") for j in jobs.all_jobs()):
            self.report({"WARNING"}, "La instalación ya está en marcha")
            return {"CANCELLED"}
        steps = setup.install_steps(prefs)
        if not steps:
            self.report({"INFO"}, "CorridorKey ya está instalado")
            return {"FINISHED"}
        root = setup.root(prefs)
        os.makedirs(os.path.dirname(root), exist_ok=True)
        log = os.path.join(os.path.dirname(root), "corridorkey_install_log.txt")
        job = jobs.Job("Instalar CorridorKey", steps, log_path=log)
        job.data["install"] = True
        jobs.submit(job)
        self.report({"INFO"}, f"Instalando en {root}. Sigue el avance aquí mismo.")
        return {"FINISHED"}


class CK_OT_key(bpy.types.Operator):
    bl_idname = "corridorkey.key"
    bl_label = "Recortar con CorridorKey"
    bl_description = "Lanza CorridorKey sobre el clip en segundo plano y trae el resultado"

    def execute(self, context):
        prefs = setup.addon_prefs(context)
        if not setup.is_ready(prefs):
            self.report({"ERROR"}, "Falta instalar CorridorKey: Preferencias > Add-ons > CorridorKey")
            return {"CANCELLED"}
        settings = context.scene.corridorkey
        try:
            job = keying.make_job(context, prefs, settings)
        except keying.SourceError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        jobs.submit(job)
        busy = sum(1 for j in jobs.all_jobs() if j.active) - 1
        msg = f"En marcha: {job.title}" if busy == 0 else f"En cola detrás de {busy}: {job.title}"
        self.report({"INFO"}, msg)
        return {"FINISHED"}


class CK_OT_cancel(bpy.types.Operator):
    bl_idname = "corridorkey.cancel"
    bl_label = "Cancelar"
    bl_description = "Detiene este trabajo"
    job_id: StringProperty()

    def execute(self, context):
        job = jobs.get(self.job_id)
        if job and job.active:
            job.cancel()
        return {"FINISHED"}


class CK_OT_clear(bpy.types.Operator):
    bl_idname = "corridorkey.clear"
    bl_label = "Limpiar terminados"
    bl_description = "Quita de la lista los trabajos que ya acabaron"

    def execute(self, context):
        jobs.clear_finished()
        return {"FINISHED"}


class CK_OT_open(bpy.types.Operator):
    bl_idname = "corridorkey.open"
    bl_label = "Abrir"
    bl_description = "Abre la carpeta o el registro de este trabajo"
    job_id: StringProperty()
    what: StringProperty(default="folder")

    def execute(self, context):
        job = jobs.get(self.job_id)
        if not job:
            return {"CANCELLED"}
        path = job.log_path if self.what == "log" else job.data.get("work_dir") or os.path.dirname(job.log_path or "")
        if path and os.path.exists(path):
            if os.name == "nt":
                os.startfile(path)
            else:
                bpy.ops.wm.path_open(filepath=path)
        return {"FINISHED"}


classes = (CK_Preferences, CK_Settings, CK_OT_install, CK_OT_key, CK_OT_cancel,
           CK_OT_clear, CK_OT_open)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.corridorkey = PointerProperty(type=CK_Settings)
    ui.register()


def unregister():
    jobs.shutdown()
    ui.unregister()
    del bpy.types.Scene.corridorkey
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
