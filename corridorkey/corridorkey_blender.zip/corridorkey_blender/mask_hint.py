"""Rasteriza una Máscara de Blender a PNG en blanco y negro para usarla de pista.

Se monta una escena temporal con solo el compositor (nodo Máscara -> salida)
a la resolución nativa del clip y se renderiza. Blanco = sujeto.
"""

import os

import bpy


def _build_tree(scene, mask):
    if hasattr(scene, "compositing_node_group"):
        # Blender 5.0+: el compositor es un grupo de nodos con salida propia.
        tree = bpy.data.node_groups.new("CK_mask_hint", "CompositorNodeTree")
        scene.compositing_node_group = tree
        tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
        out = tree.nodes.new("NodeGroupOutput")
        out_socket = out.inputs[0]
    else:
        scene.use_nodes = True
        tree = scene.node_tree
        tree.nodes.clear()
        out = tree.nodes.new("CompositorNodeComposite")
        out_socket = out.inputs["Image"]
    node = tree.nodes.new("CompositorNodeMask")
    node.mask = mask
    if hasattr(node, "size_source"):
        node.size_source = "SCENE"
    tree.links.new(node.outputs[0], out_socket)
    return tree


def render_mask(mask, width, height, out_dir, frames, *, prefix="hint_"):
    """Renderiza `mask` en los fotogramas de escena `frames`.

    Devuelve la lista de rutas PNG en el mismo orden que `frames`.
    """
    os.makedirs(out_dir, exist_ok=True)
    for name in os.listdir(out_dir):
        if name.startswith(prefix) and name.endswith(".png"):
            os.remove(os.path.join(out_dir, name))

    scene = bpy.data.scenes.new("CK_mask_hint")
    tree = None
    cam_data = cam = None
    try:
        r = scene.render
        r.resolution_x = int(width)
        r.resolution_y = int(height)
        r.resolution_percentage = 100
        r.pixel_aspect_x = r.pixel_aspect_y = 1.0
        r.use_compositing = True
        r.use_sequencer = False
        r.image_settings.file_format = "PNG"
        r.image_settings.color_mode = "BW"
        r.image_settings.color_depth = "8"
        r.engine = "BLENDER_WORKBENCH"
        # Sin transformada de vista: blanco tiene que salir 1.0 y negro 0.0.
        scene.view_settings.view_transform = "Standard"
        scene.view_settings.look = "None"
        scene.view_settings.exposure = 0.0
        scene.view_settings.gamma = 1.0
        scene.display_settings.display_device = "sRGB"
        # Algunas versiones exigen cámara aunque solo se use el compositor.
        cam_data = bpy.data.cameras.new("CK_mask_hint_cam")
        cam = bpy.data.objects.new("CK_mask_hint_cam", cam_data)
        scene.collection.objects.link(cam)
        scene.camera = cam
        tree = _build_tree(scene, mask)

        paths = []
        for i, f in enumerate(frames):
            scene.frame_set(int(f))
            path = os.path.join(out_dir, f"{prefix}{i:06d}.png")
            r.filepath = path
            bpy.ops.render.render(write_still=True, scene=scene.name)
            if not os.path.isfile(path):
                raise RuntimeError(f"No se pudo renderizar la máscara en {path}")
            paths.append(path)
        return paths
    finally:
        if hasattr(scene, "compositing_node_group") and tree is not None:
            bpy.data.node_groups.remove(tree)
        bpy.data.scenes.remove(scene)
        if cam is not None:
            bpy.data.objects.remove(cam)
        if cam_data is not None:
            bpy.data.cameras.remove(cam_data)
