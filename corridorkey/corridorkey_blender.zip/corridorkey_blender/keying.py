"""Del clip de Blender al comando de CorridorKey, y del resultado de vuelta a Blender."""

import glob
import os
import re
import tempfile

import bpy

from . import jobs, mask_hint, scene_targets, setup

FRAME_EXTS = (".exr", ".png", ".jpg", ".jpeg")


SourceError = scene_targets.TargetError


# ---------------------------------------------------------------- origen

class Source:
    """Lo que CorridorKey va a recortar y dónde cae en la línea de tiempo."""

    def __init__(self):
        self.path = ""          # vídeo o carpeta de fotogramas
        self.is_dir = False
        self.width = 0
        self.height = 0
        self.frames = 0
        self.scene_frame0 = 1   # fotograma de escena del primer fotograma del clip
        self.name = "clip"
        self.strip_name = None  # si viene del VSE
        self.clip_name = None   # si viene del editor de clips
        self.linear = False     # fotogramas EXR (lineales)
        self.mode = ""
        self.plane_targets = None   # planos que reciben el recorte en su material
        self.camera_target = None   # cámara que recibe el recorte de fondo


def _strip_collection(se):
    return se.strips if hasattr(se, "strips") else se.sequences


def _strip_all(se):
    return se.strips_all if hasattr(se, "strips_all") else se.sequences_all


def _active_strip(context):
    se = context.scene.sequence_editor
    if not se:
        return None
    return getattr(se, "active_strip", None)


def _probe_size(path):
    clip = bpy.data.movieclips.load(path, check_existing=False)
    try:
        return int(clip.size[0]), int(clip.size[1]), int(clip.frame_duration)
    finally:
        bpy.data.movieclips.remove(clip)


def _image_size(path):
    img = bpy.data.images.load(path, check_existing=False)
    try:
        return int(img.size[0]), int(img.size[1])
    finally:
        bpy.data.images.remove(img)


def _frames_in(directory):
    return sorted(n for n in os.listdir(directory) if n.lower().endswith(FRAME_EXTS))


def _isolate_frames(directory, names, work_dir):
    """CorridorKey lee TODAS las imágenes de la carpeta. Si la carpeta tiene
    otras, se enlazan solo las del clip en una carpeta aparte."""
    if _frames_in(directory) == sorted(names):
        return directory
    dest = os.path.join(work_dir, "input_frames")
    os.makedirs(dest, exist_ok=True)
    for old in os.listdir(dest):
        os.remove(os.path.join(dest, old))
    for i, n in enumerate(names):
        src = os.path.join(directory, n)
        dst = os.path.join(dest, f"frame_{i:06d}{os.path.splitext(n)[1].lower()}")
        try:
            os.link(src, dst)
        except OSError:
            import shutil
            shutil.copy2(src, dst)
    return dest


def source_from_context(context, settings, work_dir):
    src = Source()
    space = context.space_data
    mode = settings.source_mode

    if mode == "AUTO" and space and space.type == "CLIP_EDITOR":
        mode = "CLIP"
    elif mode == "AUTO" and space and space.type == "VIEW_3D":
        mode = scene_targets.auto_mode(context)
    elif mode == "AUTO":
        mode = "STRIP"
    src.mode = mode

    if mode == "OBJECT":
        scene_targets.fill_from_planes(context, src, work_dir, _probe_size, _frames_in)
        return src
    if mode == "CAMERA":
        scene_targets.fill_from_camera(context, src, work_dir, _probe_size, _frames_in)
        return src

    if mode == "FILE":
        path = bpy.path.abspath(settings.source_file)
        if not path or not os.path.exists(path):
            raise SourceError("Elige un vídeo o una carpeta de fotogramas.")
        src.path = os.path.normpath(path)
        src.is_dir = os.path.isdir(src.path)
        src.scene_frame0 = context.scene.frame_start
        if src.is_dir:
            names = _frames_in(src.path)
            if not names:
                raise SourceError("La carpeta no tiene EXR, PNG o JPG.")
            src.width, src.height = _image_size(os.path.join(src.path, names[0]))
            src.frames = len(names)
            src.linear = names[0].lower().endswith(".exr")
            src.name = os.path.basename(src.path)
        else:
            src.width, src.height, src.frames = _probe_size(src.path)
            src.name = os.path.splitext(os.path.basename(src.path))[0]
        return src

    if mode == "CLIP":
        clip = getattr(space, "clip", None) if space and space.type == "CLIP_EDITOR" else None
        if clip is None:
            raise SourceError("No hay clip activo en el editor de clips.")
        path = os.path.normpath(bpy.path.abspath(clip.filepath))
        src.clip_name = clip.name
        src.name = clip.name
        src.width, src.height = int(clip.size[0]), int(clip.size[1])
        src.frames = int(clip.frame_duration)
        src.scene_frame0 = int(clip.frame_start)
        if clip.source == "SEQUENCE":
            directory = os.path.dirname(path)
            names = _frames_in(directory)
            src.path = _isolate_frames(directory, names, work_dir)
            src.is_dir = True
            src.linear = path.lower().endswith(".exr")
        else:
            src.path = path
        return src

    strip = _active_strip(context)
    if strip is None or strip.type not in {"MOVIE", "IMAGE"}:
        raise SourceError("Selecciona una tira de vídeo o de imágenes en el VSE.")
    src.strip_name = strip.name
    src.name = strip.name
    src.scene_frame0 = int(strip.frame_start)
    if strip.type == "MOVIE":
        src.path = os.path.normpath(bpy.path.abspath(strip.filepath))
        if not os.path.isfile(src.path):
            raise SourceError(f"No encuentro el vídeo: {src.path}")
        src.width, src.height, src.frames = _probe_size(src.path)
    else:
        directory = os.path.normpath(bpy.path.abspath(strip.directory))
        names = [e.filename for e in strip.elements]
        src.path = _isolate_frames(directory, names, work_dir)
        src.is_dir = True
        src.frames = len(names)
        src.linear = names[0].lower().endswith(".exr")
        e = strip.elements[0]
        src.width, src.height = e.orig_width, e.orig_height
        if not src.width:
            src.width, src.height = _image_size(os.path.join(directory, names[0]))
    return src


# ---------------------------------------------------------------- carpetas

def output_root(settings):
    p = settings.output_dir or "//corridorkey/"
    if p.startswith("//") and not bpy.data.filepath:
        return os.path.join(tempfile.gettempdir(), "corridorkey_blender")
    return os.path.normpath(bpy.path.abspath(p))


def new_work_dir(settings, name):
    safe = re.sub(r"[^\w\-]+", "_", name).strip("_") or "clip"
    base = output_root(settings)
    n = 1
    while os.path.exists(os.path.join(base, f"{safe}_v{n:03d}")):
        n += 1
    path = os.path.join(base, f"{safe}_v{n:03d}")
    os.makedirs(path)
    return path


# ---------------------------------------------------------------- pista

def prepare_hint(context, settings, src, work_dir):
    """Devuelve (argumentos de pista para infer.py)."""
    mode = settings.hint_mode
    if mode == "NONE":
        return []
    if mode in {"MASK_FIRST", "MASK_ALL"}:
        if settings.hint_mask is None:
            raise SourceError("Elige la máscara que marca al sujeto.")
        hint_dir = os.path.join(work_dir, "hint")
        if mode == "MASK_FIRST":
            frames = [src.scene_frame0]
        else:
            n = settings.test_frames if settings.test_frames > 0 else src.frames
            frames = [src.scene_frame0 + i for i in range(min(n, src.frames))]
        paths = mask_hint.render_mask(settings.hint_mask, src.width, src.height,
                                      hint_dir, frames)
        if mode == "MASK_FIRST":
            return ["--hint_first_frame", paths[0]]
        return ["--hint_video", hint_dir]
    path = bpy.path.abspath(settings.hint_file)
    if not path or not os.path.exists(path):
        raise SourceError("Elige el archivo de pista.")
    if mode == "IMAGE":
        return ["--hint_first_frame", os.path.normpath(path)]
    return ["--hint_video", os.path.normpath(path)]


# ---------------------------------------------------------------- comando

def build_command(prefs, settings, src, work_dir, hint_args):
    r = setup.root(prefs)
    cmd = [setup.venv_python(prefs), "-u", os.path.join(r, "infer.py"),
           "--input", src.path, "--output_dir", work_dir]
    cmd += hint_args
    if hint_args:
        cmd += ["--hint_quality", f"{settings.hint_quality:.3f}"]
        if not settings.carry_hint:
            cmd.append("--no_carry_hint")
    outputs = [name for name in ("alpha", "fg", "cutout", "checker")
               if getattr(settings, f"out_{name}")]
    if not outputs:
        outputs = ["cutout"]
    cmd += ["--outputs", *outputs]
    cmd += ["--despill_strength", f"{settings.despill:.3f}"]
    if settings.output_format == "EXR":
        cmd += ["--output_format", "exr", "--exr_dtype", settings.exr_dtype.lower()]
    elif settings.cutout_linear:
        cmd.append("--cutout_linear")
    if src.is_dir:
        fps = context_fps()
        cmd += ["--frame_dir_fps", f"{fps:.4f}"]
        linear = {"AUTO": src.linear, "LINEAR": True, "SRGB": False}[settings.frames_color]
        if linear:
            cmd.append("--frame_dir_linear")
    if settings.vram_mode == "LOW":
        cmd.append("--low_vram")
    elif settings.vram_mode == "MANUAL":
        cmd += ["--hann_chunk", str(settings.hann_chunk),
                "--hann_stride", str(max(1, min(settings.hann_stride, settings.hann_chunk)))]
        if settings.manual_low_vram:
            cmd.append("--low_vram")
    if settings.test_frames > 0:
        cmd += ["--num_frames", str(settings.test_frames)]
    cmd += ["--temp_dir", os.path.join(work_dir, "tmp")]
    ff = setup.ffmpeg_exe(prefs)
    if ff:
        cmd += ["--ffmpeg_bin", ff]
    return cmd


def context_fps():
    s = bpy.context.scene.render
    return s.fps / (s.fps_base or 1.0)


# ---------------------------------------------------------------- progreso

_RE_PROBED = re.compile(r"probed (\d+) frames")
_RE_WINDOW = re.compile(r"window (\d+)/(\d+)")
_RE_CHUNK = re.compile(r"Hann stage1: chunk=(\d+)")
_OOM_LADDER = (4, 2, 1)


def retry_on_oom(job, step):
    """Si la GPU se quedó sin memoria, otro intento con una ventana más pequeña y poca VRAM."""
    # Sin memoria: el error de PyTorch, o un cierre de golpe de Windows (0xC0000005)
    # en plena inferencia, que es como acaba cuando falta memoria nativa.
    crashed = job.data.get("last_code") in (3221225477, -1073741819) and "stage" in job.data
    if not (job.data.pop("oom", False) or crashed):
        return None
    current = job.data.get("chunk", 8)
    smaller = next((c for c in _OOM_LADDER if c < current), None)
    if smaller is None:
        return None
    cmd, skip = [], 0
    for arg in step.cmd:
        if skip:
            skip -= 1
            continue
        if arg in ("--hann_chunk", "--hann_stride"):
            skip = 1
            continue
        if arg == "--low_vram":
            continue
        cmd.append(arg)
    cmd += ["--hann_chunk", str(smaller), "--hann_stride", str(max(1, smaller // 2)), "--low_vram"]
    job.data["chunk"] = smaller
    job.data["low_vram"] = True
    job.data["stage"] = f"Sin memoria: reintento con ventana {smaller}"
    job.step_progress = 0.0
    return jobs.Step(f"CorridorKey (ventana {smaller}, poca VRAM)", cmd, cwd=step.cwd, env=step.env)


def parse_progress(job, line):
    if "OutOfMemoryError" in line or "CUDA out of memory" in line:
        job.data["oom"] = True
        return
    m = _RE_CHUNK.search(line)
    if m:
        job.data["chunk"] = int(m.group(1))
    m = _RE_PROBED.search(line)
    if m:
        job.data["frames"] = int(m.group(1))
        job.step_progress = max(job.step_progress, 0.03)
        job.data["stage"] = "Leyendo el clip"
        return
    if "Loading CorridorKey" in line:
        job.data["stage"] = "Cargando el modelo"
        job.step_progress = max(job.step_progress, 0.01)
    elif "Auto VRAM" in line:
        job.data["stage"] = "Ajustando memoria"
        job.data["vram"] = line.strip()
    elif "RVM continuous prepass" in line:
        job.data["stage"] = "RVM"
        job.step_progress = max(job.step_progress, 0.05)
    elif "frozen VFM prepass" in line:
        job.data["stage"] = "Modelos base"
        job.step_progress = max(job.step_progress, 0.08)
    elif "Hann stage1" in line:
        job.data["stage"] = "Recortando"
        job.step_progress = max(job.step_progress, 0.1)
    else:
        m = _RE_WINDOW.search(line)
        if m:
            i, n = int(m.group(1)), int(m.group(2))
            job.data["stage"] = f"Recortando · ventana {i}/{n}"
            span = 0.6 if job.data.get("low_vram") else 0.88
            job.step_progress = max(job.step_progress, 0.1 + span * i / n)
        elif "wrote" in line and "output" in line:
            job.data["stage"] = "Guardado"
            job.step_progress = 1.0


# ---------------------------------------------------------------- importar

def _find_outputs(work_dir):
    """{nombre: (tipo, ruta, ficheros)} con lo que CorridorKey dejó."""
    found = {}
    for kind in ("cutout", "fg", "alpha", "checker"):
        dirs = glob.glob(os.path.join(work_dir, f"*_{kind}*_exr"))
        if dirs:
            files = sorted(glob.glob(os.path.join(dirs[0], "*.exr")))
            if files:
                found[kind] = ("exr", dirs[0], files)
                continue
        vids = glob.glob(os.path.join(work_dir, f"*_{kind}*.mp4")) + \
            glob.glob(os.path.join(work_dir, f"*_{kind}*.mov"))
        if vids:
            found[kind] = ("video", vids[0], [vids[0]])
    return found


def _set_colorspace(settings_obj, names):
    for n in names:
        try:
            settings_obj.name = n
            return
        except TypeError:
            continue


def _load_image(kind, out, label):
    typ, path, files = out
    img = bpy.data.images.load(files[0], check_existing=False)
    img.name = f"CK_{label}_{kind}"
    if typ == "exr":
        img.source = "SEQUENCE"
    else:
        img.source = "MOVIE"
    if kind == "cutout":
        img.alpha_mode = "STRAIGHT"
    if kind == "alpha":
        _set_colorspace(img.colorspace_settings, ["Non-Color"])
    return img


def _free_channel(se, start, end, above):
    strips = list(_strip_all(se))
    ch = max(1, above)
    while ch < 128:
        clash = any(s.channel == ch and s.frame_final_start < end and s.frame_final_end > start
                    for s in strips)
        if not clash:
            return ch
        ch += 1
    return 128


def _add_to_vse(scene, kind, out, src, label):
    se = scene.sequence_editor_create()
    coll = _strip_collection(se)
    origin = None
    if src.get("strip_name"):
        origin = _strip_all(se).get(src["strip_name"])
    start = origin.frame_start if origin else src["scene_frame0"]
    typ, path, files = out
    above = origin.channel + 1 if origin else 2
    ch = _free_channel(se, start, start + len(files) if typ == "exr" else start + src["frames"], above)
    name = f"CK_{label}_{kind}"
    if typ == "exr":
        strip = coll.new_image(name, files[0], ch, int(start))
        for f in files[1:]:
            strip.elements.append(os.path.basename(f))
    else:
        strip = coll.new_movie(name, path, ch, int(start))
    if kind == "cutout":
        strip.alpha_mode = "STRAIGHT"
    if kind in {"cutout", "fg", "checker"}:
        strip.blend_type = "ALPHA_OVER"
    if origin is not None:
        strip.frame_offset_start = origin.frame_offset_start
        strip.frame_offset_end = origin.frame_offset_end
    return strip


def _add_plane(context, img, src, frames, label):
    w, h = src["width"], src["height"]
    height = 2.0
    width = height * w / h if h else height
    mesh = bpy.data.meshes.new(f"CK_{label}")
    hw, hh = width / 2, height / 2
    mesh.from_pydata([(-hw, 0, -hh), (hw, 0, -hh), (hw, 0, hh), (-hw, 0, hh)], [], [(0, 1, 2, 3)])
    uv = mesh.uv_layers.new()
    for loop, co in zip(uv.data, [(0, 0), (1, 0), (1, 1), (0, 1)]):
        loop.uv = co
    obj = bpy.data.objects.new(f"CK_{label}", mesh)
    obj.location = (0, 0, hh)
    context.scene.collection.objects.link(obj)

    mat = bpy.data.materials.new(f"CK_{label}")
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.location = (-600, 0)
    if img.source in {"SEQUENCE", "MOVIE"}:
        iu = tex.image_user
        iu.frame_duration = frames
        iu.frame_start = int(src["scene_frame0"])
        iu.frame_offset = -1 if img.source == "SEQUENCE" else 0
        iu.use_auto_refresh = True
    emit = nt.nodes.new("ShaderNodeEmission")
    emit.location = (-250, -100)
    transp = nt.nodes.new("ShaderNodeBsdfTransparent")
    transp.location = (-250, 100)
    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.location = (0, 0)
    out = nt.nodes.new("ShaderNodeOutputMaterial")
    out.location = (220, 0)
    nt.links.new(tex.outputs["Color"], emit.inputs["Color"])
    nt.links.new(tex.outputs["Alpha"], mix.inputs[0])
    nt.links.new(transp.outputs[0], mix.inputs[1])
    nt.links.new(emit.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs["Surface"])
    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = "BLENDED"
    elif hasattr(mat, "blend_method"):
        mat.blend_method = "BLEND"
    mesh.materials.append(mat)
    return obj


def import_results(job):
    if job.state != "hecho":
        return
    d = job.data
    scene = bpy.data.scenes.get(d["scene"])
    if scene is None:
        return
    found = _find_outputs(d["work_dir"])
    if not found:
        job.state = "error"
        job.error = "CorridorKey terminó pero no encuentro los archivos de salida."
        return
    label = d["label"]
    images = {}
    for kind, out in found.items():
        images[kind] = _load_image(kind, out, label)
    main = "cutout" if "cutout" in found else ("fg" if "fg" in found else next(iter(found)))
    frames = len(found[main][2]) if found[main][0] == "exr" else d["src"]["frames"]
    made = []
    src = d["src"]
    in_scene = src.get("plane_targets") or src.get("camera_target")
    if src.get("plane_targets"):
        made += scene_targets.apply_to_planes(src["plane_targets"], found[main], label)
    if src.get("camera_target"):
        made += scene_targets.apply_to_camera(src["camera_target"], found[main], label,
                                              add_plane=d["cam_plane"], distance=d["cam_distance"])
    if d["to_vse"] and not in_scene:
        made.append(_add_to_vse(scene, main, found[main], src, label).name)
    if d["to_plane"] and not src.get("plane_targets"):
        made.append(_add_plane(bpy.context, images[main], src, frames, label).name)
    if d["to_compositor"]:
        made.append(scene_targets.add_compositor(scene, images[main], src["scene_frame0"], frames, label))
    if d["src"].get("clip_name") and found[main][0] == "exr":
        clip = bpy.data.movieclips.load(found[main][2][0], check_existing=False)
        clip.name = f"CK_{label}_{main}"
        clip.frame_start = int(d["src"]["scene_frame0"])
        made.append(clip.name)
    d["made"] = made + [i.name for i in images.values()]
    job.detail = "Importado: " + ", ".join(d["made"])
    job.log(job.detail)


def make_job(context, prefs, settings):
    """Prepara todo y devuelve el trabajo listo para la cola."""
    # La carpeta de trabajo se crea antes de saber el nombre definitivo del clip.
    probe_name = settings.source_mode
    space = context.space_data
    strip = _active_strip(context)
    if settings.source_mode == "FILE":
        probe_name = os.path.splitext(os.path.basename(bpy.path.abspath(settings.source_file).rstrip("\\/")))[0]
    elif space and space.type == "CLIP_EDITOR" and getattr(space, "clip", None):
        probe_name = space.clip.name
    elif space and space.type == "VIEW_3D" and context.active_object is not None:
        probe_name = context.active_object.name
    elif strip is not None:
        probe_name = strip.name
    work_dir = new_work_dir(settings, probe_name)
    try:
        src = source_from_context(context, settings, work_dir)
        hint_args = prepare_hint(context, settings, src, work_dir)
    except Exception:
        try:
            os.rmdir(work_dir)
        except OSError:
            pass
        raise
    cmd = build_command(prefs, settings, src, work_dir, hint_args)
    env = {}
    ff = setup.ffmpeg_exe(prefs)
    if ff:
        env["PATH"] = os.path.dirname(ff) + os.pathsep + os.environ.get("PATH", "")
    frames = settings.test_frames if settings.test_frames > 0 else src.frames
    title = f"{src.name} ({frames} fot., {src.width}x{src.height})"
    job = jobs.Job(
        title,
        [jobs.Step("CorridorKey", cmd, cwd=setup.root(prefs), env=env)],
        log_path=os.path.join(work_dir, "corridorkey_log.txt"),
        on_done=import_results,
        progress_parser=parse_progress,
        on_fail=retry_on_oom,
    )
    job.data.update({
        "work_dir": work_dir,
        "scene": context.scene.name,
        "label": re.sub(r"[^\w\-]+", "_", src.name).strip("_")[:40] or "clip",
        "to_vse": settings.add_to_vse,
        "to_plane": settings.add_plane,
        "to_compositor": settings.add_compositor,
        "cam_plane": settings.camera_plane,
        "cam_distance": settings.camera_plane_distance,
        "low_vram": settings.vram_mode == "LOW" or (settings.vram_mode == "MANUAL" and settings.manual_low_vram),
        "src": {
            "strip_name": src.strip_name, "clip_name": src.clip_name,
            "scene_frame0": src.scene_frame0, "frames": frames,
            "width": src.width, "height": src.height,
            "plane_targets": src.plane_targets, "camera_target": src.camera_target,
        },
    })
    return job
