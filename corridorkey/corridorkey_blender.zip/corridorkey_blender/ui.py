"""Interfaz con la estética de «Pérdida del alma».

Tríptico de cabecera, logo e iconos propios, textos en clave de pantalla
de vigilancia (OSD) y un panel «Señal» con la foto y los enlaces.
El mismo juego de paneles se registra en el VSE, el editor de clips y la
vista 3D; cada espacio necesita sus propias clases.
"""

import os
import webbrowser

import bpy
import bpy.utils.previews

from . import jobs, scene_targets, setup

_previews = None

VERSION = "0.3.0"
AUTHOR = "Toniño"
CREDIT = "por Toniño · Pérdida del Alma"
INSTAGRAM = "https://www.instagram.com/perdidadelalma/"
WEB = "https://perdidadelalma.github.io/perdida-del-alma/"
MODEL_URL = "https://github.com/nikopueringer/CorridorKey2.0"
DOCS = os.path.join(os.path.dirname(__file__), "docs", "instrucciones.html")


def icon(name):
    if _previews is None:
        return 0
    for key in (name, f"i_{name}"):
        if key in _previews:
            return _previews[key].icon_id
    return 0


def load_icons():
    global _previews
    _previews = bpy.utils.previews.new()
    folder = os.path.join(os.path.dirname(__file__), "icons")
    for f in os.listdir(folder):
        if f.endswith(".png"):
            _previews.load(os.path.splitext(f)[0], os.path.join(folder, f), "IMAGE")


def free_icons():
    global _previews
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None


# ---------------------------------------------------------------- piezas

def _width_units(context):
    unit = 20 * context.preferences.system.ui_scale
    region = context.region
    return (region.width / unit) if region else 14


def draw_banner(layout, context):
    """Tríptico: foto, nombre del modelo, firma."""
    scale = max(2.0, (_width_units(context) - 1.4) / 3)
    row = layout.row(align=True)
    row.alignment = "CENTER"
    for i in range(3):
        row.template_icon(icon_value=icon(f"banner_{i}"), scale=scale)


def osd(layout, text, icon_name=None, alert=False):
    """Una línea en mayúsculas, como el texto de la cámara en las piezas."""
    row = layout.row()
    row.alert = alert
    if icon_name:
        row.label(text=text.upper(), icon_value=icon(icon_name))
    else:
        row.label(text=text.upper())


_STATE = {"en_cola": ("EN ESPERA", "TIME"), "en_curso": ("REC", "REC"),
          "hecho": ("SEÑAL LIMPIA", "CHECKMARK"), "error": ("SIN SEÑAL", "ERROR"),
          "cancelado": ("CORTADO", "CANCEL")}


def draw_jobs(layout, only_install=False):
    shown = [j for j in jobs.all_jobs() if bool(j.data.get("install")) == only_install]
    if not shown:
        return
    col = layout.column()
    for n, job in enumerate(reversed(shown[-6:])):
        box = col.box()
        word, ic = _STATE.get(job.state, ("", "DOT"))
        head = box.row(align=True)
        head.alert = job.state == "error"
        head.label(text=f"CH-{len(shown) - n:02d} · {word}", icon=ic)
        if job.active:
            op = head.operator("corridorkey.cancel", text="", icon="X")
            op.job_id = job.id
        op = head.operator("corridorkey.open", text="", icon="FILE_FOLDER")
        op.job_id, op.what = job.id, "folder"
        op = head.operator("corridorkey.open", text="", icon="TEXT")
        op.job_id, op.what = job.id, "log"
        box.label(text=job.title)
        if job.state == "en_curso":
            n_steps = len(job.steps)
            stage = job.data.get("stage") or job.current_label
            text = stage if n_steps == 1 else f"{job.step_index + 1}/{n_steps} · {job.current_label}"
            box.progress(factor=job.progress, type="BAR",
                         text=f"TRANSMITIENDO · {text.upper()}  {job.progress * 100:.0f}%")
            sub = box.row()
            sub.enabled = False
            sub.label(text=job.detail[-80:])
        elif job.state == "error":
            sub = box.column(align=True)
            sub.alert = True
            for chunk in _wrap(job.error, 56)[:4]:
                sub.label(text=chunk)
        elif job.state == "hecho" and job.detail:
            sub = box.row()
            sub.enabled = False
            sub.label(text=job.detail if len(job.detail) <= 70 else job.detail[:69] + "…", icon="IMPORT")
    if any(not j.active for j in shown):
        col.operator("corridorkey.clear", text="Borrar cintas terminadas", icon="TRASH")


def _wrap(text, width):
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + 1 > width:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}".strip()
    if cur:
        lines.append(cur)
    return lines


def draw_install_box(layout, prefs):
    st = setup.status(prefs)
    box = layout.box()
    osd(box, "Comprobación de señal", "senal")
    col = box.column(align=True)
    for key, label in (("repo", "Código de CorridorKey"), ("venv", "Entorno Python"),
                       ("weights", "Pesos de CorridorKey"), ("vfms", "Modelos base"),
                       ("ffmpeg", "ffmpeg"), ("git", "git (para instalar)")):
        col.label(text=label, icon="CHECKMARK" if st[key] else "X")
    row = box.row()
    row.scale_y = 1.4
    if setup.is_ready(prefs):
        row.label(text="LISTO PARA GRABAR", icon_value=icon("trabajos"))
        row.operator("corridorkey.install", text="Reparar", icon="FILE_REFRESH")
    else:
        row.operator("corridorkey.install", text="Instalar lo que falta (~9 GB)", icon="IMPORT")
    draw_jobs(layout, only_install=True)


def _ready(context):
    return setup.is_ready(setup.addon_prefs(context))


def _hint_name(s):
    return {"NONE": "sin pista", "MASK_FIRST": "máscara 1.er fot.", "MASK_ALL": "máscara animada",
            "IMAGE": "imagen", "VIDEO": "vídeo"}[s.hint_mode]


# ---------------------------------------------------------------- operadores propios de la interfaz

class CK_OT_revert(bpy.types.Operator):
    bl_idname = "corridorkey.revert_plane"
    bl_label = "Devolver la imagen original"
    bl_description = "Quita el recorte de los planos seleccionados y deja su imagen y material como estaban"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        objs = set(context.selected_objects) | ({context.active_object} if context.active_object else set())
        n = sum(1 for o in objs if scene_targets.revert_plane(o))
        self.report({"INFO"}, f"{n} plano(s) devuelto(s) a su imagen original")
        return {"FINISHED"}


class CK_OT_docs(bpy.types.Operator):
    bl_idname = "corridorkey.docs"
    bl_label = "Instrucciones"
    bl_description = "Abre las instrucciones del addon en el navegador"

    def execute(self, context):
        webbrowser.open("file:///" + DOCS.replace("\\", "/"))
        return {"FINISHED"}


# ---------------------------------------------------------------- paneles

class _Base:
    bl_region_type = "UI"
    bl_category = "CorridorKey"


class _Main(_Base):
    bl_label = "CORRIDORKEY"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("logo"))

    def draw(self, context):
        layout = self.layout
        draw_banner(layout, context)
        if not _ready(context):
            box = layout.box()
            box.alert = True
            box.label(text="SIN SEÑAL: CorridorKey no está instalado", icon="ERROR")
            draw_install_box(layout, setup.addon_prefs(context))
            return
        s = context.scene.corridorkey
        busy = any(j.active and not j.data.get("install") for j in jobs.all_jobs())
        row = layout.row()
        row.scale_y = 2.2
        row.operator("corridorkey.key", text="GRABAR RECORTE" if not busy else "AÑADIR A LA COLA",
                     icon_value=icon("trabajos"))
        fmt = "EXR" if s.output_format == "EXR" else "VÍDEO"
        sub = layout.row()
        sub.alignment = "CENTER"
        sub.enabled = False
        sub.label(text=f"CH-01 · {_hint_name(s).upper()} · {fmt} · DESPILL {s.despill:.2f}")


class _Sub(_Base):
    bl_options = {"DEFAULT_CLOSED"}
    icon_name = "senal"

    @classmethod
    def poll(cls, context):
        return _ready(context)

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon(self.icon_name))


class _Source(_Sub):
    bl_label = "ORIGEN"
    bl_options = set()
    icon_name = "origen"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s = context.scene.corridorkey
        layout.prop(s, "source_mode", text="Desde")
        mode = s.source_mode
        if mode == "AUTO" and context.space_data.type == "VIEW_3D":
            mode = scene_targets.auto_mode(context)
            sub = layout.row()
            sub.enabled = False
            sub.label(text={"OBJECT": "→ PLANOS SELECCIONADOS", "CAMERA": "→ FONDO DE LA CÁMARA",
                            "FILE": "→ ARCHIVO"}[mode])
        if mode == "FILE":
            layout.prop(s, "source_file")
        elif mode == "OBJECT":
            planes = [o for o in context.selected_objects if scene_targets.image_node(o)]
            box = layout.box()
            box.label(text=f"{len(planes)} plano(s) con imagen", icon="IMAGE_PLANE")
            if len(planes) > 1:
                box.label(text="Fotos fijas (COLMAP): se recortan juntas en orden")
            if any(scene_targets.has_original(o) for o in planes):
                box.operator("corridorkey.revert_plane", icon="LOOP_BACK")
        elif mode == "CAMERA":
            cam = context.active_object if context.active_object and context.active_object.type == "CAMERA"                 else context.scene.camera
            box = layout.box()
            ok = scene_targets.camera_background(cam)
            box.label(text=(cam.name if cam else "Sin cámara") + (" · con fondo" if ok else " · sin fondo"),
                      icon="CAMERA_DATA" if ok else "ERROR")
            box.prop(s, "camera_plane")
            if s.camera_plane:
                box.prop(s, "camera_plane_distance")
        layout.prop(s, "frames_color")
        layout.prop(s, "test_frames")


class _Hint(_Sub):
    bl_label = "PISTA DEL SUJETO"
    bl_options = set()
    icon_name = "pista"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s = context.scene.corridorkey
        layout.prop(s, "hint_mode", text="Modo")
        if s.hint_mode in {"MASK_FIRST", "MASK_ALL"}:
            layout.prop(s, "hint_mask")
            if s.hint_mask is None:
                layout.label(text="Dibújala en el editor de clips, modo Máscara", icon="INFO")
        elif s.hint_mode in {"IMAGE", "VIDEO"}:
            layout.prop(s, "hint_file")
        if s.hint_mode != "NONE":
            layout.prop(s, "hint_quality", slider=True)
            layout.prop(s, "carry_hint")


class _Output(_Sub):
    bl_label = "SALIDA"
    icon_name = "salida"

    def draw(self, context):
        layout = self.layout
        s = context.scene.corridorkey
        grid = layout.grid_flow(columns=2, align=True, even_columns=True)
        for name, ic in (("out_cutout", "IMAGE_RGB_ALPHA"), ("out_alpha", "IMAGE_ALPHA"),
                         ("out_fg", "IMAGE_RGB"), ("out_checker", "TEXTURE")):
            grid.prop(s, name, toggle=True, icon=ic)
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(s, "output_format")
        if s.output_format == "EXR":
            layout.prop(s, "exr_dtype")
        else:
            layout.prop(s, "cutout_linear")
        layout.prop(s, "despill", slider=True)
        layout.prop(s, "output_dir")
        col = layout.column(heading="Al terminar", align=True)
        col.prop(s, "add_to_vse")
        col.prop(s, "add_plane")
        col.prop(s, "add_compositor")


class _Memory(_Sub):
    bl_label = "MEMORIA DE LA GPU"
    icon_name = "memoria"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        s = context.scene.corridorkey
        layout.prop(s, "vram_mode")
        if s.vram_mode == "MANUAL":
            layout.prop(s, "hann_chunk")
            layout.prop(s, "hann_stride")
            layout.prop(s, "manual_low_vram")


class _Jobs(_Base):
    bl_label = "CINTAS"

    @classmethod
    def poll(cls, context):
        return any(not j.data.get("install") for j in jobs.all_jobs())

    def draw_header(self, context):
        n = sum(1 for j in jobs.all_jobs() if j.active and not j.data.get("install"))
        self.layout.label(text=f"● {n}" if n else "", icon_value=icon("trabajos"))

    def draw(self, context):
        draw_jobs(self.layout)


class _Signal(_Base):
    bl_label = "SEÑAL"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("senal"))

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.alignment = "CENTER"
        row.template_icon(icon_value=icon("foto"), scale=max(4.0, _width_units(context) - 1.6))
        col = layout.column(align=True)
        osd(col, f"CorridorKey para Blender {VERSION}")
        osd(col, CREDIT)
        col.separator()
        row = col.row(align=True)
        row.scale_y = 1.3
        row.operator("wm.url_open", text="@perdidadelalma", icon_value=icon("ig")).url = INSTAGRAM
        row.operator("wm.url_open", text="Web", icon="URL").url = WEB
        col.operator("corridorkey.docs", text="Instrucciones", icon_value=icon("libro"))
        col.separator()
        sub = col.column(align=True)
        sub.enabled = False
        sub.label(text="Modelo CorridorKey 2.0: Zachary Harris")
        sub.label(text="y Corridor Digital")
        col.operator("wm.url_open", text="Repositorio del modelo", icon="URL").url = MODEL_URL


_SPACES = (("SEQUENCE_EDITOR", "SEQ"), ("CLIP_EDITOR", "CLIP"), ("VIEW_3D", "V3D"))
_PARTS = (("main", _Main, None), ("source", _Source, "main"), ("hint", _Hint, "main"),
          ("output", _Output, "main"), ("memory", _Memory, "main"),
          ("jobs", _Jobs, None), ("signal", _Signal, None))


def _make_classes():
    out = []
    for space, tag in _SPACES:
        for name, base, parent in _PARTS:
            idname = f"CK_PT_{tag}_{name}"
            attrs = {"bl_idname": idname, "bl_space_type": space}
            if parent:
                attrs["bl_parent_id"] = f"CK_PT_{tag}_{parent}"
            out.append(type(idname, (base, bpy.types.Panel), attrs))
    return out


classes = [CK_OT_revert, CK_OT_docs] + _make_classes()


def register():
    load_icons()
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    free_icons()
