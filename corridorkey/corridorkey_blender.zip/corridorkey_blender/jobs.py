"""Cola de trabajos en segundo plano.

Cada trabajo es una lista de pasos (comandos externos). Un hilo los ejecuta
uno tras otro y lee su salida; un temporizador de Blender, en el hilo
principal, refresca la interfaz y llama a `on_done` cuando el trabajo acaba.
Solo corre un trabajo a la vez porque todos compiten por la GPU o la red.
"""

import os
import re
import subprocess
import threading
import time
from collections import deque

import bpy

_jobs = []          # todos los trabajos de la sesión, en orden
_lock = threading.Lock()
_TIMER_INTERVAL = 0.5

_CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0


class Step:
    def __init__(self, label, cmd, cwd=None, env=None, weight=1.0):
        self.label = label
        self.cmd = cmd
        self.cwd = cwd
        self.env = env
        self.weight = weight


class Job:
    def __init__(self, title, steps, *, log_path=None, on_done=None,
                 progress_parser=None):
        self.id = f"{int(time.time() * 1000)}"
        self.title = title
        self.steps = steps
        self.log_path = log_path
        self.on_done = on_done              # fn(job) en el hilo principal
        self.progress_parser = progress_parser  # fn(job, line) -> None
        self.state = "en_cola"              # en_cola, en_curso, hecho, error, cancelado
        self.step_index = 0
        self.step_progress = 0.0            # 0..1 dentro del paso actual
        self.detail = ""
        self.lines = deque(maxlen=400)
        self.error = ""
        self.data = {}                      # libre para el parser y on_done
        self.proc = None
        self.cancel_requested = False
        self.done_handled = False
        self.started = None
        self.finished = None

    @property
    def progress(self):
        total = sum(s.weight for s in self.steps) or 1.0
        done = sum(s.weight for s in self.steps[:self.step_index])
        if self.state == "hecho":
            return 1.0
        cur = self.steps[self.step_index].weight if self.step_index < len(self.steps) else 0
        return min(1.0, (done + cur * self.step_progress) / total)

    @property
    def current_label(self):
        if self.step_index < len(self.steps):
            return self.steps[self.step_index].label
        return ""

    @property
    def active(self):
        return self.state in ("en_cola", "en_curso")

    def log(self, text):
        self.lines.append(text)
        if self.log_path:
            try:
                with open(self.log_path, "a", encoding="utf-8") as f:
                    f.write(text + "\n")
            except OSError:
                pass

    def cancel(self):
        self.cancel_requested = True
        proc = self.proc
        if proc and proc.poll() is None:
            _kill_tree(proc)


def _kill_tree(proc):
    try:
        if os.name == "nt":
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)],
                           capture_output=True, creationflags=_CREATE_NO_WINDOW)
        else:
            proc.kill()
    except OSError:
        pass


_SPLIT = re.compile(r"[\r\n]+")


def _run_job(job):
    job.state = "en_curso"
    job.started = time.time()
    job.log(f"=== {job.title} ({time.strftime('%Y-%m-%d %H:%M:%S')}) ===")
    try:
        for i, step in enumerate(job.steps):
            if job.cancel_requested:
                break
            job.step_index = i
            job.step_progress = 0.0
            job.detail = step.label
            job.log(f"--- {step.label}: {' '.join(str(c) for c in step.cmd)}")
            env = dict(os.environ)
            if step.env:
                env.update(step.env)
            env.setdefault("PYTHONUNBUFFERED", "1")
            env.setdefault("PYTHONIOENCODING", "utf-8")
            # El Python de Blender deja variables que confunden a otro intérprete.
            for k in ("PYTHONHOME", "PYTHONPATH"):
                env.pop(k, None)
            job.proc = subprocess.Popen(
                [str(c) for c in step.cmd], cwd=step.cwd, env=env,
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, creationflags=_CREATE_NO_WINDOW)
            buf = ""
            while True:
                chunk = job.proc.stdout.read1(4096) if hasattr(job.proc.stdout, "read1") \
                    else job.proc.stdout.read(4096)
                if not chunk:
                    break
                buf += chunk.decode("utf-8", errors="replace")
                parts = _SPLIT.split(buf)
                buf = parts.pop()
                for line in parts:
                    line = line.rstrip()
                    if not line:
                        continue
                    job.log(line)
                    job.detail = line[-160:]
                    if job.progress_parser:
                        try:
                            job.progress_parser(job, line)
                        except Exception:
                            pass
            if buf.strip():
                job.log(buf.strip())
            code = job.proc.wait()
            if job.cancel_requested:
                break
            if code != 0:
                job.state = "error"
                job.error = f"{step.label} falló (código {code}). " + _last_error(job)
                job.log("!!! " + job.error)
                return
            job.step_progress = 1.0
        if job.cancel_requested:
            job.state = "cancelado"
            job.log("--- cancelado")
        else:
            job.step_index = len(job.steps)
            job.state = "hecho"
            job.log("--- terminado")
    except Exception as exc:
        job.state = "error"
        job.error = f"{type(exc).__name__}: {exc}"
        job.log("!!! " + job.error)
    finally:
        job.proc = None
        job.finished = time.time()


def _last_error(job):
    for line in reversed(job.lines):
        if "Error" in line or "error" in line or "Traceback" in line:
            return line[-300:]
    return job.lines[-1][-300:] if job.lines else ""


def _runner():
    while True:
        with _lock:
            nxt = next((j for j in _jobs if j.state == "en_cola"), None)
        if nxt is None:
            return
        _run_job(nxt)


_runner_thread = None


def submit(job):
    global _runner_thread
    with _lock:
        _jobs.append(job)
    if _runner_thread is None or not _runner_thread.is_alive():
        _runner_thread = threading.Thread(target=_runner, daemon=True)
        _runner_thread.start()
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=_TIMER_INTERVAL, persistent=True)
    return job


def all_jobs():
    return list(_jobs)


def get(job_id):
    return next((j for j in _jobs if j.id == job_id), None)


def clear_finished():
    with _lock:
        _jobs[:] = [j for j in _jobs if j.active]


def any_active():
    return any(j.active for j in _jobs)


def _redraw():
    wm = bpy.context.window_manager
    if not wm:
        return
    for win in wm.windows:
        for area in win.screen.areas:
            if area.type in {"SEQUENCE_EDITOR", "CLIP_EDITOR", "PREFERENCES",
                             "NODE_EDITOR", "VIEW_3D"}:
                area.tag_redraw()


def _tick():
    for job in list(_jobs):
        if not job.active and not job.done_handled:
            job.done_handled = True
            if job.on_done:
                try:
                    job.on_done(job)
                except Exception as exc:
                    job.state = "error"
                    job.error = f"Al importar el resultado: {type(exc).__name__}: {exc}"
                    job.log("!!! " + job.error)
    _redraw()
    if any_active():
        return _TIMER_INTERVAL
    return None


def shutdown():
    for job in _jobs:
        if job.active:
            job.cancel()
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
