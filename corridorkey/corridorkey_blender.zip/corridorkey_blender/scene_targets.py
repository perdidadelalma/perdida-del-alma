"""Recortar lo que ya está en la escena y devolver el resultado a su sitio.

- Planos con imagen: un «Image as Plane» con vídeo o secuencia, o los planos
  por cámara que crea el importador de COLMAP (una foto fija cada uno).
  El recorte sustituye la imagen dentro del mismo material y se conecta su
  alfa; se guarda lo que había para poder volver atrás.
- Fondo de cámara: la cámara animada de COLMAP lleva el plano como imagen
  de fondo. El recorte se añade como fondo delante y, si se pide, como un
  plano pegado a la cámara que sale en el render.
- Compositor: nodo Imagen con el recorte sobre las capas de render.
"""

import json
import os
import re

import bpy

FRAME_EXTS = (".exr", ".png", ".jpg", ".jpeg", ".tif", ".tiff")
_ORIG_KEY = "ck_original"


class TargetError(Exception):
    pass


# ---------------------------------------------------------------- búsqueda

def image_node(obj):
    """(material, nodo Imagen) del primer material del objeto que tenga imagen."""
    if obj is None or obj.type != "MESH":
        return None
    for slot in obj.material_slots:
        mat = slot.material
        if mat and mat.use_nodes and mat.node_tree:
            for node in mat.node_tree.nodes:
                if node.type == "TEX_IMAGE" and node.image is not None:
                    return mat, node
    return None


def camera_background(cam_obj):
    """(índice, fondo) del primer fondo de cámara con clip o imagen."""
    if cam_obj is None or cam_obj.type != "CAMERA":
        return None
    for i, bg in enumerate(cam_obj.data.background_images):
        if bg.source == "MOVIE_CLIP" and bg.clip is not None:
            return i, bg
        if bg.source == "IMAGE" and bg.image is not None:
            return i, bg
    return None


def auto_mode(context):
    """Qué recortar en la vista 3D si el origen está en Automático."""
    obj = context.active_object
    if obj is not None and obj.type == "CAMERA" and camera_background(obj):
        return "CAMERA"
    if any(image_node(o) for o in context.selected_objects) or image_node(obj):
        return "OBJECT"
    return "FILE"


def _first_number(name):
    m = re.findall(r"(\d+)", os.path.splitext(name)[0])
    return int(m[-1]) if m else 1


def _sequence_names(path):
    """Fotogramas de la misma secuencia que `path` (mismo prefijo y extensión)."""
    directory, first = os.path.split(path)
    stem, ext = os.path.splitext(first)
    prefix = re.sub(r"\d+$", "", stem)
    names = sorted(n for n in os.listdir(directory)
                   if n.lower().endswith(ext.lower()) and re.sub(r"\d+$", "", os.path.splitext(n)[0]) == prefix)
    return directory, names


def _scene_frame_of_first(img, iu):
    """Fotograma de escena en el que se ve el primer fotograma del vídeo o la secuencia."""
    if img.source == "MOVIE":
        return int(iu.frame_start - iu.frame_offset)
    n0 = _first_number(os.path.basename(bpy.path.abspath(img.filepath)))
    return int(iu.frame_start + (n0 - 1 - iu.frame_offset))


def _size(img, path):
    """Tamaño real; una secuencia sin cargar todavía da 0x0."""
    w, h = int(img.size[0]), int(img.size[1])
    if w and h:
        return w, h
    probe = bpy.data.images.load(path, check_existing=False)
    try:
        return int(probe.size[0]), int(probe.size[1])
    finally:
        bpy.data.images.remove(probe)


def _link_frames(paths, work_dir):
    dest = os.path.join(work_dir, "input_frames")
    os.makedirs(dest, exist_ok=True)
    for old in os.listdir(dest):
        os.remove(os.path.join(dest, old))
    for i, p in enumerate(paths):
        dst = os.path.join(dest, f"frame_{i:06d}{os.path.splitext(p)[1].lower()}")
        try:
            os.link(p, dst)
        except OSError:
            import shutil
            shutil.copy2(p, dst)
    return dest


# ---------------------------------------------------------------- origen: planos

def fill_from_planes(context, src, work_dir, probe_size, frames_in):
    objs = [o for o in context.selected_objects if image_node(o)]
    act = context.active_object
    if act is not None and image_node(act) and act not in objs:
        objs.insert(0, act)
    if not objs:
        raise TargetError("Selecciona un plano con imagen (Image as Plane o los planos de COLMAP).")

    first_mat, first_node = image_node(objs[0])
    img = first_node.image
    if len(objs) == 1 and img.source in {"MOVIE", "SEQUENCE"}:
        path = os.path.normpath(bpy.path.abspath(img.filepath))
        iu = first_node.image_user
        src.scene_frame0 = _scene_frame_of_first(img, iu)
        if img.source == "MOVIE":
            src.path = path
            src.width, src.height, src.frames = probe_size(path)
        else:
            directory, names = _sequence_names(path)
            src.path = _link_frames([os.path.join(directory, n) for n in names], work_dir)
            src.is_dir = True
            src.frames = len(names)
            src.width, src.height = _size(img, os.path.join(directory, names[0]))
            src.linear = path.lower().endswith(".exr")
        src.name = objs[0].name
        src.plane_targets = [{"obj": objs[0].name, "mat": first_mat.name, "node": first_node.name,
                              "mode": "anim", "f0": src.scene_frame0}]
        return

    # Fotos fijas, una por plano (COLMAP): se recortan juntas, en orden de
    # nombre de archivo, para que el modelo vea la continuidad del plano.
    entries = []
    for o in objs:
        mat, node = image_node(o)
        if node.image.source in {"MOVIE", "SEQUENCE"}:
            raise TargetError(f"{o.name} tiene vídeo: recórtalo solo, sin otros planos seleccionados.")
        entries.append((os.path.normpath(bpy.path.abspath(node.image.filepath)), o, mat, node))
    entries.sort(key=lambda e: os.path.basename(e[0]).lower())
    paths = []
    for p, *_ in entries:
        if p not in paths:
            paths.append(p)
    sizes = {_size(e[3].image, e[0]) for e in entries}
    if len(sizes) > 1:
        raise TargetError("Los planos tienen fotos de tamaños distintos; recórtalos por grupos del mismo tamaño.")
    src.width, src.height = sizes.pop()
    src.path = _link_frames(paths, work_dir)
    src.is_dir = True
    src.frames = len(paths)
    src.linear = paths[0].lower().endswith(".exr")
    src.scene_frame0 = context.scene.frame_start
    src.name = f"{len(objs)}_planos" if len(objs) > 1 else objs[0].name
    src.plane_targets = [{"obj": o.name, "mat": mat.name, "node": node.name,
                          "mode": "still", "index": paths.index(p)}
                         for p, o, mat, node in entries]


# ---------------------------------------------------------------- origen: cámara

def fill_from_camera(context, src, work_dir, probe_size, frames_in):
    cam = context.active_object
    if cam is None or cam.type != "CAMERA":
        cam = context.scene.camera
    found = camera_background(cam)
    if not found:
        raise TargetError("La cámara no tiene imagen de fondo (en COLMAP: «Add animated camera background images»).")
    index, bg = found
    if bg.source == "MOVIE_CLIP":
        clip = bg.clip
        path = os.path.normpath(bpy.path.abspath(clip.filepath))
        src.width, src.height = int(clip.size[0]), int(clip.size[1])
        src.frames = int(clip.frame_duration)
        src.scene_frame0 = int(clip.frame_start)
        if clip.source == "SEQUENCE":
            directory, names = _sequence_names(path)
            src.path = _link_frames([os.path.join(directory, n) for n in names], work_dir)
            src.is_dir = True
            src.linear = path.lower().endswith(".exr")
        else:
            src.path = path
    else:
        img = bg.image
        path = os.path.normpath(bpy.path.abspath(img.filepath))
        src.scene_frame0 = _scene_frame_of_first(img, bg.image_user) if img.source != "FILE" \
            else context.scene.frame_start
        if img.source == "MOVIE":
            src.path = path
            src.width, src.height, src.frames = probe_size(path)
        else:
            directory, names = _sequence_names(path) if img.source == "SEQUENCE" \
                else (os.path.dirname(path), [os.path.basename(path)])
            src.path = _link_frames([os.path.join(directory, n) for n in names], work_dir)
            src.is_dir = True
            src.frames = len(names)
            src.width, src.height = _size(img, os.path.join(directory, names[0]))
    src.name = cam.name
    src.camera_target = {"cam": cam.name, "bg": index, "f0": src.scene_frame0}


# ---------------------------------------------------------------- resultado: planos

def _render_method(mat):
    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = "DITHERED"
    if hasattr(mat, "blend_method"):
        try:
            mat.blend_method = "HASHED"
        except TypeError:
            pass


def _wire_alpha(mat, node):
    """Conecta el alfa del recorte al sombreador. Devuelve qué se añadió."""
    nt = mat.node_tree
    if node.outputs["Alpha"].is_linked:
        return {}
    for link in node.outputs["Color"].links:
        to = link.to_node
        if to.type == "BSDF_PRINCIPLED" and "Alpha" in to.inputs:
            nt.links.new(node.outputs["Alpha"], to.inputs["Alpha"])
            return {"alpha_to": to.name}
    out = next((n for n in nt.nodes if n.type == "OUTPUT_MATERIAL" and n.is_active_output), None) \
        or next((n for n in nt.nodes if n.type == "OUTPUT_MATERIAL"), None)
    if out is None or not out.inputs["Surface"].is_linked:
        return {}
    shader = out.inputs["Surface"].links[0].from_socket
    transp = nt.nodes.new("ShaderNodeBsdfTransparent")
    transp.name = "CK_transparente"
    transp.location = (out.location.x - 200, out.location.y + 160)
    mix = nt.nodes.new("ShaderNodeMixShader")
    mix.name = "CK_mezcla"
    mix.location = (out.location.x - 200, out.location.y)
    nt.links.new(node.outputs["Alpha"], mix.inputs[0])
    nt.links.new(transp.outputs[0], mix.inputs[1])
    nt.links.new(shader, mix.inputs[2])
    nt.links.new(mix.outputs[0], out.inputs["Surface"])
    return {"mix": mix.name, "transp": transp.name, "out": out.name,
            "shader_node": shader.node.name, "shader_socket": shader.identifier}


def _set_image_user(iu, f0, frames, source):
    iu.frame_duration = frames
    iu.frame_start = int(f0)
    iu.frame_offset = -1 if source == "SEQUENCE" else 0
    iu.use_auto_refresh = True


def apply_to_planes(targets, out, label):
    typ, path, files = out
    shared = None
    done = []
    for t in targets:
        obj = bpy.data.objects.get(t["obj"])
        mat = bpy.data.materials.get(t["mat"])
        node = mat.node_tree.nodes.get(t["node"]) if mat else None
        if obj is None or node is None:
            continue
        iu = node.image_user
        orig = json.loads(mat.get(_ORIG_KEY, "{}"))
        if node.name not in orig:
            orig[node.name] = {"image": node.image.name, "frame_start": iu.frame_start,
                               "frame_offset": iu.frame_offset, "frame_duration": iu.frame_duration,
                               "auto": iu.use_auto_refresh,
                               "render_method": getattr(mat, "surface_render_method", ""),
                               "blend": getattr(mat, "blend_method", "")}
        if t["mode"] == "still" and typ == "exr":
            # Sin reutilizar: el primer archivo ya está cargado como secuencia.
            img = bpy.data.images.load(files[t["index"]], check_existing=False)
            img.name = f"CK_{label}_{obj.name}"
            img.alpha_mode = "STRAIGHT"
            node.image = img
        else:
            if shared is None:
                shared = bpy.data.images.load(files[0], check_existing=False)
                shared.name = f"CK_{label}_recorte"
                shared.source = "SEQUENCE" if typ == "exr" else "MOVIE"
                shared.alpha_mode = "STRAIGHT"
            node.image = shared
            _set_image_user(iu, t.get("f0", 1), len(files) if typ == "exr" else iu.frame_duration,
                            shared.source)
        added = _wire_alpha(mat, node)
        if added:
            orig[node.name]["added"] = added
        _render_method(mat)
        mat[_ORIG_KEY] = json.dumps(orig)
        done.append(obj.name)
    return done


def revert_plane(obj):
    """Devuelve la imagen y el material del plano a como estaban."""
    found = image_node(obj)
    if not found:
        return False
    mat, _node = found
    orig = json.loads(mat.get(_ORIG_KEY, "{}"))
    if not orig:
        return False
    nt = mat.node_tree
    for node_name, o in orig.items():
        node = nt.nodes.get(node_name)
        img = bpy.data.images.get(o["image"])
        if node is None or img is None:
            continue
        node.image = img
        iu = node.image_user
        iu.frame_start, iu.frame_offset = o["frame_start"], o["frame_offset"]
        iu.frame_duration, iu.use_auto_refresh = o["frame_duration"], o["auto"]
        added = o.get("added", {})
        if "alpha_to" in added:
            for link in list(node.outputs["Alpha"].links):
                if link.to_node.name == added["alpha_to"]:
                    nt.links.remove(link)
        if "mix" in added:
            out = nt.nodes.get(added["out"])
            shader_node = nt.nodes.get(added["shader_node"])
            if out and shader_node:
                sock = next((s for s in shader_node.outputs if s.identifier == added["shader_socket"]), None)
                if sock:
                    nt.links.new(sock, out.inputs["Surface"])
            for n in (added["mix"], added["transp"]):
                if nt.nodes.get(n):
                    nt.nodes.remove(nt.nodes[n])
        if o.get("render_method") and hasattr(mat, "surface_render_method"):
            mat.surface_render_method = o["render_method"]
        if o.get("blend") and hasattr(mat, "blend_method"):
            try:
                mat.blend_method = o["blend"]
            except TypeError:
                pass
    del mat[_ORIG_KEY]
    return True


def has_original(obj):
    found = image_node(obj)
    return bool(found and found[0].get(_ORIG_KEY))


# ---------------------------------------------------------------- resultado: cámara

def apply_to_camera(target, out, label, *, add_plane, distance):
    cam = bpy.data.objects.get(target["cam"])
    if cam is None:
        return []
    typ, path, files = out
    made = []
    clip = bpy.data.movieclips.load(files[0], check_existing=False)
    clip.name = f"CK_{label}_recorte"
    clip.frame_start = int(target["f0"])
    data = cam.data
    data.show_background_images = True
    old = data.background_images[target["bg"]] if target["bg"] < len(data.background_images) else None
    frame_method = old.frame_method if old is not None else "CROP"
    bg = data.background_images.new()
    bg.source = "MOVIE_CLIP"
    bg.clip = clip
    bg.alpha = 1.0
    bg.display_depth = "FRONT"
    bg.frame_method = frame_method
    made.append(clip.name)
    if add_plane:
        made.append(camera_plane(cam, out, label, target["f0"], distance).name)
    return made


def camera_plane(cam, out, label, f0, distance):
    """Plano hijo de la cámara que llena el encuadre a `distance` metros."""
    typ, path, files = out
    cd = cam.data
    scene = bpy.context.scene
    rx = scene.render.resolution_x * scene.render.pixel_aspect_x
    ry = scene.render.resolution_y * scene.render.pixel_aspect_y
    aspect = rx / ry if ry else 16 / 9
    if cd.type == "ORTHO":
        size = cd.ortho_scale
    else:
        fit = cd.sensor_fit
        sensor = cd.sensor_height if fit == "VERTICAL" else cd.sensor_width
        size = distance * sensor / cd.lens
    horizontal = cd.sensor_fit == "HORIZONTAL" or (cd.sensor_fit == "AUTO" and aspect >= 1)
    w, h = (size, size / aspect) if horizontal else (size * aspect, size)

    mesh = bpy.data.meshes.new(f"CK_{label}_plano_camara")
    mesh.from_pydata([(-w / 2, -h / 2, 0), (w / 2, -h / 2, 0), (w / 2, h / 2, 0), (-w / 2, h / 2, 0)],
                     [], [(0, 1, 2, 3)])
    uv = mesh.uv_layers.new()
    for loop, co in zip(uv.data, [(0, 0), (1, 0), (1, 1), (0, 1)]):
        loop.uv = co
    obj = bpy.data.objects.new(f"CK_{label}_plano_camara", mesh)
    coll = cam.users_collection[0] if cam.users_collection else scene.collection
    coll.objects.link(obj)
    obj.parent = cam
    big = max(w, h)
    obj.location = (cd.shift_x * big, cd.shift_y * big, -distance)
    for attr in ("visible_shadow",):
        if hasattr(obj, attr):
            setattr(obj, attr, False)

    img = bpy.data.images.load(files[0], check_existing=False)
    img.name = f"CK_{label}_plano_camara"
    img.source = "SEQUENCE" if typ == "exr" else "MOVIE"
    img.alpha_mode = "STRAIGHT"
    mat = bpy.data.materials.new(obj.name)
    mat.use_nodes = True
    nt = mat.node_tree
    nt.nodes.clear()
    tex = nt.nodes.new("ShaderNodeTexImage")
    tex.image = img
    tex.location = (-600, 0)
    _set_image_user(tex.image_user, f0, len(files) if typ == "exr" else 1, img.source)
    emit = nt.nodes.new("ShaderNodeEmission")
    emit.location = (-250, -100)
    transp = nt.nodes.new("ShaderNodeBsdfTransparent")
    transp.location = (-250, 100)
    mix = nt.nodes.new("ShaderNodeMixShader")
    outn = nt.nodes.new("ShaderNodeOutputMaterial")
    outn.location = (220, 0)
    nt.links.new(tex.outputs["Color"], emit.inputs["Color"])
    nt.links.new(tex.outputs["Alpha"], mix.inputs[0])
    nt.links.new(transp.outputs[0], mix.inputs[1])
    nt.links.new(emit.outputs[0], mix.inputs[2])
    nt.links.new(mix.outputs[0], outn.inputs["Surface"])
    _render_method(mat)
    mesh.materials.append(mat)
    return obj


# ---------------------------------------------------------------- resultado: compositor

def _input(node, names, index):
    for n in names:
        if n in node.inputs:
            return node.inputs[n]
    return node.inputs[index]


def add_compositor(scene, img, f0, frames, label):
    """Recorte encima de lo que ya llegaba a la salida del compositor."""
    if hasattr(scene, "compositing_node_group"):          # Blender 5.0+
        tree = scene.compositing_node_group
        if tree is None:
            tree = bpy.data.node_groups.new(f"{scene.name} compositor", "CompositorNodeTree")
            scene.compositing_node_group = tree
        if not any(s.in_out == "OUTPUT" for s in tree.interface.items_tree if hasattr(s, "in_out")):
            tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
        out = next((n for n in tree.nodes if n.type == "GROUP_OUTPUT"), None) or tree.nodes.new("NodeGroupOutput")
        out_socket = out.inputs[0]
    else:
        scene.use_nodes = True
        tree = scene.node_tree
        out = next((n for n in tree.nodes if n.type == "COMPOSITE"), None) \
            or tree.nodes.new("CompositorNodeComposite")
        out_socket = out.inputs["Image"]

    if out_socket.is_linked:
        background = out_socket.links[0].from_socket
    else:
        rl = next((n for n in tree.nodes if n.type == "R_LAYERS"), None) \
            or tree.nodes.new("CompositorNodeRLayers")
        background = rl.outputs["Image"]

    node = tree.nodes.new("CompositorNodeImage")
    node.name = node.label = f"CK {label}"
    node.image = img
    node.location = (out.location.x - 520, out.location.y - 260)
    for attr, val in (("frame_duration", frames), ("frame_start", int(f0)),
                      ("frame_offset", -1 if img.source == "SEQUENCE" else 0), ("use_auto_refresh", True)):
        if hasattr(node, attr):
            setattr(node, attr, val)
    over = tree.nodes.new("CompositorNodeAlphaOver")
    over.name = over.label = f"CK sobre {label}"
    over.location = (out.location.x - 220, out.location.y)
    tree.links.new(background, _input(over, ("Background",), 1))
    tree.links.new(node.outputs["Image"], _input(over, ("Foreground",), 2))
    tree.links.new(over.outputs[0], out_socket)
    if not hasattr(scene, "compositing_node_group"):
        viewer = next((n for n in tree.nodes if n.type == "VIEWER"), None) \
            or tree.nodes.new("CompositorNodeViewer")
        tree.links.new(over.outputs[0], viewer.inputs[0])
    return tree.name
