# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""QR de la dirección del móvil, con el codificador de OpenCV (ya lo instala el addon) → ~/RASTRO/qr_*.png."""

import hashlib
import os

from . import dependencias

CARPETA = os.path.join(os.path.expanduser("~"), "RASTRO")


def crear(url, modulo=12, margen=4):
    """PNG en blanco y negro, con píxeles grandes para que se vea nítido en el panel. Devuelve la ruta o ''."""
    dependencias.preparar_ruta()
    try:
        import cv2
        import numpy as np
    except ImportError:
        return ""
    ruta = os.path.join(CARPETA, "qr_" + hashlib.md5(url.encode()).hexdigest()[:10] + ".png")
    if os.path.isfile(ruta):
        return ruta
    m = cv2.QRCodeEncoder.create().encode(url)  # un píxel por módulo (0 negro, 255 blanco)
    if m is None or m.size == 0:
        return ""
    m = np.pad(m, margen, constant_values=255)
    m = cv2.resize(m, None, fx=modulo, fy=modulo, interpolation=cv2.INTER_NEAREST)
    os.makedirs(CARPETA, exist_ok=True)
    cv2.imwrite(ruta, m)
    return ruta
