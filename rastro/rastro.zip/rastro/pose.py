# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Poses de cámara: de lo que mandan las fuentes (móvil, FreeD, marcadores, COLMAP) al mundo de Blender.

Una pose es (t, R, p): instante en segundos, matriz de giro 3×3 y posición en metros, ya en el
convenio de Blender (Z arriba; la cámara mira hacia su −Z local con +Y arriba, como cualquier
cámara de Blender).
"""

import math
import threading
import time
from collections import deque

from mathutils import Euler, Matrix, Quaternion, Vector

# WebXR / ARKit / ARCore: Y arriba, −Z al frente. A Blender (Z arriba): (x, y, z) → (x, −z, y)
_XR = Matrix(((1, 0, 0), (0, 0, -1), (0, 1, 0)))


def desde_webxr(p, q):
    """Pose del visor WebXR (Android, o cualquier fuente con convenio de WebXR)."""
    # La cámara de WebXR ya mira a su −Z con +Y arriba, como la de Blender: basta con cambiar el mundo
    R = _XR @ Quaternion((q[3], q[0], q[1], q[2])).to_matrix()
    return R, _XR @ Vector(p)


# Cómo va el móvil en el soporte: giro de los ejes del dispositivo a los de la cámara
GIRO_MOVIL = {
    "VERTICAL": Matrix.Identity(3),
    "HORIZONTAL_IZQ": Matrix.Rotation(math.radians(90), 3, "Z"),
    "HORIZONTAL_DER": Matrix.Rotation(math.radians(-90), 3, "Z"),
}


def desde_orientacion(alfa, beta, gamma, montaje="HORIZONTAL_IZQ"):
    """DeviceOrientation (iPhone sin app): solo giro. Ejes de la Tierra con Z arriba, como Blender.
    R = Rz(α)·Rx(β)·Ry(γ) es el giro del dispositivo; la cámara trasera mira a su −Z."""
    R = (Matrix.Rotation(math.radians(alfa or 0), 3, "Z")
         @ Matrix.Rotation(math.radians(beta or 0), 3, "X")
         @ Matrix.Rotation(math.radians(gamma or 0), 3, "Y"))
    return R @ GIRO_MOVIL.get(montaje, Matrix.Identity(3)), None


def desde_freed(pan, tilt, roll, x, y, z, signos=(1, 1, 1)):
    """FreeD D1: pan/tilt/roll en grados, x/y/z en metros (ya convertidos). Pan sobre la vertical,
    tilt hacia arriba positivo, roll sobre el eje de la mirada. Cámara en reposo mirando a +Y."""
    sp, st, sr = signos
    R = (Matrix.Rotation(math.radians(-sp * pan), 3, "Z")
         @ Matrix.Rotation(math.radians(90 + st * tilt), 3, "X")
         @ Matrix.Rotation(math.radians(sr * roll), 3, "Z"))
    return R, Vector((x, y, z))


# ---------------------------------------------------------------- suavizado (filtro One Euro)

class _UnEuro:
    """Filtro One Euro: quieto, suaviza mucho (quita temblor); rápido, casi no retrasa."""

    def __init__(self, minimo=1.0, beta=0.05, d_corte=1.0):
        self.minimo, self.beta, self.d_corte = minimo, beta, d_corte
        self.x = self.dx = None
        self.t = None

    @staticmethod
    def _alfa(corte, dt):
        tau = 1.0 / (2 * math.pi * corte)
        return 1.0 / (1.0 + tau / max(dt, 1e-4))

    def __call__(self, t, x):
        if self.x is None:
            self.x, self.dx, self.t = x, x * 0, t
            return x
        dt = max(t - self.t, 1e-4)
        dx = (x - self.x) / dt
        a_d = self._alfa(self.d_corte, dt)
        self.dx = self.dx + (dx - self.dx) * a_d
        corte = self.minimo + self.beta * self.dx.length
        a = self._alfa(corte, dt)
        self.x = self.x + (x - self.x) * a
        self.t = t
        return self.x


class Suavizado:
    def __init__(self, fuerza=0.5):
        self.reiniciar(fuerza)

    def reiniciar(self, fuerza=0.5):
        # fuerza 0 = sin suavizar; 1 = mucho
        minimo = 10 ** (1.2 - 2.0 * fuerza)  # 15,8 Hz … 0,16 Hz
        self.pos = _UnEuro(minimo, 0.3)
        self.rot = _UnEuro(minimo, 0.3)
        self.q_prev = None

    def __call__(self, t, R, p):
        q = R.to_quaternion()
        if self.q_prev is not None and self.q_prev.dot(q) < 0:
            q.negate()  # mismo hemisferio que la anterior (si no, el filtro da la vuelta larga)
        self.q_prev = q
        qv = self.rot(t, Vector((q.w, q.x, q.y, q.z)))
        q2 = Quaternion((qv[0], qv[1], qv[2], qv[3])).normalized()
        p2 = self.pos(t, p) if p is not None else None
        return q2.to_matrix(), p2


# ---------------------------------------------------------------- buzón de poses (hilos → Blender)

class Buzon:
    """Las fuentes escriben desde sus hilos; Blender lee la última (o la de hace «retraso» s)."""

    def __init__(self, maximo=600):
        self.cola = deque(maxlen=maximo)
        self.cerrojo = threading.Lock()
        self.fuente = ""
        self.contador = 0
        self.extra = {}

    def poner(self, fuente, R, p, extra=None):
        with self.cerrojo:
            self.cola.append((time.perf_counter(), R, p))
            self.fuente = fuente
            self.contador += 1
            if extra:
                self.extra.update(extra)

    def ultima(self, retraso=0.0):
        with self.cerrojo:
            if not self.cola:
                return None
            if retraso <= 0:
                return self.cola[-1]
            objetivo = time.perf_counter() - retraso
            for t, R, p in reversed(self.cola):
                if t <= objetivo:
                    return (t, R, p)
            return self.cola[0]

    def edad(self):
        with self.cerrojo:
            return time.perf_counter() - self.cola[-1][0] if self.cola else 1e9


BUZON = Buzon()


# ---------------------------------------------------------------- alineación con la escena

class Alineacion:
    """Lleva el mundo de la fuente al de Blender: «poner a cero» hace que, en ese instante, la cámara
    de Blender quede donde estaba. Solo se gira alrededor de la vertical (la gravedad del móvil manda),
    salvo en fuentes sin gravedad (marcadores), donde se usa el giro completo."""

    def __init__(self):
        self.M = Matrix.Identity(4)
        self.escala = 1.0
        self.hecha = False

    def poner_a_cero(self, R_fuente, p_fuente, matriz_camara, solo_vertical=True):
        Rb = matriz_camara.to_3x3().normalized()
        pb = matriz_camara.translation.copy()
        if solo_vertical:
            def rumbo(R):
                f = R @ Vector((0, 0, -1))
                return math.atan2(f.y, f.x)
            giro = Matrix.Rotation(rumbo(Rb) - rumbo(R_fuente), 4, "Z")
        else:
            giro = (Rb @ R_fuente.transposed()).to_4x4()
        p0 = (p_fuente or Vector()) * self.escala
        self.M = Matrix.Translation(pb) @ giro @ Matrix.Translation(-p0)
        self.hecha = True

    def aplicar(self, R, p, base=None):
        """Matriz 4×4 de la cámara en Blender. Sin posición (solo giro) se usa la de «base»."""
        giro = self.M.to_3x3()
        Rw = giro @ R
        if p is None:
            pw = base.translation.copy() if base is not None else self.M.translation.copy()
        else:
            pw = self.M @ (p * self.escala)
        m = Rw.to_4x4()
        m.translation = pw
        return m
