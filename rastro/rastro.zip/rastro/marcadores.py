# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Tracking con marcadores impresos (ArUco) vistos por una webcam o por la cámara de un móvil (página /camara).

Lo normal: la webcam va encima de la cámara de rodaje mirando al techo, donde están pegados los
marcadores (no salen en la toma ni los tapa el actor). También vale con los marcadores en el croma.

- hoja(): PNG para imprimir (A4 a 300 ppp) con los marcadores numerados a su tamaño real.
- tablero(): ajedrez para calibrar la lente de la webcam.
- calibrar(): mira el tablero desde 20 posiciones y guarda la lente en ~/RASTRO/lente_webcam.json.
- arrancar(): hilo que lee la webcam, detecta marcadores y manda la pose al buzón. El marcador 0 es
  el origen; los demás se aprenden solos cuando se ven a la vez que uno ya conocido.
"""

import json
import math
import os
import threading
import time

import numpy as np

from . import dependencias, pose

CARPETA = os.path.join(os.path.expanduser("~"), "RASTRO")
LENTES = {"webcam": os.path.join(CARPETA, "lente_webcam.json"), "movil": os.path.join(CARPETA, "lente_movil.json")}
MOVIL = "MOVIL"  # en vez del número de webcam: las fotos que manda el móvil
MAPA = os.path.join(CARPETA, "mapa_marcadores.json")
DICCIONARIO = "DICT_4X4_50"
FIRMA = "RASTRO - creado por Tonino - @perdidadelalma"  # (OpenCV no dibuja tildes ni eñes)
_hilo = {"activo": False, "estado": "", "vistos": 0, "conocidos": 0, "calib": 0,
         "ids": [], "falta": None}  # falta: dónde mira la cámara (mundo de los marcadores) si ve menos de 2

# Cómo va la webcam respecto al objetivo de la cámara de rodaje (v_objetivo = M · v_webcam)
MONTAJES = {
    "ARRIBA": ((1, 0, 0), (0, 0, -1), (0, 1, 0)),     # mirando al techo, por encima de la cámara
    "IGUAL": ((1, 0, 0), (0, 1, 0), (0, 0, 1)),       # mirando a lo mismo que el objetivo
    "ABAJO": ((1, 0, 0), (0, 0, 1), (0, -1, 0)),      # mirando al suelo
}
_ajustes = {"camara": 0, "tam_cm": 15.0, "montaje": "ARRIBA"}


def _cv():
    dependencias.preparar_ruta()
    import cv2
    return cv2


def _detector(cv2):
    d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, DICCIONARIO))
    p = cv2.aruco.DetectorParameters()
    p.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
    return cv2.aruco.ArucoDetector(d, p), d


# ---------------------------------------------------------------- hojas para imprimir

def hoja(ruta, desde=0, cuantos=12, tam_cm=15.0):
    """Marcadores a tamaño real en hojas A4 (300 ppp). Devuelve las rutas de las páginas."""
    cv2 = _cv()
    _, dic = _detector(cv2)
    ppp = 300 / 2.54
    lado = int(round(tam_cm * ppp))
    W, H = int(21.0 * ppp), int(29.7 * ppp)
    margen = int(1.2 * ppp)
    cols = max(1, (W - margen) // (lado + margen))
    filas = max(1, (H - margen) // (lado + margen + int(0.8 * ppp)))
    por_hoja = cols * filas
    rutas = []
    for pagina in range(math.ceil(cuantos / por_hoja)):
        img = np.full((H, W), 255, np.uint8)
        for k in range(por_hoja):
            n = desde + pagina * por_hoja + k
            if n >= desde + cuantos:
                break
            c, f = k % cols, k // cols
            x = margen + c * (lado + margen)
            y = margen + f * (lado + margen + int(0.8 * ppp))
            # El texto va ENCIMA: marca el borde de arriba de la hoja (el plan dice hacia dónde apunta)
            cv2.putText(img, f"ARRIBA  -  RASTRO {n}  -  {tam_cm:g} cm", (x, y + int(0.55 * ppp)),
                        cv2.FONT_HERSHEY_SIMPLEX, 1.6, 0, 3)
            y += int(0.8 * ppp)
            img[y:y + lado, x:x + lado] = cv2.aruco.generateImageMarker(dic, n, lado)
        cv2.putText(img, FIRMA, (margen, H - int(0.5 * ppp)), cv2.FONT_HERSHEY_SIMPLEX, 1.2, 90, 2)
        r = ruta.replace(".png", f"_{pagina + 1}.png")
        cv2.imwrite(r, img)
        rutas.append(r)
    return rutas


def pdf(rutas, salida):
    """Junta las páginas (PNG a 300 ppp) en un PDF A4 a tamaño real: imprimir «tamaño real / 100 %»."""
    import zlib
    cv2 = _cv()
    NL = b"\n"
    objetos, paginas = [], []

    def nuevo(contenido):
        objetos.append(contenido)
        return len(objetos)

    raiz, arbol = nuevo(None), nuevo(None)
    for r in rutas:
        img = cv2.imread(r, cv2.IMREAD_COLOR)
        if img is None:
            continue
        h, w = img.shape[:2]
        gris = bool((img[:, :, 0] == img[:, :, 1]).all() and (img[:, :, 1] == img[:, :, 2]).all())
        datos = img[:, :, 0] if gris else img[:, :, ::-1]
        pw, ph = w * 72 / 300, h * 72 / 300            # puntos PDF a 300 ppp → A4 exacto
        flujo = zlib.compress(np.ascontiguousarray(datos).tobytes(), 6)
        cab = (b"<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /%s /BitsPerComponent 8 "
               b"/Filter /FlateDecode /Length %d >>" % (w, h, b"DeviceGray" if gris else b"DeviceRGB", len(flujo)))
        im = nuevo(cab + NL + b"stream" + NL + flujo + NL + b"endstream")
        dibujo = b"q %.2f 0 0 %.2f 0 0 cm /I Do Q" % (pw, ph)
        cont = nuevo(b"<< /Length %d >>" % len(dibujo) + NL + b"stream" + NL + dibujo + NL + b"endstream")
        paginas.append(nuevo(b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] /Contents %d 0 R "
                             b"/Resources << /XObject << /I %d 0 R >> >> >>" % (arbol, pw, ph, cont, im)))
    objetos[raiz - 1] = b"<< /Type /Catalog /Pages %d 0 R >>" % arbol
    objetos[arbol - 1] = b"<< /Type /Pages /Kids [%s] /Count %d >>" % (b" ".join(b"%d 0 R" % p for p in paginas), len(paginas))
    out = bytearray(b"%PDF-1.4" + NL)
    pos = []
    for i, o in enumerate(objetos, 1):
        pos.append(len(out))
        out += b"%d 0 obj" % i + NL + o + NL + b"endobj" + NL
    xref = len(out)
    out += b"xref" + NL + b"0 %d" % (len(objetos) + 1) + NL + b"0000000000 65535 f " + NL
    out += b"".join(b"%010d 00000 n " % p + NL for p in pos)
    out += b"trailer" + NL + b"<< /Size %d /Root %d 0 R >>" % (len(objetos) + 1, raiz) + NL
    out += b"startxref" + NL + b"%d" % xref + NL + b"%%EOF" + NL
    with open(salida, "wb") as f:
        f.write(out)
    return salida


def tablero(ruta, cols=9, filas=6, cuadro_mm=25.0):
    """Tablero de ajedrez (cols × filas esquinas interiores) para calibrar la lente."""
    cv2 = _cv()
    ppp = 300 / 25.4
    c = int(round(cuadro_mm * ppp))
    W, H = int(297 * ppp), int(210 * ppp)  # A4 apaisado
    img = np.full((H, W), 255, np.uint8)
    x0, y0 = (W - c * (cols + 1)) // 2, (H - c * (filas + 1)) // 2
    for j in range(filas + 1):
        for i in range(cols + 1):
            if (i + j) % 2 == 0:
                img[y0 + j * c:y0 + (j + 1) * c, x0 + i * c:x0 + (i + 1) * c] = 0
    cv2.putText(img, FIRMA, (x0, img.shape[0] - 120), cv2.FONT_HERSHEY_SIMPLEX, 1.2, 90, 2)
    cv2.putText(img, f"RASTRO - calibracion {cols}x{filas} - cuadros de {cuadro_mm:g} mm (comprueba con una regla)",
                (x0, y0 - 40), cv2.FONT_HERSHEY_SIMPLEX, 1.2, 0, 3)
    cv2.imwrite(ruta, img)
    return ruta


# ---------------------------------------------------------------- de dónde salen las imágenes

class _Webcam:
    def __init__(self, n):
        cv2 = _cv()
        self.cap = cv2.VideoCapture(n, cv2.CAP_DSHOW) if os.name == "nt" else cv2.VideoCapture(n)
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

    def leer(self):
        return self.cap.read()

    def soltar(self):
        self.cap.release()


class _Movil:
    """Las fotos JPEG que manda el móvil al servidor HTTPS (receptor)."""

    def leer(self):
        from . import receptor
        datos = receptor.foto_nueva(1.0)
        if datos is None:
            return False, None
        cv2 = _cv()
        img = cv2.imdecode(np.frombuffer(datos, np.uint8), cv2.IMREAD_COLOR)
        return img is not None, img

    def soltar(self):
        pass


def _abrir(camara):
    return _Movil() if camara == MOVIL else _Webcam(camara)


def _ruta_lente(camara):
    return LENTES["movil" if camara == MOVIL else "webcam"]


# ---------------------------------------------------------------- lente

def lente(camara=0):
    ruta = _ruta_lente(camara)
    if os.path.exists(ruta):
        with open(ruta, encoding="utf-8") as f:
            d = json.load(f)
        return np.array(d["K"]), np.array(d["dist"]), tuple(d["tam"])
    return None


def lente_aproximada(ancho, alto, campo_h=78.0):
    """Sin calibrar: lente ideal con el campo de visión horizontal de la webcam (78° es lo típico)."""
    f = (ancho / 2) / math.tan(math.radians(campo_h) / 2)
    return np.array([[f, 0, ancho / 2], [0, f, alto / 2], [0, 0, 1]], float), np.zeros(5), (ancho, alto)


def calibrar(camara=0, cols=9, filas=6, cuadro_mm=25.0, vistas=20, al_acabar=None):
    """Hilo: busca el tablero en la webcam (o el móvil); cada vez que lo ve (y te has movido) guarda una vista."""
    def hilo():
        cv2 = _cv()
        cap = _abrir(camara)
        obj = np.zeros((cols * filas, 3), np.float32)
        obj[:, :2] = np.mgrid[0:cols, 0:filas].T.reshape(-1, 2) * cuadro_mm / 1000.0
        pts_obj, pts_img, ultimo, tam = [], [], 0.0, None
        _hilo.update(calib=0, estado="Enseña el tablero a la webcam desde distintos ángulos…")
        inicio = time.time()
        while len(pts_img) < vistas and time.time() - inicio < 300:
            ok, img = cap.leer()
            if not ok:
                time.sleep(0.05)
                continue
            gris = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            tam = gris.shape[::-1]
            hay, esq = cv2.findChessboardCorners(gris, (cols, filas), cv2.CALIB_CB_FAST_CHECK)
            if hay and time.time() - ultimo > 0.8:
                esq = cv2.cornerSubPix(gris, esq, (11, 11), (-1, -1),
                                       (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001))
                pts_obj.append(obj)
                pts_img.append(esq)
                ultimo = time.time()
                _hilo["calib"] = len(pts_img)
        cap.soltar()
        if len(pts_img) < 8:
            _hilo["estado"] = "Pocas vistas del tablero: vuelve a probar con más luz."
        else:
            err, K, dist, _r, _t = cv2.calibrateCamera(pts_obj, pts_img, tam, None, None)
            os.makedirs(CARPETA, exist_ok=True)
            with open(_ruta_lente(camara), "w", encoding="utf-8") as f:
                json.dump({"K": K.tolist(), "dist": dist.ravel().tolist(), "tam": list(tam), "error_px": err}, f)
            _hilo["estado"] = f"Lente calibrada (error {err:.2f} px)."
        if al_acabar:
            al_acabar()
    threading.Thread(target=hilo, daemon=True).start()


# ---------------------------------------------------------------- mapa de marcadores

def _a_matriz(rvec, tvec):
    cv2 = _cv()
    R, _ = cv2.Rodrigues(rvec)
    m = np.eye(4)
    m[:3, :3], m[:3, 3] = R, tvec.ravel()
    return m


def leer_mapa():
    if os.path.exists(MAPA):
        with open(MAPA, encoding="utf-8") as f:
            return {int(k): np.array(v) for k, v in json.load(f).items()}
    return {}


def guardar_mapa(mapa):
    os.makedirs(CARPETA, exist_ok=True)
    with open(MAPA, "w", encoding="utf-8") as f:
        json.dump({str(k): v.tolist() for k, v in mapa.items()}, f)


def borrar_mapa():
    if os.path.exists(MAPA):
        os.remove(MAPA)


# OpenCV: cámara con x derecha, y abajo, z al frente. Blender: x derecha, y arriba, z hacia atrás.
_CV_A_BL = np.diag([1.0, -1.0, -1.0])


def pose_de_imagen(img, K, dist, tam_m, mapa, aprender=True):
    """Pose de la cámara (4×4, mundo de los marcadores) en una imagen, o None. Actualiza el mapa."""
    cv2 = _cv()
    det, _ = _detector(cv2)
    esquinas, ids, _ = det.detectMarkers(img)
    if ids is None or len(ids) == 0:
        return None, 0
    h = tam_m / 2
    obj = np.array([[-h, h, 0], [h, h, 0], [h, -h, 0], [-h, -h, 0]], np.float32)
    vistos = {}
    for c, i in zip(esquinas, ids.ravel()):
        ok, rvec, tvec = cv2.solvePnP(obj, c.reshape(4, 2), K, dist, flags=cv2.SOLVEPNP_IPPE_SQUARE)
        if ok:
            vistos[int(i)] = (_a_matriz(rvec, tvec), cv2.contourArea(c.reshape(4, 2)))
    if not mapa and 0 in vistos:
        mapa[0] = np.eye(4)  # el marcador 0 es el origen del mundo
    # Pose de la cámara según cada marcador conocido; manda el que se ve más grande
    candidatas = [(area, m_mundo @ np.linalg.inv(m_cam)) for i, (m_cam, area) in vistos.items()
                  if (m_mundo := mapa.get(i)) is not None]
    if not candidatas:
        return None, len(vistos)
    candidatas.sort(key=lambda x: -x[0])
    T = candidatas[0][1]
    # Afinar con todas las esquinas de todos los marcadores conocidos a la vez (más preciso que uno solo)
    obj_w, img_p = [], []
    for c, i in zip(esquinas, ids.ravel()):
        m_mundo = mapa.get(int(i))
        if m_mundo is not None:
            pts = (m_mundo @ np.c_[obj, np.ones(4)].T)[:3].T
            obj_w.append(pts)
            img_p.append(c.reshape(4, 2))
    if len(obj_w) >= 2:
        inv = np.linalg.inv(T)
        rvec0, _ = cv2.Rodrigues(inv[:3, :3])
        ok, rvec, tvec = cv2.solvePnP(np.vstack(obj_w).astype(np.float32), np.vstack(img_p).astype(np.float32),
                                      K, dist, rvec0, inv[:3, 3].reshape(3, 1), useExtrinsicGuess=True,
                                      flags=cv2.SOLVEPNP_ITERATIVE)
        if ok:
            T = np.linalg.inv(_a_matriz(rvec, tvec))
    if aprender:
        for i, (m_cam, area) in vistos.items():
            if i not in mapa and area > 400:
                mapa[i] = T @ m_cam
    return T, len(vistos)


def _bucle(camara, tam_m, montaje):
    cap = _abrir(camara)
    ok, img = cap.leer()
    inicio = time.time()
    while not ok and _hilo["activo"] and camara == MOVIL and time.time() - inicio < 120:
        _hilo["estado"] = "Esperando la cámara del móvil (abre /camara y pulsa Empezar)…"
        ok, img = cap.leer()
    if not ok:
        _hilo.update(activo=False, estado="No llega la cámara del móvil." if camara == MOVIL else f"No se abre la webcam {camara}.")
        cap.soltar()
        return
    L = lente(camara)
    if L and tuple(L[2]) != (img.shape[1], img.shape[0]):
        L = None  # calibrada a otra resolución (o con el móvil girado): mejor la aproximada
    # Campo de visión típico: webcam ~78°, cámara principal de un móvil ~66° (en horizontal)
    K, dist, _ = L if L else lente_aproximada(img.shape[1], img.shape[0], 66.0 if camara == MOVIL else 78.0)
    mapa = leer_mapa()
    M = np.array(MONTAJES.get(montaje, MONTAJES["IGUAL"]), float)
    from mathutils import Matrix, Vector
    ultimo_guardado = time.time()
    _hilo["estado"] = "Buscando marcadores…" + ("" if L else " (lente sin calibrar)")
    while _hilo["activo"]:
        ok, img = cap.leer()
        if not ok:
            continue
        T, n = pose_de_imagen(img, K, dist, tam_m, mapa)
        _hilo.update(vistos=n, conocidos=len(mapa), ids=sorted(mapa), falta=_donde_mira(T, mapa) if n < 2 else None)
        if n == 0:
            _hilo["falta"] = "ninguno"
        if T is None:
            continue
        R_web = T[:3, :3] @ _CV_A_BL           # ejes de la webcam al convenio de cámara de Blender
        R_obj = R_web @ M.T                    # del soporte de la webcam al objetivo
        pose.BUZON.poner("Marcadores", Matrix(R_obj.tolist()), Vector(T[:3, 3].tolist()))
        if time.time() - ultimo_guardado > 5:
            guardar_mapa(mapa)
            ultimo_guardado = time.time()
    guardar_mapa(mapa)
    cap.soltar()


def _donde_mira(T, mapa):
    """Punto del techo / la pared (el plano del marcador 0) al que apunta el centro de la imagen, o None."""
    if T is None or 0 not in mapa:
        return None
    o, d = T[:3, 3], T[:3, :3] @ np.array([0.0, 0.0, 1.0])   # posición y eje óptico (OpenCV: z al frente)
    p0, nrm = mapa[0][:3, 3], mapa[0][:3, 2]
    den = float(d @ nrm)
    if abs(den) < 1e-3:
        return None
    t = float((p0 - o) @ nrm) / den
    return (o + t * d).tolist() if t > 0 else None


def ajustar(camara=None, tam_cm=None, montaje=None):
    if camara is not None:
        _ajustes["camara"] = camara
    if tam_cm is not None:
        _ajustes["tam_cm"] = tam_cm
    if montaje is not None:
        _ajustes["montaje"] = montaje


def arrancar(context=None):
    parar()
    if context is not None:
        a = context.scene.rastro
        ajustar(MOVIL if a.ojo == "MOVIL" else a.webcam, a.tam_marcador, a.montaje_webcam)
    _hilo["activo"] = True
    threading.Thread(target=_bucle, args=(_ajustes["camara"], _ajustes["tam_cm"] / 100.0, _ajustes["montaje"]),
                     daemon=True).start()
    quien = "Cámara del móvil" if _ajustes["camara"] == MOVIL else f"Webcam {_ajustes['camara']}"
    return f"{quien} · marcadores de {_ajustes['tam_cm']:g} cm"


def parar():
    _hilo["activo"] = False


def estado():
    return dict(_hilo)
