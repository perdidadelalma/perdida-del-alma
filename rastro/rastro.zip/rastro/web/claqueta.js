/* RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma) · GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt) */
// Claqueta: el micrófono del móvil escucha y, al oír un golpe seco, avisa a Blender (POST /claqueta).
// Se mete dentro de cada página (receptor.py) y se activa con la casilla «Escuchar la claqueta».
const Claqueta = (() => {
  let ctx = null, flujo = null, mirar = null, fondo = 0.01, ultimo = 0;

  function aviso(t) {
    const el = document.getElementById("claqueta-aviso");
    if (el) { el.textContent = t; el.className = "ok"; }
  }

  async function empezar() {
    if (ctx) return;
    try {
      flujo = await navigator.mediaDevices.getUserMedia({ audio: {
        echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
    } catch (e) { aviso("Sin micrófono: " + e.message); return; }
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === "suspended") ctx.resume();
    const fuente = ctx.createMediaStreamSource(flujo);
    const an = ctx.createAnalyser();
    an.fftSize = 512;
    fuente.connect(an);
    const datos = new Float32Array(an.fftSize);
    aviso("Escuchando la claqueta…");
    mirar = setInterval(() => {
      an.getFloatTimeDomainData(datos);
      let pico = 0, suma = 0;
      for (const v of datos) { const a = Math.abs(v); if (a > pico) pico = a; suma += a * a; }
      const rms = Math.sqrt(suma / datos.length);
      const ahora = performance.now();
      // Golpe: pico alto y muy por encima del ruido de fondo de la sala; luego 1,5 s sin escuchar
      if (pico > 0.35 && rms > fondo * 8 && ahora - ultimo > 1500) {
        ultimo = ahora;
        fetch("/claqueta", { method: "POST", body: "{}" }).catch(() => {});
        aviso("¡Claqueta! " + new Date().toLocaleTimeString());
        if (navigator.vibrate) navigator.vibrate(120);
      }
      fondo = fondo * 0.995 + rms * 0.005;
    }, 10);
  }

  function parar() {
    clearInterval(mirar);
    if (flujo) flujo.getTracks().forEach(t => t.stop());
    if (ctx) ctx.close();
    ctx = null; flujo = null;
    aviso("");
  }

  return { empezar, parar };
})();

function casillaClaqueta() {
  const c = document.getElementById("claqueta");
  return c && c.checked;
}

// Rodaje: estado de Blender, «¡corten!» (por voz o con el botón), plano y listado de tomas con buena / mala.
const Rodaje = (() => {
  let estado = {}, voz = null, oyendo = false, avisoVoz = "";
  const Reconocer = window.SpeechRecognition || window.webkitSpeechRecognition;

  function orden(d) { return fetch("/orden", { method: "POST", body: JSON.stringify(d) }).catch(() => {}); }

  function montar() {
    const sitio = document.getElementById("datos");
    if (!sitio) return;
    const s = document.createElement("section");
    s.id = "rodaje";
    s.innerHTML = `
      <div id="r-aviso" class="aviso-hueco" hidden></div>
      <div id="r-estado" class="rodaje-estado">Conectando con Blender…</div>
      <div class="fila"><button id="r-esperar" class="gris">Esperar claqueta</button>
        <button id="r-corten" class="parar" hidden>¡CORTEN!</button></div>
      <div class="fila plano"><button id="r-menos" class="gris">−</button><span id="r-plano">Plano 1</span>
        <button id="r-mas" class="gris">+</button></div>
      <p id="r-voz" class="pequeno"></p>
      <ol id="r-tomas" class="tomas"></ol>`;
    sitio.after(s);
    document.getElementById("r-esperar").onclick = () => orden({ orden: "esperar" });
    document.getElementById("r-corten").onclick = () => orden({ orden: "corten" });
    document.getElementById("r-menos").onclick = () => orden({ orden: "plano", cambio: -1 });
    document.getElementById("r-mas").onclick = () => orden({ orden: "plano", cambio: 1 });
    setInterval(leer, 700);
    leer();
  }

  function nombre(p, t) { return `P${String(p).padStart(2, "0")} T${String(t).padStart(2, "0")}`; }

  async function leer() {
    try { estado = await (await fetch("/estado", { cache: "no-store" })).json(); } catch (e) { return; }
    const sig = nombre(estado.plano, estado.toma);
    const el = document.getElementById("r-estado");
    if (estado.estado === "grabando") {
      el.textContent = `● GRABANDO ${sig} · ${estado.segundos.toFixed(1)} s`; el.className = "rodaje-estado mal";
    } else if (estado.estado === "esperando") {
      el.textContent = `Esperando la claqueta… (${sig})`; el.className = "rodaje-estado ok";
    } else {
      el.textContent = `Listo · siguiente ${sig}`; el.className = "rodaje-estado";
    }
    document.getElementById("r-corten").hidden = estado.estado !== "grabando";
    document.getElementById("r-esperar").hidden = estado.estado === "grabando";
    document.getElementById("r-esperar").textContent = estado.estado === "esperando" ? "Cancelar espera" : "Esperar claqueta";
    document.getElementById("r-plano").textContent = `Plano ${estado.plano}`;
    const av = document.getElementById("r-aviso");
    av.textContent = estado.aviso || ""; av.hidden = !estado.aviso;
    pintarTomas(estado.tomas || []);
    escucharCorten(estado.estado === "grabando" && casillaClaqueta());
  }

  function pintarTomas(lista) {
    const ol = document.getElementById("r-tomas");
    ol.innerHTML = "";
    for (const t of lista.slice().reverse()) {
      const li = document.createElement("li");
      li.className = t.valor;
      li.innerHTML = `<span>${t.id} · ${Number(t.segundos).toFixed(1)} s</span>`;
      for (const [valor, signo] of [["buena", "✔"], ["mala", "✘"]]) {
        const b = document.createElement("button");
        b.textContent = signo;
        b.className = "valor " + valor + (t.valor === valor ? " elegido" : "");
        b.onclick = () => orden({ orden: "valorar", id: t.id, valor: t.valor === valor ? "" : valor });
        li.appendChild(b);
      }
      ol.appendChild(li);
    }
  }

  // «¡Corten!»: reconocimiento de voz del navegador mientras se graba (si el móvil lo tiene)
  function escucharCorten(si) {
    const nota = document.getElementById("r-voz");
    if (!Reconocer) { nota.textContent = si ? "Este navegador no reconoce la voz: pulsa ¡CORTEN!" : ""; return; }
    if (si && !oyendo) {
      oyendo = true;
      voz = new Reconocer();
      voz.lang = "es-ES"; voz.continuous = true; voz.interimResults = true;
      voz.onresult = e => {
        for (let i = e.resultIndex; i < e.results.length; i++) {
          if (/\b(corten|corte|corta|cut)\b/i.test(e.results[i][0].transcript)) {
            orden({ orden: "corten" });
            nota.textContent = "«¡Corten!» oído.";
            if (navigator.vibrate) navigator.vibrate([80, 60, 80]);
          }
        }
      };
      voz.onerror = e => { avisoVoz = "No puedo oír «corten» (" + e.error + "): pulsa ¡CORTEN!"; };
      voz.onend = () => { if (oyendo) { try { voz.start(); } catch (e) {} } };
      try { voz.start(); nota.textContent = "Di «¡corten!» para acabar la toma."; } catch (e) {}
    } else if (!si && oyendo) {
      oyendo = false;
      try { voz.stop(); } catch (e) {}
      nota.textContent = avisoVoz;
    } else if (si && avisoVoz) {
      nota.textContent = avisoVoz;
    }
  }

  document.addEventListener("DOMContentLoaded", montar);
  return {};
})();
