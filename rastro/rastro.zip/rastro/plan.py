# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Dónde poner los marcadores: una rejilla que cubre la zona por donde se mueve la cámara, con la separación
justa para que el móvil (o la webcam) vea siempre 2 o más a la vez, y el tamaño para que se lean bien.

- calcular(): la rejilla (en metros, respecto al marcador 0) y el tamaño recomendado.
- a_escena(): los marcadores en la escena de Blender (planos con su imagen). «RASTRO marcador 0» es el
  ancla: dónde esté en Blender es dónde está el marcador 0 en el plató (directo.py lo usa para alinear).
- plano(): PNG para imprimir con las medidas desde el marcador 0.
"""

import math
import os

import numpy as np

from . import marcadores

CARPETA = os.path.join(os.path.expanduser("~"), "RASTRO", "imprimir")
COLECCION = "RASTRO · plan de marcadores"
ANCLA = "RASTRO marcador 0"
MAX = 50  # el diccionario 4×4_50

# Cómo va cada marcador según dónde se pegue (ejes del marcador → Blender): x, y (arriba de la hoja), z (cara)
GIROS = {
    "ARRIBA": (0.0, math.pi, 0.0),       # en el techo, boca abajo, con el «ARRIBA» de la hoja hacia el decorado (+Y)
    "IGUAL": (math.pi / 2, 0.0, 0.0),    # en la pared o el croma de enfrente, mirando a la cámara
    "ABAJO": (0.0, 0.0, 0.0),            # en el suelo, boca arriba, con el «ARRIBA» hacia el decorado
}


def campo_corto(movil=True):
    """Campo de visión del lado corto de la imagen (grados): móvil ~66° y webcam ~78° en horizontal, a 16:9."""
    h = 66.0 if movil else 78.0
    return math.degrees(2 * math.atan(math.tan(math.radians(h / 2)) * 9 / 16))


def zona_de_camara(scene, ancho, fondo):
    """Rectángulo (x0, x1, y0, y1) por donde va la cámara: su animación si la tiene, si no ancho × fondo a su alrededor."""
    cam = scene.camera
    xs, ys = [], []
    if cam and cam.animation_data and cam.animation_data.action:
        actual = scene.frame_current
        for f in range(scene.frame_start, scene.frame_end + 1, max(1, (scene.frame_end - scene.frame_start) // 60)):
            scene.frame_set(f)
            p = cam.matrix_world.translation
            xs.append(p.x)
            ys.append(p.y)
        scene.frame_set(actual)
    if not xs or (max(xs) - min(xs) < 0.2 and max(ys) - min(ys) < 0.2):
        c = cam.matrix_world.translation if cam else None
        cx, cy = (c.x, c.y) if c else (0.0, 0.0)
        return cx - ancho / 2, cx + ancho / 2, cy - fondo / 2, cy + fondo / 2
    return min(xs), max(xs), min(ys), max(ys)


def calcular(zona, distancia, movil=True):
    """Rejilla de marcadores para una zona (metros) a `distancia` de la cámara. Devuelve (puntos, separación, tam_cm, huella)."""
    huella = 2 * distancia * math.tan(math.radians(campo_corto(movil) / 2))  # lo que ve el lado corto de la imagen
    sep = huella / 2                                                        # así entran 2 o más en cualquier sitio
    x0, x1, y0, y1 = zona
    while True:
        nx = max(1, math.ceil((x1 - x0) / sep) + 1)
        ny = max(1, math.ceil((y1 - y0) / sep) + 1)
        if nx * ny <= MAX:
            break
        sep *= 1.15
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    pts = [(cx + (i - (nx - 1) / 2) * sep, cy + (j - (ny - 1) / 2) * sep) for j in range(ny) for i in range(nx)]
    # El 0 en el centro y luego por cercanía: si solo pegas los primeros, quedan en el centro
    pts.sort(key=lambda p: (p[0] - cx) ** 2 + (p[1] - cy) ** 2)
    # ~60 píxeles por marcador en 720 de alto; entre 6 y 18 cm (más no cabe bien en un A4)
    tam = min(18.0, max(6.0, round(huella / 12 * 100)))
    return pts, sep, tam, huella


def a_escena(context, pts, tam_cm, montaje, fijo):
    """Planos con la imagen de cada marcador en la escena, en la colección del plan (la rehace).
    Techo/suelo: pts son (x, y) y `fijo` la altura. Pared: pts son (x, z) y `fijo` la Y de la pared."""
    import bpy
    cv2 = marcadores._cv()
    _, dic = marcadores._detector(cv2)
    os.makedirs(os.path.join(CARPETA, "escena"), exist_ok=True)
    col = bpy.data.collections.get(COLECCION)
    if col:
        for o in list(col.objects):
            bpy.data.objects.remove(o, do_unlink=True)
    else:
        col = bpy.data.collections.new(COLECCION)
        context.scene.collection.children.link(col)
    t = tam_cm / 100.0
    h = t / 2
    for n, (x, y) in enumerate(pts):
        ruta = os.path.join(CARPETA, "escena", f"m_{n:02d}.png")  # (solo para verlos en Blender, no se imprimen)
        if not os.path.exists(ruta):
            m = cv2.aruco.generateImageMarker(dic, n, 200)
            cv2.imwrite(ruta, np.pad(m, 25, constant_values=255))
        malla = bpy.data.meshes.new(f"RASTRO marcador {n}")
        malla.from_pydata([(-h, -h, 0), (h, -h, 0), (h, h, 0), (-h, h, 0)], [], [(0, 1, 2, 3)])
        uv = malla.uv_layers.new()
        for i, c in enumerate(((0, 0), (1, 0), (1, 1), (0, 1))):
            uv.data[i].uv = c
        malla.materials.append(_material(n, ruta))
        ob = bpy.data.objects.new(f"RASTRO marcador {n}", malla)
        ob["rastro_marcador"] = n
        ob.location = (x, fijo, y) if montaje == "IGUAL" else (x, y, fijo)
        ob.rotation_euler = GIROS[montaje]
        col.objects.link(ob)
    return col


def _material(n, ruta):
    import bpy
    nombre = f"RASTRO marcador {n}"
    mat = bpy.data.materials.get(nombre) or bpy.data.materials.new(nombre)
    mat.use_nodes = True
    nt = mat.node_tree
    bsdf = next((x for x in nt.nodes if x.type == "BSDF_PRINCIPLED"), None)
    tex = next((x for x in nt.nodes if x.type == "TEX_IMAGE"), None) or nt.nodes.new("ShaderNodeTexImage")
    img = bpy.data.images.load(ruta, check_existing=True)
    tex.image = img
    if bsdf:
        nt.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    mat.diffuse_color = (0.9, 0.9, 0.9, 1)
    return mat


def plano(ruta, pts, tam_cm, sep, distancia, montaje):
    """PNG A4 apaisado: la rejilla vista desde la cámara con cada número y su distancia al 0 en cm."""
    cv2 = marcadores._cv()
    W, H = 3508, 2480
    img = np.full((H, W, 3), 255, np.uint8)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    x0, y0 = pts[0]
    ancho = max(xs) - min(xs) + sep
    alto = max(ys) - min(ys) + sep
    esc = min((W - 600) / ancho, (H - 900) / alto)
    ox = W / 2 - (min(xs) + max(xs)) / 2 * esc
    oy = H / 2 + 120 + (min(ys) + max(ys)) / 2 * esc

    def a_px(x, y):
        return int(ox + x * esc), int(oy - y * esc)

    donde = {"ARRIBA": "en el TECHO", "IGUAL": "en la PARED / el CROMA de enfrente", "ABAJO": "en el SUELO"}[montaje]
    eje_y = "hacia arriba" if montaje == "IGUAL" else "hacia el decorado"
    txt = [f"RASTRO - plan de marcadores {donde}  ({len(pts)} marcadores de {tam_cm:g} cm, cada {sep * 100:.0f} cm)",
           f"Mira el plano como si estuvieras en la camara mirando al decorado. Medidas desde el CENTRO del marcador 0:",
           f"derecha (+) / izquierda (-)  y  {eje_y} (+). Pega cada hoja con su 'ARRIBA' {eje_y}.",
           f"Distancia de la camara a los marcadores: {distancia:g} m."]
    for k, t in enumerate(txt):
        cv2.putText(img, t, (120, 130 + k * 75), cv2.FONT_HERSHEY_SIMPLEX, 1.55 if k == 0 else 1.25, (0, 0, 0), 4 if k == 0 else 3)
    # rejilla suave
    for x in sorted(set(round(v, 4) for v in xs)):
        cv2.line(img, a_px(x, min(ys) - sep / 2), a_px(x, max(ys) + sep / 2), (225, 225, 225), 3)
    for y in sorted(set(round(v, 4) for v in ys)):
        cv2.line(img, a_px(min(xs) - sep / 2, y), a_px(max(xs) + sep / 2, y), (225, 225, 225), 3)
    lado = max(40, int(tam_cm / 100 * esc))
    for n, (x, y) in enumerate(pts):
        cx, cy = a_px(x, y)
        color = (60, 60, 220) if n == 0 else (0, 0, 0)
        cv2.rectangle(img, (cx - lado // 2, cy - lado // 2), (cx + lado // 2, cy + lado // 2), color, 6)
        cv2.arrowedLine(img, (cx, cy + lado // 4), (cx, cy - lado // 2 - 30), color, 4, tipLength=0.3)
        cv2.putText(img, str(n), (cx - 30, cy + lado // 2 + 70), cv2.FONT_HERSHEY_SIMPLEX, 2.2, color, 6)
        dx, dy = (x - x0) * 100, (y - y0) * 100
        cv2.putText(img, f"{dx:+.0f} / {dy:+.0f}", (cx - 110, cy + lado // 2 + 125), cv2.FONT_HERSHEY_SIMPLEX, 1.1,
                    (90, 90, 90), 3)
    arriba = "techo" if montaje == "IGUAL" else "decorado / hacia donde mira la camara"
    cv2.putText(img, f"^  {arriba}  ^", (W // 2 - 420, 520), cv2.FONT_HERSHEY_SIMPLEX, 1.4, (60, 60, 220), 3)
    cv2.putText(img, marcadores.FIRMA, (120, H - 90), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (90, 90, 90), 2)
    cv2.imwrite(ruta, img)
    return ruta
