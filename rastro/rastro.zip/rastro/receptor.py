# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Por dónde llegan las poses en directo.

- Servidor HTTPS en la red local: sirve las páginas del móvil (/android con WebXR, /iphone con el
  giroscopio) y recibe sus poses en POST /pose. HTTPS hace falta porque los navegadores solo dejan
  usar la realidad aumentada y los sensores en páginas seguras: el certificado se crea aquí y el
  móvil pide aceptarlo una vez.
- FreeD por UDP: el protocolo de los platós virtuales (trackers profesionales, cámaras robotizadas y
  apps de iPhone como FREED Tracker o VRL Cam).
"""

import collections
import datetime
import ipaddress
import json
import os
import socket
import ssl
import struct
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import pose

WEB = os.path.join(os.path.dirname(__file__), "web")
CARPETA = os.path.join(os.path.expanduser("~"), "RASTRO")

CLAQUETA = {"n": 0, "t": 0.0}
PEDIDOS = collections.deque()  # órdenes del móvil (corten, valorar, plano…): las atiende directo.py en el hilo de Blender
RODAJE = {"estado": "listo", "plano": 1, "toma": 1, "segundos": 0, "tomas": []}  # lo que ve el móvil en /estado  # cada golpe que oye el móvil (directo.py empieza la toma si está esperando)
_estado = {"https": None, "udp": None, "montaje": "HORIZONTAL_IZQ", "signos": (1, 1, 1), "puerto": None}


def ip_local():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def ips():
    """[(ip, descripción)] de este ordenador: primero la de la wifi/cable, luego Tailscale (va por internet)."""
    vistas = [ip_local()]
    try:
        vistas += socket.gethostbyname_ex(socket.gethostname())[2]
    except OSError:
        pass
    salida = []
    for ip in vistas:
        if ip.startswith("127.") or ip in (x for x, _ in salida):
            continue
        tailscale = ipaddress.ip_address(ip) in ipaddress.ip_network("100.64.0.0/10")
        salida.append((ip, "Tailscale (por internet)" if tailscale else "wifi / cable"))
    salida.sort(key=lambda x: x[1].startswith("Tailscale"))
    return salida or [("127.0.0.1", "solo este ordenador")]


# ---------------------------------------------------------------- certificado propio

def certificado():
    """Certificado autofirmado para las IP de este ordenador (se rehace si cambian)."""
    os.makedirs(CARPETA, exist_ok=True)
    crt, key = os.path.join(CARPETA, "rastro.crt"), os.path.join(CARPETA, "rastro.key")
    todas = [ip for ip, _ in ips()]
    ip = ",".join(todas)
    marca = os.path.join(CARPETA, "rastro.ip")
    if os.path.exists(crt) and os.path.exists(key) and os.path.exists(marca) and open(marca).read() == ip:
        return crt, key
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID
    k = ec.generate_private_key(ec.SECP256R1())
    nombre = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "RASTRO")])
    ahora = datetime.datetime.now(datetime.timezone.utc)
    alt = x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address(x)) for x in todas]
                                      + [x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))])
    c = (x509.CertificateBuilder().subject_name(nombre).issuer_name(nombre).public_key(k.public_key())
         .serial_number(x509.random_serial_number()).not_valid_before(ahora - datetime.timedelta(days=1))
         .not_valid_after(ahora + datetime.timedelta(days=3650)).add_extension(alt, critical=False)
         .sign(k, hashes.SHA256()))
    open(crt, "wb").write(c.public_bytes(serialization.Encoding.PEM))
    open(key, "wb").write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                          serialization.NoEncryption()))
    open(marca, "w").write(ip)
    return crt, key


# ---------------------------------------------------------------- servidor del móvil

class _Pagina(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _enviar(self, cuerpo, tipo="text/plain; charset=utf-8", codigo=200):
        datos = cuerpo if isinstance(cuerpo, bytes) else cuerpo.encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(datos)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(datos)

    def do_GET(self):
        if self.path.split("?")[0] == "/estado":
            return self._enviar(json.dumps(RODAJE), "application/json")
        rutas = {"/": "inicio.html", "/android": "android.html", "/iphone": "iphone.html", "/camara": "camara.html"}
        nombre = rutas.get(self.path.split("?")[0])
        if nombre is None:
            return self._enviar("no", codigo=404)
        with open(os.path.join(WEB, nombre), encoding="utf-8") as f:
            pagina = f.read()
        with open(os.path.join(WEB, "estilo.css"), encoding="utf-8") as f:
            pagina = pagina.replace("/*ESTILO*/", f.read())
        with open(os.path.join(WEB, "claqueta.js"), encoding="utf-8") as f:
            pagina = pagina.replace("/*CLAQUETA*/", f.read())  # una sola petición: el móvil no pide nada más
        self._enviar(pagina, "text/html; charset=utf-8")

    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0") or 0)
        if self.path == "/foto" and 0 < n < 8_000_000:
            poner_foto(self.rfile.read(n))
            return self._enviar("ok")
        if self.path == "/orden":
            try:
                d = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return self._enviar("mal", codigo=400)
            PEDIDOS.append(d)
            return self._enviar("ok")
        if self.path == "/claqueta":
            self.rfile.read(n)
            CLAQUETA["n"] += 1
            CLAQUETA["t"] = time.perf_counter()
            return self._enviar("ok")
        if self.path != "/pose":
            return self._enviar("no", codigo=404)
        try:
            d = json.loads(self.rfile.read(n) or b"{}")
            if d.get("tipo") == "xr":
                R, p = pose.desde_webxr(d["p"], d["q"])
                pose.BUZON.poner("Android (WebXR)", R, p)
            elif d.get("tipo") == "giro":
                R, p = pose.desde_orientacion(d.get("a"), d.get("b"), d.get("g"), _estado["montaje"])
                pose.BUZON.poner("iPhone (giroscopio)", R, p)
            self._enviar("ok")
        except (ValueError, KeyError, TypeError):
            self._enviar("mal", codigo=400)


# ---------------------------------------------------------------- fotos de la cámara del móvil (para los marcadores)

_foto = {"datos": None, "n": 0, "leida": 0}
_hay_foto = threading.Condition()


def poner_foto(datos):
    with _hay_foto:
        _foto["datos"] = datos
        _foto["n"] += 1
        _hay_foto.notify_all()


def foto_nueva(espera=1.0):
    """El último JPEG del móvil que no se haya leído todavía (espera hasta `espera` s), o None."""
    with _hay_foto:
        if _foto["n"] == _foto["leida"]:
            _hay_foto.wait(espera)
        if _foto["n"] == _foto["leida"]:
            return None
        _foto["leida"] = _foto["n"]
        return _foto["datos"]


def https_activo():
    return _estado["https"] is not None


def arrancar_https(puerto=8443, ip=""):
    parar_https()
    crt, key = certificado()
    srv = ThreadingHTTPServer(("0.0.0.0", puerto), _Pagina)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(crt, key)
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    _estado["https"], _estado["puerto"] = srv, puerto
    return f"https://{ip or ip_local()}:{puerto}/"


def parar_https():
    if _estado["https"]:
        _estado["https"].shutdown()
        _estado["https"].server_close()
        _estado["https"] = None


# ---------------------------------------------------------------- FreeD por UDP

def _s24(b):
    v = (b[0] << 16) | (b[1] << 8) | b[2]
    return v - (1 << 24) if v & 0x800000 else v


def leer_freed(paquete):
    """Mensaje D1 de FreeD (29 bytes): ángulos /32768 grados, posición /64 mm, zoom y foco en bruto."""
    if len(paquete) < 29 or paquete[0] != 0xD1:
        return None
    if (0x40 - sum(paquete[:28])) % 256 != paquete[28]:
        return None
    pan, tilt, roll = (_s24(paquete[i:i + 3]) / 32768.0 for i in (2, 5, 8))
    x, y, z = (_s24(paquete[i:i + 3]) / 64.0 / 1000.0 for i in (11, 14, 17))
    zoom = (paquete[20] << 16) | (paquete[21] << 8) | paquete[22]
    foco = (paquete[23] << 16) | (paquete[24] << 8) | paquete[25]
    return {"camara": paquete[1], "pan": pan, "tilt": tilt, "roll": roll, "x": x, "y": y, "z": z,
            "zoom": zoom, "foco": foco}


def hacer_freed(pan, tilt, roll, x, y, z, zoom=0, foco=0, camara=1):
    """Para las pruebas (y para quien quiera reenviar la cámara de Blender a otro sistema)."""
    def s24(v):
        v = int(round(v)) & 0xFFFFFF
        return bytes(((v >> 16) & 255, (v >> 8) & 255, v & 255))
    cuerpo = bytes((0xD1, camara)) + b"".join(s24(a * 32768) for a in (pan, tilt, roll)) \
        + b"".join(s24(m * 1000 * 64) for m in (x, y, z)) + s24(zoom) + s24(foco) + b"\x00\x00"
    return cuerpo + bytes(((0x40 - sum(cuerpo)) % 256,))


def _bucle_udp(sock):
    while _estado["udp"] is sock:
        try:
            datos, _ = sock.recvfrom(1024)
        except OSError:
            break
        d = leer_freed(datos)
        if d:
            R, p = pose.desde_freed(d["pan"], d["tilt"], d["roll"], d["x"], d["y"], d["z"], _estado["signos"])
            pose.BUZON.poner("FreeD", R, p, {"zoom": d["zoom"], "foco": d["foco"]})


def arrancar_freed(puerto=40000):
    parar_freed()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", puerto))
    _estado["udp"] = sock
    threading.Thread(target=_bucle_udp, args=(sock,), daemon=True).start()
    return f"{ip_local()}:{puerto}"


def parar_freed():
    s = _estado["udp"]
    _estado["udp"] = None
    if s:
        s.close()


def ajustes(montaje=None, signos=None):
    if montaje:
        _estado["montaje"] = montaje
    if signos:
        _estado["signos"] = signos


def activos():
    return {"https": _estado["https"] is not None, "freed": _estado["udp"] is not None}
