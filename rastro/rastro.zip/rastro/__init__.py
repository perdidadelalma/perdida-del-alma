# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""RASTRO · la cámara real mueve la de Blender (móvil, FreeD, marcadores o GoPro + COLMAP)."""

bl_info = {
    "name": "RASTRO · Cámara real",
    "author": "Toniño",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "Vista 3D > Barra lateral (N) > Rastro",
    "description": "Plató virtual sencillo: la cámara de rodaje mueve la de Blender y se graba para rematar",
    "doc_url": "https://perdidadelalma.github.io/perdida-del-alma/rastro/",
    "category": "Camera",
}

if "ui" in locals():
    import importlib
    from . import camaras, dependencias, directo, gopro, marcadores, plan, pose, qr, receptor
    for m in (pose, receptor, camaras, dependencias, directo, marcadores, plan, gopro, qr, ui):
        importlib.reload(m)
else:
    from . import ui


def register():
    ui.register()


def unregister():
    ui.unregister()
