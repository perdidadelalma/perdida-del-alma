# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Catálogo de cámaras reales: elegir una pone en la cámara de Blender el mismo sensor, resolución y fps.

El catálogo general está en camaras.json; las propias, en ~/RASTRO/camaras_propias.json.
"""

import json
import os
import unicodedata

AQUI = os.path.dirname(__file__)
PROPIAS = os.path.join(os.path.expanduser("~"), "RASTRO", "camaras_propias.json")
_cache = {"mtime": None, "lista": []}


def _leer(ruta):
    with open(ruta, encoding="utf-8") as f:
        return json.load(f)


def cargar(forzar=False):
    rutas = [os.path.join(AQUI, "camaras.json")] + ([PROPIAS] if os.path.exists(PROPIAS) else [])
    mtime = tuple(os.path.getmtime(r) for r in rutas)
    if forzar or _cache["mtime"] != mtime:
        todas = {c["id"]: dict(c, propia=False) for c in _leer(rutas[0])["camaras"]}
        if len(rutas) > 1:
            try:
                for c in _leer(rutas[1]).get("camaras", []):
                    todas[c["id"]] = dict(c, propia=True)
            except (OSError, ValueError) as e:
                print("RASTRO: no se pudo leer", PROPIAS, e)
        _cache.update(mtime=mtime, lista=list(todas.values()))
    return _cache["lista"]


def camara(cid):
    return next((c for c in cargar() if c["id"] == cid), None)


def nombre(c):
    return f"{c['marca']} {c['modelo']}"


def _plano(t):
    t = unicodedata.normalize("NFD", t.lower())
    return "".join(ch for ch in t if unicodedata.category(ch) != "Mn")


def buscar(texto=""):
    palabras = _plano(texto).split()
    return [c for c in cargar() if all(p in _plano(f"{nombre(c)} {c['tipo']}") for p in palabras)]


_items = []


def items_enum(_self=None, _context=None):
    """Una entrada por cámara y modo, para el desplegable con buscador de Blender."""
    global _items
    orden = {"Cine": 0, "Sin espejo": 1, "Réflex": 2, "Videocámara": 3, "Compacta": 4, "Acción": 5, "Móvil": 6}
    _items = []
    for c in sorted(cargar(), key=lambda c: (orden.get(c["tipo"], 9), c["marca"], c["modelo"])):
        for i, m in enumerate(c["modos"]):
            _items.append((f"{c['id']}|{i}", f"{nombre(c)} · {m['nombre']}",
                           f"{c['tipo']} · sensor {m['w']}×{m['h']} mm · {m['res'][0]}×{m['res'][1]}"))
    return _items


def aplicar(cam_obj, scene, clave, focal=None, fps=None):
    """Pone sensor, resolución y fps de la cámara elegida («id|modo») en la cámara y la escena."""
    cid, _, i = clave.partition("|")
    c = camara(cid)
    if c is None:
        return None
    m = c["modos"][int(i or 0)]
    cd = cam_obj.data
    cd.sensor_fit = "HORIZONTAL"
    cd.sensor_width, cd.sensor_height = m["w"], m["h"]
    if c.get("focal_fija"):
        cd.lens = c["focal_fija"]
    elif focal:
        cd.lens = focal
    scene.render.resolution_x, scene.render.resolution_y = m["res"]
    scene.render.pixel_aspect_x = scene.render.pixel_aspect_y = 1.0
    if fps:
        scene.render.fps, scene.render.fps_base = int(round(fps)), (round(fps) / fps if fps else 1.0)
    cam_obj["rastro_camara"] = clave
    return c, m


def guardar_propia(c):
    datos = _leer(PROPIAS) if os.path.exists(PROPIAS) else {"camaras": []}
    datos["camaras"] = [x for x in datos["camaras"] if x["id"] != c["id"]] + [c]
    os.makedirs(os.path.dirname(PROPIAS), exist_ok=True)
    with open(PROPIAS, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    cargar(forzar=True)
