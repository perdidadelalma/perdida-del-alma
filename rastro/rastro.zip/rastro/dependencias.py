# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Lo que no trae Blender: OpenCV (marcadores) y cryptography (certificado HTTPS para el móvil).
Se instala una vez en ~/RASTRO/libs con el pip del propio Blender, sin tocar su instalación."""

import importlib
import os
import subprocess
import sys
import threading

LIBS = os.path.join(os.path.expanduser("~"), "RASTRO", "libs")
PAQUETES = ["opencv-contrib-python-headless", "cryptography", "cffi", "pycparser"]
_estado = {"instalando": False, "log": ""}


def preparar_ruta():
    if os.path.isdir(LIBS) and LIBS not in sys.path:
        sys.path.append(LIBS)  # al final: el numpy de Blender sigue mandando


def falta():
    preparar_ruta()
    faltan = []
    for mod in ("cv2", "cryptography"):
        try:
            importlib.import_module(mod)
        except ImportError:
            faltan.append(mod)
    return faltan


def instalar(al_acabar=None):
    if _estado["instalando"]:
        return
    _estado.update(instalando=True, log="Instalando OpenCV y cryptography…")

    def hilo():
        os.makedirs(LIBS, exist_ok=True)
        cmd = [sys.executable, "-m", "pip", "install", "--no-deps", "--upgrade", "--target", LIBS,
               "--no-warn-script-location"] + PAQUETES
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
            _estado["log"] = "Instalado." if r.returncode == 0 else ("Error: " + r.stderr[-400:])
        except Exception as e:  # sin internet, sin pip…
            _estado["log"] = f"Error: {e}"
        _estado["instalando"] = False
        importlib.invalidate_caches()
        preparar_ruta()
        if al_acabar:
            al_acabar()

    threading.Thread(target=hilo, daemon=True).start()


def estado():
    return dict(_estado)
