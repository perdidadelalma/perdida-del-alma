# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""Panel «Rastro» de la vista 3D: la cámara real, el directo (móvil, FreeD, marcadores) y las tomas."""

import os
import textwrap
import webbrowser

import bpy
import bpy.utils.previews
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty, IntProperty,
                       PointerProperty, StringProperty)

from . import camaras, dependencias, directo, gopro, receptor

VERSION = "0.1.0"
CREDIT = "creado por Toniño · Pérdida del Alma"
INSTAGRAM = "https://www.instagram.com/perdidadelalma/"
WEB = "https://perdidadelalma.github.io/perdida-del-alma/rastro/"
_previews = None


_msg = {"texto": ""}


def icon(name):
    if _previews is None:
        return 0
    for key in (name, f"i_{name}"):
        if key in _previews:
            return _previews[key].icon_id
    return 0


def load_icons():
    global _previews
    _previews = bpy.utils.previews.new()
    carpeta = os.path.join(os.path.dirname(__file__), "icons")
    if os.path.isdir(carpeta):
        for f in os.listdir(carpeta):
            if f.endswith(".png"):
                _previews.load(os.path.splitext(f)[0], os.path.join(carpeta, f), "IMAGE")


def icono_qr(url):
    """El QR de la dirección como icono del panel (se carga una vez por dirección)."""
    if _previews is None or not url.startswith("https://"):
        return 0
    from . import qr
    clave = "qr_" + url
    if clave not in _previews:
        ruta = qr.crear(url)
        if not ruta:
            return 0
        _previews.load(clave, ruta, "IMAGE")
    return _previews[clave].icon_id


def free_icons():
    global _previews
    if _previews is not None:
        bpy.utils.previews.remove(_previews)
        _previews = None


def osd(layout, text, alert=False, icono=None):
    row = layout.row()
    row.alert = alert
    if icono and icon(icono):
        row.label(text=text.upper(), icon_value=icon(icono))
    else:
        row.label(text=text.upper())


def _redibujar():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == "VIEW_3D":
                a.tag_redraw()


def _refresco():
    """Mientras hay directo, el panel se repinta para enseñar Hz y estado."""
    from . import marcadores
    if directo.estado()["activo"] or dependencias.estado()["instalando"] or 0 < marcadores.estado()["calib"] < 20:
        _redibujar()
        return 0.5
    return None


# ---------------------------------------------------------------- propiedades

def _cambio_montaje(self, context):
    receptor.ajustes(montaje=self.montaje)


def _cambio_signos(self, context):
    receptor.ajustes(signos=(-1 if self.inv_pan else 1, -1 if self.inv_tilt else 1, -1 if self.inv_roll else 1))


class RASTRO_Ajustes(bpy.types.PropertyGroup):
    fuente: EnumProperty(name="Fuente", items=[
        ("MOVIL", "Móvil (Android / iPhone)", "Página web en el móvil, montado encima de la cámara"),
        ("FREED", "FreeD", "Apps de iPhone con posición completa, trackers profesionales y cámaras robotizadas"),
        ("MARCADORES", "Marcadores", "Marcadores impresos vistos por una webcam (en el techo o en el croma)")], default="MOVIL")
    puerto_https: IntProperty(name="Puerto web", default=8443, min=1024, max=65535)
    puerto_freed: IntProperty(name="Puerto FreeD", default=40000, min=1024, max=65535)
    montaje: EnumProperty(name="Móvil en el soporte", items=[
        ("HORIZONTAL_IZQ", "Horizontal (botones arriba)", ""), ("HORIZONTAL_DER", "Horizontal (botones abajo)", ""),
        ("VERTICAL", "Vertical", "")], default="HORIZONTAL_IZQ", update=_cambio_montaje,
        description="Solo para el giroscopio del iPhone: cómo va puesto el móvil")
    inv_pan: BoolProperty(name="Invertir pan", update=_cambio_signos)
    inv_tilt: BoolProperty(name="Invertir tilt", update=_cambio_signos)
    inv_roll: BoolProperty(name="Invertir roll", update=_cambio_signos)
    suavizado: FloatProperty(name="Suavizado", default=0.4, min=0, max=1, subtype="FACTOR",
                             description="Quita el temblor cuando la cámara está quieta sin retrasar los movimientos rápidos")
    retraso: FloatProperty(name="Retraso (ms)", default=0, min=0, max=1000,
                           description="Retrasa el tracking para que coincida con la imagen de la cámara, que suele llegar tarde")
    escala: FloatProperty(name="Escala", default=1.0, min=0.01, max=1000,
                          description="1 = un metro del plató es un metro en Blender. Más para decorados enormes")
    desplazamiento: FloatVectorProperty(name="Móvil respecto al objetivo (cm)", size=3, default=(0.0, 12.0, 0.0),
                                        description="Dónde va el móvil visto desde la cámara: X derecha, Y arriba, Z hacia atrás")
    camara: StringProperty(name="Cámara real")
    red: EnumProperty(name="Red", items=lambda self, context: _redes(), update=lambda self, context: _cambio_red(self),
                      description="Por dónde llega el móvil: la wifi/cable de aquí, o Tailscale (por internet, desde cualquier red)")
    url: StringProperty()
    webcam: IntProperty(name="Webcam", default=0, min=0, max=9, description="Número de la webcam (0 = la primera)")
    ojo: EnumProperty(name="Cámara que ve los marcadores", items=[
        ("WEBCAM", "Webcam del ordenador", "Una webcam por USB encima de la cámara de rodaje"),
        ("MOVIL", "Cámara del móvil", "El móvil manda lo que ve por la wifi o Tailscale (página «Cámara del móvil»): "
                                      "vale cualquier móvil, aunque no tenga ARCore")], default="WEBCAM")
    distancia_marcadores: FloatProperty(name="Distancia a los marcadores (m)", default=2.0, min=0.3, max=15,
                                        description="De la cámara al techo (o a la pared / al suelo) donde van los marcadores")
    zona_ancho: FloatProperty(name="Ancho", default=3.0, min=0.2, max=30, unit="LENGTH",
                              description="Si la cámara no está animada: ancho de la zona por donde se moverá")
    zona_fondo: FloatProperty(name="Fondo", default=3.0, min=0.2, max=30, unit="LENGTH",
                              description="Si la cámara no está animada: fondo de la zona (alto, si van en la pared)")
    plano: IntProperty(name="Plano", default=1, min=1, max=999,
                        description="Número de plano de la escaleta: las tomas se llaman P01 T01, P01 T02…")
    tam_marcador: FloatProperty(name="Lado del marcador (cm)", default=15.0, min=2, max=100,
                                description="Mídelo con una regla en el papel impreso: lado del cuadrado negro")
    montaje_webcam: EnumProperty(name="Webcam", items=[
        ("ARRIBA", "Mirando al techo", "Encima de la cámara, mirando a los marcadores del techo"),
        ("IGUAL", "Mirando al frente", "Mirando a lo mismo que el objetivo (marcadores en el croma)"),
        ("ABAJO", "Mirando al suelo", "Marcadores en el suelo")], default="ARRIBA")
    gopro_video: StringProperty(name="Vídeo de la GoPro", subtype="FILE_PATH")
    cine_video: StringProperty(name="Vídeo de la cámara", subtype="FILE_PATH",
                               description="Opcional: si está, se sincroniza por la palmada y se pone de fondo")
    ojo_de_pez: BoolProperty(name="GoPro en modo ancho (ojo de pez)", default=True)
    escala_gopro: FloatProperty(name="Escala", default=1.0, min=0.001, max=1000,
                                description="COLMAP no sabe medir: ajústala con algo de tamaño conocido")
    inclinacion_gopro: FloatProperty(name="GoPro inclinada (°)", default=0.0, min=-90, max=90,
                                     description="Cuánto mira la GoPro hacia arriba respecto al objetivo")
    duracion_gopro: FloatProperty(name="Duración (s)", default=0.0, min=0,
                                  description="0 = todo el vídeo. Para probar, unos segundos")


# ---------------------------------------------------------------- operadores

class RASTRO_OT_elegir_camara(bpy.types.Operator):
    """Busca tu cámara: marca, modelo, «cine», «gopro», «iphone»…"""
    bl_idname = "rastro.elegir_camara"
    bl_label = "Elegir cámara real"
    bl_property = "camara"
    bl_options = {"REGISTER", "UNDO"}
    camara: EnumProperty(items=camaras.items_enum)

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        cam = context.scene.camera
        if cam is None:
            self.report({"WARNING"}, "La escena no tiene cámara activa")
            return {"CANCELLED"}
        c, m = camaras.aplicar(cam, context.scene, self.camara)
        context.scene.rastro.camara = self.camara
        self.report({"INFO"}, f"{camaras.nombre(c)} · {m['nombre']} · sensor {m['w']}×{m['h']} mm")
        return {"FINISHED"}


class RASTRO_OT_camara_nueva(bpy.types.Operator):
    """Añade una cámara que no está en el catálogo"""
    bl_idname = "rastro.camara_nueva"
    bl_label = "Cámara nueva"
    marca: StringProperty(name="Marca")
    modelo: StringProperty(name="Modelo")
    tipo: EnumProperty(name="Tipo", items=[(t, t, "") for t in ("Cine", "Sin espejo", "Réflex", "Videocámara", "Compacta", "Acción", "Móvil")])
    modo: StringProperty(name="Modo", default="4K")
    ancho: FloatProperty(name="Ancho del sensor (mm)", default=23.5, min=1, max=80)
    alto: FloatProperty(name="Alto del sensor (mm)", default=13.2, min=1, max=60)
    res_x: IntProperty(name="Resolución X", default=3840, min=320)
    res_y: IntProperty(name="Resolución Y", default=2160, min=240)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        if not self.modelo.strip():
            return {"CANCELLED"}
        cid = "propia_" + "".join(ch if ch.isalnum() else "_" for ch in (self.marca + "_" + self.modelo).lower())
        camaras.guardar_propia({"id": cid, "marca": self.marca or "Propia", "modelo": self.modelo, "tipo": self.tipo,
                                "modos": [{"nombre": self.modo, "w": self.ancho, "h": self.alto,
                                           "res": [self.res_x, self.res_y], "fps": [24, 25, 30]}]})
        if context.scene.camera:
            camaras.aplicar(context.scene.camera, context.scene, cid + "|0")
            context.scene.rastro.camara = cid + "|0"
        return {"FINISHED"}


_REDES = []  # (Blender necesita que la lista de un EnumProperty dinámico siga viva)


def _redes():
    _REDES[:] = [(ip, f"{ip} · {desc}", desc) for ip, desc in receptor.ips()]
    return _REDES


def _cambio_red(a):
    if a.url.startswith("https://"):
        a.url = f"https://{a.red}:{a.puerto_https}/"


def _camara_marcadores(a):
    from . import marcadores
    return marcadores.MOVIL if a.ojo == "MOVIL" else a.webcam


def _servidor_movil(a, pagina=""):
    """Arranca (si hace falta) la web del móvil y deja en el panel su dirección y su QR."""
    if not receptor.https_activo():
        receptor.arrancar_https(a.puerto_https, a.red)
    a.url = f"https://{a.red}:{a.puerto_https}/{pagina}"


class RASTRO_OT_conectar(bpy.types.Operator):
    """Empieza a recibir la cámara real y a mover la de Blender"""
    bl_idname = "rastro.conectar"
    bl_label = "Conectar"

    def execute(self, context):
        a = context.scene.rastro
        if context.scene.camera is None:
            self.report({"WARNING"}, "La escena no tiene cámara activa")
            return {"CANCELLED"}
        try:
            if a.fuente == "MOVIL":
                if "cryptography" in dependencias.falta():
                    self.report({"WARNING"}, "Falta instalar lo necesario (botón Instalar)")
                    return {"CANCELLED"}
                a.url = receptor.arrancar_https(a.puerto_https, a.red)
                receptor.ajustes(montaje=a.montaje)
            elif a.fuente == "FREED":
                a.url = "FreeD → " + receptor.arrancar_freed(a.puerto_freed)
                _cambio_signos(a, context)
            else:
                from . import marcadores
                if a.ojo == "MOVIL":
                    if dependencias.falta():
                        self.report({"WARNING"}, "Falta instalar lo necesario (botón Instalar)")
                        return {"CANCELLED"}
                    _servidor_movil(a, "camara")
                    marcadores.arrancar(context)
                else:
                    a.url = marcadores.arrancar(context)
        except OSError as e:
            self.report({"ERROR"}, f"No se pudo abrir el puerto: {e}")
            return {"CANCELLED"}
        directo.empezar()
        bpy.app.timers.register(_refresco, first_interval=0.5)
        return {"FINISHED"}


class RASTRO_OT_desconectar(bpy.types.Operator):
    bl_idname = "rastro.desconectar"
    bl_label = "Desconectar"

    def execute(self, context):
        directo.parar()
        receptor.parar_https()
        receptor.parar_freed()
        try:
            from . import marcadores
            marcadores.parar()
        except ImportError:
            pass
        context.scene.rastro.url = ""
        return {"FINISHED"}


class RASTRO_OT_cero(bpy.types.Operator):
    """Deja la cámara de Blender donde está ahora y a partir de aquí la mueve la cámara real"""
    bl_idname = "rastro.cero"
    bl_label = "Poner a cero"

    def execute(self, context):
        directo.poner_a_cero()
        return {"FINISHED"}


class RASTRO_OT_toma(bpy.types.Operator):
    """Graba el movimiento de la cámara; al parar se convierte en fotogramas clave"""
    bl_idname = "rastro.toma"
    bl_label = "Grabar toma"

    def execute(self, context):
        if directo.estado()["grabando"]:
            r = directo.terminar_toma()
            if r:
                self.report({"INFO"}, f"Toma guardada: {os.path.basename(r[0])} ({r[1]} poses)")
        else:
            if not directo.estado()["activo"]:
                self.report({"WARNING"}, "Primero conecta la cámara real")
                return {"CANCELLED"}
            directo.empezar_toma()
        return {"FINISHED"}


class RASTRO_OT_claqueta(bpy.types.Operator):
    """La toma empieza sola cuando el móvil oye la claqueta (casilla «Escuchar la claqueta» en el móvil).
    Ese instante queda en el fotograma actual: en el montaje, pon ahí el golpe de la claqueta del clip"""
    bl_idname = "rastro.claqueta"
    bl_label = "Esperar la claqueta"

    def execute(self, context):
        if directo.estado()["esperando"]:
            directo.esperar_claqueta(False)
            return {"FINISHED"}
        if not directo.estado()["activo"]:
            self.report({"WARNING"}, "Primero conecta la cámara real")
            return {"CANCELLED"}
        directo.esperar_claqueta(True)
        bpy.app.timers.register(_refresco, first_interval=0.5)
        return {"FINISHED"}


class RASTRO_OT_valorar(bpy.types.Operator):
    """Marca la toma como buena o mala (también se puede desde el móvil)"""
    bl_idname = "rastro.valorar"
    bl_label = "Valorar toma"
    ident: StringProperty()
    valor: StringProperty()

    def execute(self, context):
        directo.valorar(self.ident, self.valor)
        return {"FINISHED"}


class RASTRO_OT_instalar(bpy.types.Operator):
    """Instala OpenCV y cryptography en ~/RASTRO/libs (una vez, necesita internet)"""
    bl_idname = "rastro.instalar"
    bl_label = "Instalar lo que falta"

    def execute(self, context):
        dependencias.instalar()
        bpy.app.timers.register(_refresco, first_interval=0.5)
        return {"FINISHED"}


class RASTRO_OT_hojas(bpy.types.Operator):
    """Hace los marcadores para imprimir (A4, tamaño real) y el tablero para calibrar la webcam"""
    bl_idname = "rastro.hojas"
    bl_label = "Marcadores para imprimir"
    cuantos: IntProperty(name="Cuántos", default=12, min=1, max=50)

    def execute(self, context):
        from . import marcadores
        carpeta = CARPETA_IMPRIMIR
        os.makedirs(carpeta, exist_ok=True)
        _limpiar_hojas(carpeta)
        rutas = marcadores.hoja(os.path.join(carpeta, "marcadores.png"), 0, self.cuantos, context.scene.rastro.tam_marcador)
        marcadores.tablero(os.path.join(carpeta, "tablero_calibracion.png"))
        _pdf_para_imprimir(carpeta)
        _abrir_carpeta(carpeta)
        self.report({"INFO"}, f"RASTRO_imprimir.pdf: {len(rutas)} hojas de marcadores y el tablero (imprimir a tamaño real)")
        return {"FINISHED"}


CARPETA_IMPRIMIR = os.path.join(os.path.expanduser("~"), "RASTRO", "imprimir")


def _abrir_carpeta(carpeta):
    os.startfile(carpeta) if hasattr(os, "startfile") else webbrowser.open(carpeta)


def _limpiar_hojas(carpeta):
    for f in os.listdir(carpeta):
        if (f.startswith("marcadores_") and f.endswith(".png")) or f in ("plan_marcadores.png", "RASTRO_imprimir.pdf"):
            os.remove(os.path.join(carpeta, f))


def _pdf_para_imprimir(carpeta):
    """Todo en un PDF, por este orden: plano, hojas de marcadores y tablero de calibración."""
    from . import marcadores
    hojas = sorted((f for f in os.listdir(carpeta) if f.startswith("marcadores_") and f.endswith(".png")),
                   key=lambda f: int(f[11:-4]))
    rutas = [os.path.join(carpeta, f) for f in ["plan_marcadores.png"] + hojas + ["tablero_calibracion.png"]
             if os.path.exists(os.path.join(carpeta, f))]
    return marcadores.pdf(rutas, os.path.join(carpeta, "RASTRO_imprimir.pdf"))


class RASTRO_OT_plan(bpy.types.Operator):
    """Calcula dónde poner los marcadores para que la cámara vea siempre 2 o más, los pone en la escena
    y deja para imprimir las hojas justas y un plano con las medidas desde el marcador 0"""
    bl_idname = "rastro.plan"
    bl_label = "Dónde poner los marcadores"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from . import marcadores, plan
        if dependencias.falta():
            self.report({"WARNING"}, "Falta instalar lo necesario (botón Instalar)")
            return {"CANCELLED"}
        sc, a = context.scene, context.scene.rastro
        if sc.camera is None:
            self.report({"WARNING"}, "La escena no tiene cámara activa")
            return {"CANCELLED"}
        d, m = a.distancia_marcadores, a.montaje_webcam
        x0, x1, y0, y1 = plan.zona_de_camara(sc, a.zona_ancho, a.zona_fondo)
        hcam = sc.camera.matrix_world.translation.z
        if m == "IGUAL":   # en la pared de enfrente: ancho de la zona × alto alrededor de la cámara
            zona, fijo = (x0, x1, hcam - a.zona_fondo / 2, hcam + a.zona_fondo / 2), y1 + d
        else:
            zona, fijo = (x0, x1, y0, y1), (hcam + d if m == "ARRIBA" else max(0.0, hcam - d))
        pts, sep, tam, _huella = plan.calcular(zona, d, movil=a.ojo == "MOVIL")
        a.tam_marcador = tam
        plan.a_escena(context, pts, tam, m, fijo)
        os.makedirs(CARPETA_IMPRIMIR, exist_ok=True)
        _limpiar_hojas(CARPETA_IMPRIMIR)
        hojas = marcadores.hoja(os.path.join(CARPETA_IMPRIMIR, "marcadores.png"), 0, len(pts), tam)
        plan.plano(os.path.join(CARPETA_IMPRIMIR, "plan_marcadores.png"), pts, tam, sep, d, m)
        marcadores.tablero(os.path.join(CARPETA_IMPRIMIR, "tablero_calibracion.png"))
        _pdf_para_imprimir(CARPETA_IMPRIMIR)
        _abrir_carpeta(CARPETA_IMPRIMIR)
        self.report({"INFO"}, f"RASTRO_imprimir.pdf: {len(pts)} marcadores de {tam:g} cm cada {sep * 100:.0f} cm · {len(hojas)} hojas "
                              f"+ plano con las medidas (imprimir al 100 %)")
        return {"FINISHED"}


class RASTRO_OT_imprimir(bpy.types.Operator):
    """Abre la carpeta con lo que hay que imprimir (si está vacía, hace antes los marcadores y el tablero)"""
    bl_idname = "rastro.imprimir"
    bl_label = "Abrir carpeta de marcadores"

    def execute(self, context):
        from . import marcadores
        os.makedirs(CARPETA_IMPRIMIR, exist_ok=True)
        if not any(f.startswith("marcadores_") for f in os.listdir(CARPETA_IMPRIMIR)):
            if dependencias.falta():
                self.report({"WARNING"}, "Falta instalar lo necesario (botón Instalar)")
                return {"CANCELLED"}
            marcadores.hoja(os.path.join(CARPETA_IMPRIMIR, "marcadores.png"), 0, 12, context.scene.rastro.tam_marcador)
            marcadores.tablero(os.path.join(CARPETA_IMPRIMIR, "tablero_calibracion.png"))
        if not os.path.exists(os.path.join(CARPETA_IMPRIMIR, "RASTRO_imprimir.pdf")):
            _pdf_para_imprimir(CARPETA_IMPRIMIR)
        _abrir_carpeta(CARPETA_IMPRIMIR)
        return {"FINISHED"}


class RASTRO_OT_calibrar(bpy.types.Operator):
    """Calibra la lente de la webcam o del móvil: enséñale el tablero impreso desde 20 posiciones distintas"""
    bl_idname = "rastro.calibrar"
    bl_label = "Calibrar lente"

    def execute(self, context):
        from . import marcadores
        a = context.scene.rastro
        if a.ojo == "MOVIL":
            if dependencias.falta():
                self.report({"WARNING"}, "Falta instalar lo necesario (botón Instalar)")
                return {"CANCELLED"}
            _servidor_movil(a, "camara")
        marcadores.calibrar(_camara_marcadores(a))
        bpy.app.timers.register(_refresco, first_interval=0.5)
        return {"FINISHED"}


class RASTRO_OT_borrar_mapa(bpy.types.Operator):
    """Olvida dónde están los marcadores (por si se han movido): se vuelven a aprender desde el 0"""
    bl_idname = "rastro.borrar_mapa"
    bl_label = "Olvidar marcadores"

    def execute(self, context):
        from . import marcadores
        marcadores.borrar_mapa()
        return {"FINISHED"}


def _gopro_listo():
    """Temporizador: cuando el hilo de COLMAP acaba, se hornea la cámara en el hilo de Blender."""
    st = gopro.estado()
    _redibujar()
    if st["activo"]:
        return 1.0
    res = st["resultado"]
    sc = bpy.context.scene
    cam = sc.camera
    if res and cam:
        from mathutils import Matrix
        accion = bpy.data.actions.new("RASTRO GoPro")
        cam.animation_data_create()
        cam.animation_data.action = accion
        cam.rotation_mode = "XYZ"
        base = cam.matrix_world.copy()
        prev = None
        f0 = sc.frame_start
        for k, m in enumerate(res["matrices"]):
            mm = base @ Matrix(m)
            loc, rot, _e = mm.decompose()
            e = rot.to_euler("XYZ", prev) if prev else rot.to_euler("XYZ")
            prev = e
            cam.location, cam.rotation_euler = loc, e
            cam.keyframe_insert("location", frame=f0 + k)
            cam.keyframe_insert("rotation_euler", frame=f0 + k)
        sc.frame_end = f0 + len(res["matrices"]) - 1
        if res.get("cine") and os.path.exists(res["cine"]):
            clip = bpy.data.movieclips.load(res["cine"], check_existing=True)
            cam.data.show_background_images = True
            bg = next((b for b in cam.data.background_images if b.source == "MOVIE_CLIP"), None) or cam.data.background_images.new()
            bg.source, bg.clip, bg.alpha = "MOVIE_CLIP", clip, 1.0
            bg.clip_user.use_render_undistorted = False
    return None


class RASTRO_OT_gopro(bpy.types.Operator):
    """Saca el movimiento de la cámara con la GoPro y COLMAP (sincroniza por la palmada si hay vídeo de la cámara)"""
    bl_idname = "rastro.gopro"
    bl_label = "Sacar la cámara con COLMAP"

    def execute(self, context):
        a = context.scene.rastro
        if not a.gopro_video or not os.path.exists(bpy.path.abspath(a.gopro_video)):
            self.report({"WARNING"}, "Elige el vídeo de la GoPro")
            return {"CANCELLED"}
        if context.scene.camera is None:
            self.report({"WARNING"}, "La escena no tiene cámara activa")
            return {"CANCELLED"}
        prefs = context.preferences.addons[__package__].preferences
        r = context.scene.render
        gopro.procesar(bpy.path.abspath(a.gopro_video),
                       bpy.path.abspath(a.cine_video) if a.cine_video else None,
                       fps=r.fps / r.fps_base, ffmpeg=prefs.ffmpeg, colmap=prefs.colmap, ojo_de_pez=a.ojo_de_pez,
                       escala=a.escala_gopro, inclinacion_gopro=a.inclinacion_gopro,
                       duracion=a.duracion_gopro or None)
        bpy.app.timers.register(_gopro_listo, first_interval=1.0)
        return {"FINISHED"}


class RASTRO_OT_escala(bpy.types.Operator):
    """Pone la escala real: di cuánto se movió de verdad la cámara entre dos fotogramas (un travelling, un paso…)"""
    bl_idname = "rastro.escala"
    bl_label = "Escala por distancia conocida"
    bl_options = {"REGISTER", "UNDO"}
    frame_a: IntProperty(name="Desde el fotograma", default=1)
    frame_b: IntProperty(name="Hasta el fotograma", default=48)
    metros: FloatProperty(name="Distancia real (m)", default=1.0, min=0.001, unit="LENGTH")

    def invoke(self, context, event):
        sc = context.scene
        self.frame_a, self.frame_b = sc.frame_start, sc.frame_end
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        sc = context.scene
        cam = sc.camera
        if not cam or not cam.animation_data or not cam.animation_data.action:
            self.report({"WARNING"}, "La cámara no tiene movimiento (saca primero la cámara con COLMAP)")
            return {"CANCELLED"}
        actual = sc.frame_current
        sc.frame_set(self.frame_a)
        pa = cam.matrix_world.translation.copy()
        sc.frame_set(self.frame_b)
        pb = cam.matrix_world.translation.copy()
        medida = (pb - pa).length
        if medida < 1e-6:
            sc.frame_set(actual)
            self.report({"WARNING"}, "La cámara no se mueve entre esos fotogramas")
            return {"CANCELLED"}
        k = self.metros / medida
        # Escalar el recorrido alrededor de la primera posición (las claves de location)
        sc.frame_set(sc.frame_start)
        origen = cam.location.copy()
        for fc in cam.animation_data.action.fcurves:
            if fc.data_path == "location":
                for kp in fc.keyframe_points:
                    o = origen[fc.array_index]
                    for attr in ("co", "handle_left", "handle_right"):
                        v = getattr(kp, attr)
                        v[1] = o + (v[1] - o) * k
                fc.update()
        sc.rastro.escala_gopro *= k
        sc.frame_set(actual)
        self.report({"INFO"}, f"Escala ×{k:.4g}: ahora entre esos fotogramas hay {self.metros:g} m")
        return {"FINISHED"}


class RASTRO_OT_abrir(bpy.types.Operator):
    bl_idname = "rastro.abrir"
    bl_label = "Abrir"
    url: StringProperty()

    def execute(self, context):
        webbrowser.open(self.url)
        return {"FINISHED"}


# ---------------------------------------------------------------- paneles

class _Base:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Rastro"


class RASTRO_PT_main(_Base, bpy.types.Panel):
    bl_label = "RASTRO"
    bl_idname = "RASTRO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon_value=icon("logo"))

    def draw(self, context):
        lay = self.layout
        unidad = 20 * context.preferences.system.ui_scale
        ancho = (context.region.width / unidad) if context.region else 14
        if icon("banner_0"):
            row = lay.row(align=True)
            row.alignment = "CENTER"
            for i in range(3):
                row.template_icon(icon_value=icon(f"banner_{i}"), scale=max(2.0, (ancho - 1.4) / 3))
        osd(lay, "Cámara real · N.º 03")
        osd(lay, CREDIT)
        falta = dependencias.falta()
        if falta:
            box = lay.box()
            st = dependencias.estado()
            box.label(text="Falta: " + ", ".join(falta), icon="ERROR")
            if st["instalando"] or st["log"]:
                box.label(text=st["log"])
            box.operator("rastro.instalar", icon="IMPORT")


class RASTRO_PT_camara(_Base, bpy.types.Panel):
    bl_label = "Cámara real"
    bl_parent_id = "RASTRO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon="OUTLINER_OB_CAMERA")

    def draw(self, context):
        lay = self.layout
        a = context.scene.rastro
        cam = context.scene.camera
        nombre = "Elegir cámara"
        if a.camara:
            cid, _, i = a.camara.partition("|")
            c = camaras.camara(cid)
            if c:
                m = c["modos"][int(i or 0)]
                nombre = f"{camaras.nombre(c)} · {m['nombre']}"
        lay.operator("rastro.elegir_camara", text=nombre, icon="VIEWZOOM")
        if cam:
            col = lay.column(align=True)
            col.prop(cam.data, "lens", text="Objetivo (mm)")
            row = col.row(align=True)
            row.label(text=f"Sensor {cam.data.sensor_width:.2f} × {cam.data.sensor_height:.2f} mm")
            r = context.scene.render
            col.label(text=f"{r.resolution_x}×{r.resolution_y} · {r.fps / r.fps_base:.3g} fps")
            col.prop(r, "fps", text="fps")
        lay.operator("rastro.camara_nueva", icon="ADD")


class RASTRO_PT_directo(_Base, bpy.types.Panel):
    bl_label = "Directo"
    bl_parent_id = "RASTRO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon="CON_CAMERASOLVER")

    def draw(self, context):
        lay = self.layout
        a = context.scene.rastro
        st = directo.estado()
        lay.prop(a, "fuente", text="")
        if a.fuente == "MOVIL":
            lay.prop(a, "montaje")
            lay.prop(a, "red")
        elif a.fuente == "FREED":
            row = lay.row(align=True)
            row.prop(a, "inv_pan", toggle=True)
            row.prop(a, "inv_tilt", toggle=True)
            row.prop(a, "inv_roll", toggle=True)
        col = lay.column(align=True)
        col.scale_y = 1.4
        if st["activo"]:
            col.operator("rastro.desconectar", icon="CANCEL")
        else:
            col.operator("rastro.conectar", icon="LINKED")
        if a.url:
            box = lay.box()
            if a.url.startswith("https://"):
                box.label(text="Escanéalo con el móvil:", icon="URL")
                icono = icono_qr(a.url)
                if icono:
                    box.template_icon(icon_value=icono, scale=max(6.0, context.region.width / (20 * context.preferences.system.ui_scale) - 2))
                box.label(text="o abre: " + a.url)
            else:
                box.label(text=a.url)
            if st["activo"]:
                vivo = st["edad"] < 0.5
                r = box.row()
                r.alert = not vivo
                r.label(text=f"{st['fuente'] or 'esperando…'} · {st['hz']} Hz" if vivo else "Sin señal del móvil / tracker",
                        icon="CHECKMARK" if vivo else "ERROR")
        lay.operator("rastro.cero", icon="PIVOT_CURSOR")
        col = lay.column(align=True)
        col.prop(a, "suavizado", slider=True)
        col.prop(a, "retraso")
        col.prop(a, "escala")
        lay.prop(a, "desplazamiento")


class RASTRO_PT_marcadores(_Base, bpy.types.Panel):
    bl_label = "Marcadores"
    bl_parent_id = "RASTRO_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return context.scene.rastro.fuente == "MARCADORES"

    def draw_header(self, context):
        self.layout.label(text="", icon="TRACKER")

    def draw(self, context):
        from . import marcadores
        lay = self.layout
        a = context.scene.rastro
        col = lay.column(align=True)
        col.prop(a, "ojo", text="")
        col.prop(a, "montaje_webcam", text="Mirando")
        if a.ojo == "WEBCAM":
            col.prop(a, "webcam")
        else:
            col.prop(a, "red")
        col.prop(a, "tam_marcador")
        box = lay.box()
        box.label(text="Dónde ponerlos", icon="SNAP_GRID")
        box.prop(a, "distancia_marcadores")
        anim = context.scene.camera and context.scene.camera.animation_data and context.scene.camera.animation_data.action
        if not anim:
            row = box.row(align=True)
            row.prop(a, "zona_ancho")
            row.prop(a, "zona_fondo")
        box.operator("rastro.plan", icon="OUTLINER_OB_POINTCLOUD")
        if bpy.data.objects.get("RASTRO marcador 0"):
            box.label(text="El marcador 0 de la escena fija el plató: no hace falta poner a cero.", icon="PINNED")
        col = lay.column(align=True)
        col.operator("rastro.hojas", icon="FILE_IMAGE")
        fila = col.row(align=True)
        fila.scale_y = 1.3
        fila.operator("rastro.imprimir", text="Abrir carpeta de marcadores", icon="FILE_FOLDER")
        row = lay.row(align=True)
        row.operator("rastro.calibrar", icon="CAMERA_DATA")
        row.operator("rastro.borrar_mapa", text="", icon="TRASH")
        st = marcadores.estado()
        if st["estado"]:
            lay.label(text=st["estado"], icon="INFO")
        if st["calib"]:
            lay.label(text=f"Vistas del tablero: {st['calib']}/20")
        if st["activo"]:
            lay.label(text=f"Viendo {st['vistos']} · conocidos {st['conocidos']}", icon="CHECKMARK" if st["vistos"] >= 2 else "ERROR")
            aviso = directo.estado()["aviso"]
            if aviso:
                box = lay.box()
                box.alert = True
                for trozo in textwrap.wrap(aviso, 40):
                    box.label(text=trozo)
        lay.label(text="El marcador 0 es el origen: pon ese primero a la vista.")


class RASTRO_PT_gopro(_Base, bpy.types.Panel):
    bl_label = "GoPro + COLMAP"
    bl_parent_id = "RASTRO_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.label(text="", icon="FILE_MOVIE")

    def draw(self, context):
        lay = self.layout
        a = context.scene.rastro
        lay.label(text="Después del rodaje: el movimiento bueno.")
        col = lay.column(align=True)
        col.prop(a, "gopro_video", text="GoPro")
        col.prop(a, "cine_video", text="Cámara")
        col = lay.column(align=True)
        col.prop(a, "ojo_de_pez")
        col.prop(a, "inclinacion_gopro")
        col.prop(a, "escala_gopro")
        col.prop(a, "duracion_gopro")
        st = gopro.estado()
        fila = lay.column(align=True)
        fila.scale_y = 1.3
        fila.enabled = not st["activo"]
        fila.operator("rastro.gopro", icon="CON_CAMERASOLVER")
        lay.operator("rastro.escala", icon="DRIVER_DISTANCE")
        if st["fase"]:
            box = lay.box()
            r = box.row()
            r.alert = bool(st["error"])
            r.label(text=st["error"] or st["fase"], icon="ERROR" if st["error"] else "TIME" if st["activo"] else "CHECKMARK")
            for l in st["log"][-4:]:
                box.label(text=l)


class RASTRO_PT_toma(_Base, bpy.types.Panel):
    bl_label = "Toma"
    bl_parent_id = "RASTRO_PT_main"

    def draw_header(self, context):
        self.layout.label(text="", icon="REC")

    def draw(self, context):
        lay = self.layout
        st = directo.estado()
        col = lay.column(align=True)
        col.scale_y = 1.5
        col.alert = st["grabando"]
        col.operator("rastro.toma", text=f"PARAR ({st['muestras']} poses)" if st["grabando"] else "GRABAR TOMA",
                     icon="SNAP_FACE" if st["grabando"] else "REC")
        if not st["grabando"]:
            row = lay.row()
            row.alert = st["esperando"]
            row.operator("rastro.claqueta", text="Esperando la claqueta… (cancelar)" if st["esperando"] else "Esperar la claqueta",
                         icon="SPEAKER")
        lay.label(text="Con claqueta: el golpe cae en el fotograma actual;")
        lay.label(text="«¡corten!» (o el botón del móvil) la acaba.")
        a = context.scene.rastro
        lay.prop(a, "plano")
        lista = directo.tomas()
        if lista:
            box = lay.box()
            for o in reversed(lista[-12:]):
                v = o.get("rastro_valor", "")
                row = box.row(align=True)
                row.label(text=f"{o['rastro_id']} · {o.get('rastro_segundos', 0):.1f} s",
                          icon={"buena": "CHECKMARK", "mala": "X"}.get(v, "OUTLINER_OB_CAMERA"))
                for valor, ic in (("buena", "CHECKMARK"), ("mala", "X")):
                    op = row.operator("rastro.valorar", text="", icon=ic, depress=v == valor)
                    op.ident, op.valor = o["rastro_id"], "" if v == valor else valor
        lay.label(text="Cada toma: su cámara en «RASTRO · tomas» y su .json")


class RASTRO_PT_senal(_Base, bpy.types.Panel):
    bl_label = "Señal"
    bl_parent_id = "RASTRO_PT_main"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        lay = self.layout
        if icon("foto"):
            lay.template_icon(icon_value=icon("foto"), scale=8)
        osd(lay, f"RASTRO {VERSION} · {CREDIT}")
        col = lay.column(align=True)
        col.operator("rastro.abrir", text="@perdidadelalma", icon="URL").url = INSTAGRAM
        col.operator("rastro.abrir", text="Pérdida del Alma · web", icon="URL").url = WEB


class RASTRO_Preferencias(bpy.types.AddonPreferences):
    bl_idname = __package__
    ffmpeg: StringProperty(name="ffmpeg", subtype="FILE_PATH", description="Vacío = lo busca solo")
    colmap: StringProperty(name="COLMAP", subtype="FILE_PATH", description="Vacío = lo busca solo")

    def draw(self, context):
        lay = self.layout
        lay.prop(self, "ffmpeg")
        lay.label(text="Encontrado: " + (gopro.buscar_ffmpeg(self.ffmpeg) or "no"))
        lay.prop(self, "colmap")
        lay.label(text="Encontrado: " + (gopro.buscar_colmap(self.colmap) or "no"))


classes = (RASTRO_Preferencias, RASTRO_Ajustes, RASTRO_OT_elegir_camara, RASTRO_OT_camara_nueva, RASTRO_OT_conectar, RASTRO_OT_desconectar,
           RASTRO_OT_cero, RASTRO_OT_toma, RASTRO_OT_claqueta, RASTRO_OT_valorar, RASTRO_OT_instalar, RASTRO_OT_hojas, RASTRO_OT_calibrar, RASTRO_OT_plan, RASTRO_OT_imprimir,
           RASTRO_OT_borrar_mapa, RASTRO_OT_gopro, RASTRO_OT_escala, RASTRO_OT_abrir,
           RASTRO_PT_main, RASTRO_PT_camara, RASTRO_PT_directo, RASTRO_PT_marcadores, RASTRO_PT_gopro, RASTRO_PT_toma, RASTRO_PT_senal)


def register():
    dependencias.preparar_ruta()
    load_icons()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.rastro = PointerProperty(type=RASTRO_Ajustes)


def unregister():
    directo.parar()
    receptor.parar_https()
    receptor.parar_freed()
    del bpy.types.Scene.rastro
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    free_icons()
