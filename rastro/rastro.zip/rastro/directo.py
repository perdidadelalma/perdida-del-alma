# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""El directo: cada 1/60 s se coge la última pose, se suaviza, se alinea con la escena y mueve la cámara.
Grabar una toma guarda esas poses y al parar las convierte en fotogramas clave (y en un .json)."""

import json
import os
import time

import bpy
from mathutils import Matrix, Vector

from . import pose

COLECCION_TOMAS = "RASTRO · tomas"
HUECO = "RASTRO · aquí falta un marcador"
_s = {"aviso": "", "seguir": False, "esperando": False, "claqueta_vista": 0, "manual": False, "activo": False, "suav": pose.Suavizado(), "alin": pose.Alineacion(), "base": None,
      "grabando": False, "toma": [], "t0": 0.0, "frame0": 0, "ultimo": 0, "medidas": [], "hz": 0.0}


def ajustes(scene=None):
    return (scene or bpy.context.scene).rastro


def matriz_camara(R, p, a, cam):
    """Pose de la fuente → matriz de la cámara de Blender (alineación, escala y montaje del móvil)."""
    alin = _s["alin"]
    alin.escala = a.escala
    m = alin.aplicar(R, p, base=_s["base"])
    off = Vector(a.desplazamiento) / 100.0   # cm → m, en los ejes de la cámara
    return m @ Matrix.Translation(-off)


def paso():
    """Temporizador de Blender (en el hilo principal)."""
    if not _s["activo"]:
        return None
    sc = bpy.context.scene
    a = ajustes(sc)
    cam = sc.camera
    if cam is None:
        return 0.2
    from . import receptor
    if receptor.CLAQUETA["n"] != _s["claqueta_vista"]:
        _s["claqueta_vista"] = receptor.CLAQUETA["n"]
        if _s["esperando"] and not _s["grabando"]:
            empezar_toma(receptor.CLAQUETA["t"])
            _s["seguir"] = True  # rodando con claqueta: al cortar, se queda esperando la siguiente
    if a.fuente == "MARCADORES":
        avisar_hueco(sc, a)
    atender_movil(sc)
    ult = pose.BUZON.ultima(a.retraso / 1000.0)
    if ult is not None and pose.BUZON.contador != _s["ultimo"]:
        _s["ultimo"] = pose.BUZON.contador
        t, R, p = ult
        if a.suavizado > 0:
            R, p = _s["suav"](t, R, p)
        ancla = bpy.data.objects.get("RASTRO marcador 0") if a.fuente == "MARCADORES" else None
        if not _s["alin"].hecha and ancla is not None and not _s["manual"]:
            # El marcador 0 del plan: donde está en Blender es donde está en el plató. Así todas las
            # tomas (y todos los días) caen en el mismo sitio sin poner a cero.
            loc, rot, _esc = ancla.matrix_world.decompose()
            _s["alin"].M = Matrix.Translation(loc) @ rot.to_matrix().to_4x4()
            _s["alin"].hecha = True
        if not _s["alin"].hecha:
            _s["base"] = cam.matrix_world.copy()
            _s["alin"].escala = a.escala
            _s["alin"].poner_a_cero(R, p, cam.matrix_world, solo_vertical=a.fuente != "MARCADORES")
        m = matriz_camara(R, p, a, cam)
        cam.matrix_world = m
        if _s["grabando"]:
            _s["toma"].append((time.perf_counter() - _s["t0"], [list(f) for f in m]))
        ahora = time.perf_counter()
        _s["medidas"] = [x for x in _s["medidas"] if ahora - x < 1.0] + [ahora]
        _s["hz"] = len(_s["medidas"])
    return 1 / 60


def empezar():
    _s["activo"] = True
    _s["manual"] = False
    _s["alin"] = pose.Alineacion()
    _s["suav"].reiniciar(ajustes().suavizado)
    if not bpy.app.timers.is_registered(paso):
        bpy.app.timers.register(paso, first_interval=0.05, persistent=True)


def parar():
    _s["activo"] = False
    if _s["grabando"]:
        terminar_toma()


def poner_a_cero():
    """La próxima pose deja la cámara donde está ahora en Blender."""
    cam = bpy.context.scene.camera
    _s["manual"] = True  # manda lo que diga el usuario, aunque haya marcador 0 en la escena
    _s["alin"] = pose.Alineacion()
    _s["base"] = cam.matrix_world.copy() if cam else None
    _s["suav"].reiniciar(ajustes().suavizado)


def empezar_toma(t0=None):
    """t0: el instante de la claqueta (si la toma la ha disparado el móvil al oírla)."""
    sc = bpy.context.scene
    _s.update(grabando=True, esperando=False, toma=[], t0=t0 or time.perf_counter(), frame0=sc.frame_current)


def avisar_hueco(sc, a):
    """Si la cámara ve menos de 2 marcadores: un cuadrado en la escena donde mira y qué número poner ahí."""
    from . import marcadores
    st = marcadores.estado()
    falta, aviso, donde = st.get("falta"), "", None
    if st.get("activo") and falta == "ninguno":
        aviso = "No veo ningún marcador: apunta al 0 (o a uno que ya conozca)."
    elif st.get("activo") and falta and _s["alin"].hecha:
        alin = _s["alin"]
        donde = alin.M @ (Vector(falta) * alin.escala)
        plan = bpy.data.collections.get("RASTRO · plan de marcadores")
        libres = [o for o in (plan.objects if plan else []) if "rastro_marcador" in o and o["rastro_marcador"] not in st["ids"]]
        if libres:
            o = min(libres, key=lambda o: (o.matrix_world.translation - donde).length)
            num, extra = o["rastro_marcador"], " (el del plan)"
        else:
            num, extra = next(k for k in range(50) if k not in st["ids"]), ""
        aviso = f"Aquí faltan marcadores: pon el n.º {num}{extra} donde apunta la cámara."
    hueco = bpy.data.objects.get(HUECO)
    if donde is not None:
        if hueco is None:
            hueco = bpy.data.objects.new(HUECO, None)
            hueco.empty_display_type = "CUBE"
            sc.collection.objects.link(hueco)
        lado = a.tam_marcador / 200.0
        hueco.matrix_world = (Matrix.Translation(donde) @ _s["alin"].M.to_3x3().to_4x4()
                              @ Matrix.Diagonal((lado, lado, 0.01, 1.0)))
        hueco.hide_viewport = False
    elif hueco is not None and not hueco.hide_viewport:
        hueco.hide_viewport = True
    _s["aviso"] = aviso
    from . import receptor
    receptor.RODAJE["aviso"] = aviso


def atender_movil(sc):
    """Lo que pide el móvil (corten, valorar, plano…) se hace aquí, en el hilo de Blender, y se le publica el estado."""
    from . import receptor
    a = ajustes(sc)
    while receptor.PEDIDOS:
        d = receptor.PEDIDOS.popleft()
        orden = d.get("orden")
        if orden == "corten" and _s["grabando"]:
            terminar_toma()
        elif orden == "esperar":
            esperar_claqueta(not _s["esperando"])
        elif orden == "plano":
            a.plano = max(1, a.plano + int(d.get("cambio", 0)))
        elif orden == "valorar":
            valorar(d.get("id", ""), d.get("valor", ""))
    receptor.RODAJE.update(
        estado="grabando" if _s["grabando"] else "esperando" if _s["esperando"] else "listo",
        plano=a.plano, toma=siguiente_toma(a.plano), segundos=round(time.perf_counter() - _s["t0"], 1) if _s["grabando"] else 0,
        tomas=lista_tomas())


def coleccion_tomas():
    col = bpy.data.collections.get(COLECCION_TOMAS)
    if col is None:
        col = bpy.data.collections.new(COLECCION_TOMAS)
        bpy.context.scene.collection.children.link(col)
    return col


def tomas():
    col = bpy.data.collections.get(COLECCION_TOMAS)
    obs = [o for o in col.objects if "rastro_id" in o] if col else []
    return sorted(obs, key=lambda o: (o["rastro_plano"], o["rastro_toma"]))


def siguiente_toma(plano):
    return 1 + max([o["rastro_toma"] for o in tomas() if o["rastro_plano"] == plano] or [0])


def lista_tomas():
    return [{"id": o["rastro_id"], "plano": o["rastro_plano"], "toma": o["rastro_toma"],
             "segundos": o.get("rastro_segundos", 0), "valor": o.get("rastro_valor", "")} for o in tomas()]


def valorar(ident, valor):
    """«buena», «mala» o «» (sin valorar): en la cámara de la toma, en su nombre y en su .json."""
    for o in tomas():
        if o["rastro_id"] == ident:
            o["rastro_valor"] = valor if valor in ("buena", "mala") else ""
            marca = {"buena": " ✔", "mala": " ✘"}.get(o["rastro_valor"], "")
            o.name = f"RASTRO {ident}{marca}"
            o.color = {"buena": (0.3, 0.9, 0.4, 1), "mala": (0.95, 0.3, 0.3, 1)}.get(o["rastro_valor"], (1, 1, 1, 1))
            ruta = o.get("rastro_json", "")
            if ruta and os.path.exists(ruta):
                with open(ruta, encoding="utf-8") as f:
                    datos = json.load(f)
                datos["valor"] = o["rastro_valor"]
                with open(ruta, "w", encoding="utf-8") as f:
                    json.dump(datos, f)
            return True
    return False


def esperar_claqueta(si=True):
    from . import receptor
    _s["esperando"] = si
    _s["claqueta_vista"] = receptor.CLAQUETA["n"]  # solo cuentan los golpes a partir de ahora


def terminar_toma():
    """La toma pasa a una cámara nueva, «RASTRO P01 T03» (plano y toma, para la escaleta), en la colección
    «RASTRO · tomas», y a //rastro/P01_T03.json. La cámara del directo sigue libre para la siguiente."""
    _s["grabando"] = False
    if _s["seguir"]:
        esperar_claqueta(True)
    muestras = _s["toma"]
    sc = bpy.context.scene
    cam = sc.camera
    if not muestras or cam is None:
        return None
    a = ajustes(sc)
    plano, toma = a.plano, siguiente_toma(a.plano)
    ident = f"P{plano:02d} T{toma:02d}"
    fps = sc.render.fps / sc.render.fps_base
    carpeta = bpy.path.abspath("//rastro") if bpy.data.filepath else os.path.join(os.path.expanduser("~"), "RASTRO", "tomas")
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta, ident.replace(" ", "_") + ".json")
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump({"creado_con": "RASTRO · Cámara real, por Toniño (@perdidadelalma)", "plano": plano, "toma": toma, "valor": "", "fps": fps, "frame_inicio": _s["frame0"],
                   "camara": cam.get("rastro_camara", ""), "lente_mm": cam.data.lens, "fuente": pose.BUZON.fuente,
                   "muestras": muestras}, f)
    nueva = bpy.data.objects.new(f"RASTRO {ident}", cam.data.copy())
    nueva.data.name = f"RASTRO {ident}"
    for k, v in (("rastro_id", ident), ("rastro_plano", plano), ("rastro_toma", toma), ("rastro_valor", ""),
                 ("rastro_segundos", round(muestras[-1][0], 1)), ("rastro_json", ruta),
                 ("rastro_camara", cam.get("rastro_camara", ""))):
        nueva[k] = v
    coleccion_tomas().objects.link(nueva)
    hornear(nueva, muestras, fps, _s["frame0"], f"RASTRO {ident}")
    return ruta, len(muestras)


def hornear(cam, muestras, fps, frame0, nombre):
    """Una clave por fotograma: la muestra más cercana a cada instante."""
    accion = bpy.data.actions.new(nombre)
    cam.animation_data_create()
    cam.animation_data.action = accion
    cam.rotation_mode = "XYZ"
    duracion = muestras[-1][0]
    total = int(duracion * fps) + 1
    j = 0
    euler_prev = None
    for k in range(total):
        tk = k / fps
        while j + 1 < len(muestras) and abs(muestras[j + 1][0] - tk) <= abs(muestras[j][0] - tk):
            j += 1
        m = Matrix(muestras[j][1])
        loc, rot, _esc = m.decompose()
        e = rot.to_euler("XYZ", euler_prev) if euler_prev else rot.to_euler("XYZ")
        euler_prev = e
        cam.location, cam.rotation_euler = loc, e
        cam.keyframe_insert("location", frame=frame0 + k)
        cam.keyframe_insert("rotation_euler", frame=frame0 + k)
    sc = bpy.context.scene
    sc.frame_end = max(sc.frame_end, frame0 + total - 1)


def estado():
    return {"aviso": _s["aviso"], "activo": _s["activo"], "grabando": _s["grabando"], "esperando": _s["esperando"], "muestras": len(_s["toma"]),
            "hz": _s["hz"], "fuente": pose.BUZON.fuente, "edad": pose.BUZON.edad(), "cero": _s["alin"].hecha}
