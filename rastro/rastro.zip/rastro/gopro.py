# RASTRO · Cámara real — © 2026 Toniño · Pérdida del Alma (@perdidadelalma)
# SPDX-License-Identifier: GPL-3.0-or-later · la autoría debe conservarse (ver AVISO.txt)
"""GoPro + COLMAP: el movimiento bueno de la cámara, sacado después del rodaje.

En el plató: la GoPro va fija encima de la cámara de rodaje, se graban las dos a la vez y se da una
palmada al principio. Aquí:
1. sincronizar(): busca la palmada en el sonido de los dos vídeos → desfase en segundos.
2. extraer(): fotogramas de la GoPro alineados con los de la cámara de rodaje.
3. reconstruir(): COLMAP (lente ojo de pez, emparejado secuencial de vídeo) → modelo en texto.
4. leer_modelo() + a_blender(): poses de COLMAP → mundo de Blender (Z arriba, escala, la GoPro
   pasada al objetivo de la cámara de rodaje) → fotogramas clave.
Todo corre en un hilo con su registro; Blender solo hornea al final.
"""

import math
import os
import shutil
import subprocess
import threading

import numpy as np

CARPETA = os.path.join(os.path.expanduser("~"), "RASTRO")
_trabajo = {"activo": False, "fase": "", "log": [], "resultado": None, "error": ""}
SIN_VENTANA = 0x08000000 if os.name == "nt" else 0


# ---------------------------------------------------------------- herramientas externas

def buscar_ffmpeg(pref=""):
    candidatos = [pref, os.path.join(os.path.expanduser("~"), "CorridorKey2", "ffmpeg", "bin", "ffmpeg.exe"),
                  shutil.which("ffmpeg") or ""]
    return next((c for c in candidatos if c and os.path.isfile(c)), "")


def buscar_colmap(pref=""):
    candidatos = [pref, shutil.which("colmap") or "", shutil.which("colmap.exe") or "",
                  os.path.join(os.path.expanduser("~"), "Desktop", "colmap", "nikeColmap", "01 COLMAP", "colmap.exe"),
                  r"C:\Program Files\COLMAP\colmap.exe", r"C:\COLMAP\colmap.exe"]
    return next((c for c in candidatos if c and os.path.isfile(c)), "")


def _correr(cmd, nombre):
    _trabajo["fase"] = nombre
    _trabajo["log"].append("» " + nombre)
    r = subprocess.run(cmd, capture_output=True, text=True, creationflags=SIN_VENTANA)
    if r.returncode != 0:
        raise RuntimeError(f"{nombre} falló: {(r.stderr or r.stdout)[-500:]}")
    return r


# ---------------------------------------------------------------- 1 · sincronizar por la palmada

def audio(ffmpeg, video, segundos=60, sr=8000):
    r = subprocess.run([ffmpeg, "-v", "error", "-i", video, "-t", str(segundos), "-ac", "1", "-ar", str(sr),
                        "-f", "s16le", "-"], capture_output=True, creationflags=SIN_VENTANA)
    return np.frombuffer(r.stdout, np.int16).astype(np.float32) / 32768.0


def _ataques(x, sr=8000, ventana=0.01):
    """Curva de «golpes»: subida de energía cada 10 ms (la palmada es un pico enorme)."""
    n = int(sr * ventana)
    e = np.sqrt(np.add.reduceat(x[: len(x) // n * n] ** 2, np.arange(0, len(x) // n * n, n)) / n)
    d = np.maximum(np.diff(e, prepend=e[:1]), 0)
    return (d - d.mean()) / (d.std() + 1e-9)


def sincronizar(ffmpeg, video_a, video_b, segundos=60):
    """Segundos que hay que sumar a un instante del vídeo A para encontrarlo en el B (+ confianza)."""
    a, b = _ataques(audio(ffmpeg, video_a, segundos)), _ataques(audio(ffmpeg, video_b, segundos))
    n = 1 << int(np.ceil(np.log2(len(a) + len(b))))
    cc = np.fft.irfft(np.fft.rfft(b, n) * np.conj(np.fft.rfft(a, n)), n)
    k = int(np.argmax(cc))
    lag = k if k < n // 2 else k - n
    confianza = float(cc.max() / (np.sort(cc)[-20:-1].mean() + 1e-9))
    return lag * 0.01, confianza


# ---------------------------------------------------------------- 2 · fotogramas de la GoPro

def extraer(ffmpeg, video, carpeta, fps, desde=0.0, duracion=None, ancho=1600):
    os.makedirs(carpeta, exist_ok=True)
    for f in os.listdir(carpeta):
        if f.endswith(".jpg"):
            os.remove(os.path.join(carpeta, f))
    cmd = [ffmpeg, "-v", "error", "-ss", f"{max(desde, 0):.3f}", "-i", video]
    if duracion:
        cmd += ["-t", f"{duracion:.3f}"]
    cmd += ["-vf", f"fps={fps},scale={ancho}:-2", "-q:v", "2", os.path.join(carpeta, "f%05d.jpg")]
    _correr(cmd, "Sacar fotogramas de la GoPro")
    return sorted(f for f in os.listdir(carpeta) if f.endswith(".jpg"))


# ---------------------------------------------------------------- 3 · COLMAP

def reconstruir(colmap, imagenes, trabajo, ojo_de_pez=True):
    os.makedirs(trabajo, exist_ok=True)
    db = os.path.join(trabajo, "database.db")
    if os.path.exists(db):
        os.remove(db)
    esparso, texto = os.path.join(trabajo, "sparse"), os.path.join(trabajo, "txt")
    shutil.rmtree(esparso, ignore_errors=True)
    os.makedirs(esparso)
    os.makedirs(texto, exist_ok=True)
    modelo = "OPENCV_FISHEYE" if ojo_de_pez else "OPENCV"
    _correr([colmap, "feature_extractor", "--database_path", db, "--image_path", imagenes,
             "--ImageReader.single_camera", "1", "--ImageReader.camera_model", modelo], "Puntos de cada fotograma (COLMAP)")
    _correr([colmap, "sequential_matcher", "--database_path", db, "--SequentialMatching.overlap", "15",
             "--SequentialMatching.loop_detection", "0"], "Emparejar fotogramas seguidos (COLMAP)")
    _correr([colmap, "mapper", "--database_path", db, "--image_path", imagenes, "--output_path", esparso],
            "Reconstruir la cámara (COLMAP)")
    modelos = sorted((d for d in os.listdir(esparso) if d.isdigit()),
                     key=lambda d: -len(os.listdir(os.path.join(esparso, d))))
    if not modelos:
        raise RuntimeError("COLMAP no pudo reconstruir: la GoPro tiene que ver plató con textura y moverse algo.")
    # el modelo con más imágenes registradas
    mejor = max(modelos, key=lambda d: os.path.getsize(os.path.join(esparso, d, "images.bin")))
    _correr([colmap, "model_converter", "--input_path", os.path.join(esparso, mejor), "--output_path", texto,
             "--output_type", "TXT"], "Pasar el modelo a texto (COLMAP)")
    return texto


# ---------------------------------------------------------------- 4 · del modelo a Blender

def _q_a_R(qw, qx, qy, qz):
    return np.array([[1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
                     [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
                     [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)]])


def leer_modelo(texto):
    """{nombre de imagen: (R cámara→mundo, centro)} en el mundo de COLMAP."""
    poses = {}
    with open(os.path.join(texto, "images.txt"), encoding="utf-8", errors="replace") as f:
        lineas = [l for l in f if not l.startswith("#")]
    for l in lineas[::2]:
        p = l.split()
        if len(p) < 10:
            continue
        R_cw = _q_a_R(*map(float, p[1:5]))
        t = np.array(list(map(float, p[5:8])))
        R_wc = R_cw.T
        poses[p[9]] = (R_wc, -R_wc @ t)
    return poses


_CV_A_BL = np.diag([1.0, -1.0, -1.0])


def a_blender(poses, nombres, escala=1.0, inclinacion_gopro=0.0):
    """Lista (una por fotograma, None si COLMAP no lo registró) de matrices 4×4 en Blender.
    Arriba = la media del «arriba» de las cámaras; el primer fotograma mira hacia +Y desde el origen.
    «inclinacion_gopro»: grados que la GoPro mira por encima del objetivo de la cámara de rodaje."""
    validas = [poses[n] for n in nombres if n in poses]
    if not validas:
        return []
    arriba = -np.mean([R[:, 1] for R, _c in validas], axis=0)   # en COLMAP la y de la cámara va hacia abajo
    arriba /= np.linalg.norm(arriba)
    R0, c0 = validas[0]
    frente = R0[:, 2] - arriba * (R0[:, 2] @ arriba)   # z de la cámara COLMAP = adelante, en horizontal
    frente /= np.linalg.norm(frente)
    derecha = np.cross(frente, arriba)
    A = np.array([derecha, frente, arriba])   # mundo COLMAP → Blender (x derecha, y al frente, z arriba)
    a = math.radians(inclinacion_gopro)
    M = np.array([[1, 0, 0], [0, math.cos(a), -math.sin(a)], [0, math.sin(a), math.cos(a)]])  # objetivo ← GoPro
    salida = []
    for n in nombres:
        if n not in poses:
            salida.append(None)
            continue
        R_wc, c = poses[n]
        R_bl = A @ R_wc @ _CV_A_BL @ M.T
        m = np.eye(4)
        m[:3, :3] = R_bl
        m[:3, 3] = A @ (c - c0) * escala
        salida.append(m)
    return rellenar(salida)


def rellenar(lista):
    """Fotogramas que COLMAP no registró: se interpolan entre los vecinos (posición lineal, giro esférico)."""
    from mathutils import Matrix
    idx = [i for i, m in enumerate(lista) if m is not None]
    if not idx:
        return lista
    for i in range(len(lista)):
        if lista[i] is not None:
            continue
        antes = max((k for k in idx if k < i), default=None)
        despues = min((k for k in idx if k > i), default=None)
        if antes is None or despues is None:
            lista[i] = lista[antes if antes is not None else despues].copy()
            continue
        t = (i - antes) / (despues - antes)
        ma, mb = Matrix(lista[antes].tolist()), Matrix(lista[despues].tolist())
        q = ma.to_quaternion().slerp(mb.to_quaternion(), t)
        m = q.to_matrix().to_4x4()
        m.translation = ma.translation.lerp(mb.translation, t)
        lista[i] = np.array(m)
    return lista


# ---------------------------------------------------------------- todo junto, en un hilo

def procesar(gopro, cine=None, fps=24.0, ffmpeg="", colmap="", ojo_de_pez=True, escala=1.0,
             inclinacion_gopro=0.0, duracion=None, al_acabar=None):
    _trabajo.update(activo=True, fase="Empezando", log=[], resultado=None, error="")

    def hilo():
        try:
            ff, cm = buscar_ffmpeg(ffmpeg), buscar_colmap(colmap)
            if not ff:
                raise RuntimeError("No encuentro ffmpeg (ponlo en las preferencias del addon).")
            if not cm:
                raise RuntimeError("No encuentro COLMAP (ponlo en las preferencias del addon).")
            desfase, conf = 0.0, 0.0
            if cine:
                _trabajo["fase"] = "Buscar la palmada en el sonido"
                desfase, conf = sincronizar(ff, cine, gopro)
                _trabajo["log"].append(f"Desfase GoPro − cámara: {desfase:+.2f} s (confianza {conf:.1f})")
            nombre = os.path.splitext(os.path.basename(gopro))[0]
            trabajo = os.path.join(CARPETA, "gopro", nombre)
            imgs = extraer(ff, gopro, os.path.join(trabajo, "imagenes"), fps, desde=desfase, duracion=duracion)
            _trabajo["log"].append(f"{len(imgs)} fotogramas")
            texto = reconstruir(cm, os.path.join(trabajo, "imagenes"), trabajo, ojo_de_pez)
            poses = leer_modelo(texto)
            _trabajo["log"].append(f"COLMAP registró {len(poses)} de {len(imgs)} fotogramas")
            mats = a_blender(poses, imgs, escala, inclinacion_gopro)
            _trabajo["resultado"] = {"matrices": [m.tolist() for m in mats], "fps": fps, "desfase": desfase,
                                     "registrados": len(poses), "total": len(imgs), "cine": cine, "trabajo": trabajo}
            _trabajo["fase"] = "Listo"
        except Exception as e:
            _trabajo["error"] = str(e)
            _trabajo["fase"] = "Error"
        _trabajo["activo"] = False
        if al_acabar:
            al_acabar()
    threading.Thread(target=hilo, daemon=True).start()


def estado():
    return dict(_trabajo)
